Copy files in this directory to these locations:

"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\debugger\NXP\PN7360AU-C3-00.ddf"
"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\debugger\NXP\PN7362AU-C3-00.ddf"
"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\debugger\NXP\PN73xxAU.svd"
"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\debugger\NXP\PN7462AU-C3-00.ddf"
"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\debugger\NXP\PN74xxAU.svd"
"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\debugger\NXP\PN7xxxxx.ProbeScript"
"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\devices\NXP\Other\PN73xxxx\PN7360AU-C3-00.i79"
"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\devices\NXP\Other\PN73xxxx\PN7360AU-C3-00.menu"
"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\devices\NXP\Other\PN73xxxx\PN7362AU-C3-00.i79"
"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\devices\NXP\Other\PN73xxxx\PN7362AU-C3-00.menu"
"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\devices\NXP\Other\PN74xxxx\PN7462AU-C3-00.i79"
"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\devices\NXP\Other\PN74xxxx\PN7462AU-C3-00.menu"
"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\flashloader\NXP\EepromPN7xxxxx_3_5k.flash"
"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\flashloader\NXP\FlashPN7xxxxx.out"
"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\flashloader\NXP\FlashPN7xxxxx_158k.board"
"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\flashloader\NXP\FlashPN7xxxxx_158k.flash"
"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\flashloader\NXP\FlashPN7xxxxx_80k.board"
"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\flashloader\NXP\FlashPN7xxxxx_80k.flash"
"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\linker\NXP\PN7xxxxx_158k.icf"
"C:\Program Files (x86)\IAR Systems\Embedded Workbench 7.4\arm\config\linker\NXP\PN7xxxxx_80k.icf"

"Version Information:"

Path: .
Working Copy Root Path: C:\_ddm\n\pn640\_cm\pn640.build
URL: https://www.collabnet.nxp.com/svn/pn640/pn640_build/trunk/IAR_Integration
Relative URL: ^/pn640_build/trunk/IAR_Integration
Repository Root: https://www.collabnet.nxp.com/svn/pn640
Repository UUID: f74fc608-ddfc-4ee0-acd2-acb2db8fb06c
Revision: 18521
Node Kind: directory
Schedule: normal
Last Changed Author: Purnank G (ing05193)
Last Changed Rev: 18521
Last Changed Date: 2016-06-29 19:40:42 +0530 (Wed, 29 Jun 2016)

