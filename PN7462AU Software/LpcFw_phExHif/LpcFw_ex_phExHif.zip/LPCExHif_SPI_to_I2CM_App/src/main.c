/*
 *                  Copyright (c), NXP Semiconductors
 *
 *                     (C)NXP Semiconductors
 *       All rights are reserved. Reproduction in whole or in part is
 *      prohibited without the written consent of the copyright owner.
 *  NXP reserves the right to make changes without notice at any time.
 * NXP makes no warranty, expressed, implied or statutory, including but
 * not limited to any implied warranty of merchantability or fitness for any
 *particular purpose, or that the use will not infringe any third party patent,
 * copyright or trademark. NXP must not be liable for any loss or damage
 *                          arising from its use.
 */

/** \file
 * main.c
 * $Author: Vinay Singh P (NXP74831) $
 * $Revision: 6799 $
 * $Date: 2014-09-01 11:46:12 +0530 (Mon, 01 Sep 2014) $
 *
 * History:
 *
 */
#include <cr_section_macros.h>
#include <NXP/crp.h>
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

#include "string.h"
#include "LPC17xx.h"
#include "delay.h"
#include "lpcExHif_config.h"
#include "lpcExHif.h"
#include "main.h"
#include "phExHif_Log.h"
#include "LPCExHif_SPI_to_I2CM_App_Ver.h"

volatile uint32_t msTicks = 0;

void SysTick_Handler(void)
{
	msTicks ++;
}

/*
 * Function Name     : main
 * Description       : Entry point.
 * Input Parameters  : void
 * Output Parameters :
 * NOTE              :
 */
int main(void)
{

    /* Update the system core clock */
    SystemCoreClockUpdate();

    /*Initialise the GPIO's used for Interface selection and communication channel*/
    SET_GPIO_HIF_INTERACE_L_OUTPUT;
    CLEAR_GPIO_HIF_INTERACE_L;

    SET_GPIO_HIF_INTERACE_H_OUTPUT;
    CLEAR_GPIO_HIF_INTERACE_H;

    SET_GPIO_COMM_CHANNEL_L_OUTPUT;
    CLEAR_GPIO_COMM_CHANNEL_L;

    SET_GPIO_COMM_CHANNEL_M_OUTPUT;
    CLEAR_GPIO_COMM_CHANNEL_M;

    SET_GPIO_COMM_CHANNEL_H_OUTPUT;
    CLEAR_GPIO_COMM_CHANNEL_H;

    /** Turn ON LED */
    LPC_GPIO0->FIODIR |= LED_MASK;
    LPC_GPIO0->FIOSET |= LED_MASK;

    /** Set DAT READY pin as Input */
    SET_DATA_READY_PIN_INPUT;


    while(1)
    {
        LOG_TXT(LPCExHif_SPI_to_I2CM_VER_FILEDESCRIPTION);
    	LOG_TXT("Interface Selected: HIF SPI");
    	LOG_TXT("Communication Channel Selected: Forward to I2CM");

		/*Configure the interfaces as per Config.h*/
		lpcExHif_InitInterface(PH_EXHIF_INTERFACE_HIF_SPI);

		/*Initialize and perform the test over the selected communication channel*/
		lpcExHif_InitCommChannel(PH_EXHIF_INTERFACE_HIF_SPI,PH_EXHIF_I2CM);

		/* For synchronization between PN640 and LPC1769*/
		while(GET_DATA_READY_PIN);

		/*Hold the interface selection lines to zero to re-initialize the Queues in PN640*/
		CLEAR_GPIO_HIF_INTERACE_L;
		CLEAR_GPIO_HIF_INTERACE_H;

    }
    return 0;
}
