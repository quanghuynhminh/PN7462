/*
 *                  Copyright (c), NXP Semiconductors
 *
 *                     (C)NXP Semiconductors
 *       All rights are reserved. Reproduction in whole or in part is
 *      prohibited without the written consent of the copyright owner.
 *  NXP reserves the right to make changes without notice at any time.
 * NXP makes no warranty, expressed, implied or statutory, including but
 * not limited to any implied warranty of merchantability or fitness for any
 *particular purpose, or that the use will not infringe any third party patent,
 * copyright or trademark. NXP must not be liable for any loss or damage
 *                          arising from its use.
 */

/** \file
 * main.h
 * $Author: nxp47613 $
 * $Revision: 001 $
 * $Date: 2013-07-26 10:28:17 +0530 (Fri, 26 Jul 2013) $
 *
 * History:
 *
 */
#ifndef _MAIN_H
#define _MAIN_H

#include <stdint.h>

typedef void (*TestArr)(void);

#define ENTER_BOOTLOADER   0x01
#define ENTER_TESTGROUP    0x02
#define RESET_COMMAND      0x03
#define AB_COMMAND         0x04

#define TEST_LENGTH_ERROR  0x01
#define TEST_RDY_TO_ERROR  0x02
#define TEST_RESP_FAIL_ERROR  0x03

#define LED_MASK  (1 << 22)
/*
#define REPORT_ERROR(a) fifo_flush(&rxfifo); \
                        fifo_flush(&txfifo); \
                        VCOM_putchar(0xAB);  \
                        VCOM_putchar(a);     \
*/

#define REPORT_ERROR(a) fifo_flush(&rxfifo); \
                        fifo_flush(&txfifo); \
                        VCOM_putchar(a);     \


#define REPORT_TEST_ERROR(a)  fifo_flush(&rxfifo); \
                              fifo_flush(&txfifo); \
                              VCOM_putchar('T');  \
                              VCOM_putchar(a);     \

extern uint32_t GetMaxTests(void);
extern TestArr GetBaseAddr(void);


#endif /* _MAIN_H */
