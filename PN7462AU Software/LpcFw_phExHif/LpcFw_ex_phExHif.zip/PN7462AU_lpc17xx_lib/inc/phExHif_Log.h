/*
 *                    Copyright (c), NXP Semiconductors
 *
 *                       (C) NXP Semiconductors 2014
 *
 *         All rights are reserved. Reproduction in whole or in part is
 *        prohibited without the written consent of the copyright owner.
 *    NXP reserves the right to make changes without notice at any time.
 *   NXP makes no warranty, expressed, implied or statutory, including but
 *   not limited to any implied warranty of merchantability or fitness for any
 *  particular purpose, or that the use will not infringe any third party patent,
 *   copyright or trademark. NXP must not be liable for any loss or damage
 *                            arising from its use.
 */

/** @file
 *
 * @todo Describe purpose and scope of this file
 *
 * Project:  PN640
 *
 * $Date: 2014-09-25 11:20:55 +0530 (Thu, 25 Sep 2014) $
 * $Author: Sugasi Rajesh (nxp69678) $
 * $Revision: 7262 $
 */

#ifndef PHEXHIF_LOG_H
#define PHEXHIF_LOG_H

/* *****************************************************************************************************************
 * Includes
 * ***************************************************************************************************************** */
#include "stdio.h"
#include "stdint.h"
/****************************************************************************************************************
 * MACROS/Defines
 * ***************************************************************************************************************** */
#ifdef __CODE_RED
#   ifndef PHEXHIF_ENABLE_LOG
#       define PHEXHIF_ENABLE_LOG 1
#   endif /* PHEXHIF_ENABLE_LOG */
#endif

#ifdef NDEBUG
/* No logging for relesae mode */
#	undef PHEXHIF_ENABLE_LOG
#	define PHEXHIF_ENABLE_LOG 0
#endif


#if PHEXHIF_ENABLE_LOG
	/** Log text */
#   define LOG_TXT(TXT) printf("%s:\t%d:\t%s\n",__FUNCTION__,__LINE__,(TXT))
	/** Log 32bit integer value */
#   define LOG_U32(TXT,U32) printf("%s:\t%d:\t%s=%d\n",__FUNCTION__,__LINE__,(TXT),(U32))
	/** Log 32bit hex value */
#   define LOG_X32(TXT,X32) printf("%s:\t%d:\t%s=0x%X\n",__FUNCTION__,__LINE__,(TXT),(X32))
	/** Log array of 8 bit
	 * @par */
	/**
	 *
	 * @param AU8 Array of uint8_t values
	 * @param LU8 Length of LU8
	 */
#   define LOG_AU8(TXT,AU8,LU8) do {			\
				LOG_TXT(TXT);					\
				phExHif_Log_AU8((AU8),(LU8));	\
	} while (0)
#else
#   define LOG_TXT(TXT)
#   define LOG_U32(TXT,U32)
#   define LOG_X32(TXT,U32)
#   define LOG_AU8(TXT,AU8,LU8)
#endif

/* *****************************************************************************************************************
 * Types/Structure Declarations
 * ***************************************************************************************************************** */

/* *****************************************************************************************************************
 * Extern Variables
 * ***************************************************************************************************************** */

/* *****************************************************************************************************************
 * Function Prototypes
 * ***************************************************************************************************************** */

#if PHEXHIF_ENABLE_LOG
void phExHif_Log_AU8(uint8_t * inBuf, const uint32_t inBufLen);
#else /* PHEXHIF_ENABLE_LOG */
#	define phExHif_Log_AU8(X,Y)
#endif /* PHEXHIF_ENABLE_LOG */


#endif /* PHEXHIF_LOG_H */
