/*
 * i2c_config.h
 *
 *  Created on: Oct 8, 2013
 *      Author: nxp69678
 */

#include "lpc_types.h"
#include "LPC17xx.h"


#ifndef I2C_CONFIG_H_
#define I2C_CONFIG_H_

#define CHIP_LPC175X_6X
#define CORE_M3

#define STATIC static
#define INLINE inline
#define bool Bool

#define I2C_HDLL_ADDR_BITS 0x3FF
#define I2C_HDLL_CRC_LEN 2
#define I2C_HDLL_HEADER_LEN 2
#define I2C_HDLL_MAX_HEADER_LEN 4

#define CRYSTAL_MAIN_FREQ_IN (12000000UL)
#define CRYSTAL_32K_FREQ_IN (32000UL)
#define I2C0_RATE (100000UL) /*400 KHz */

#endif /* I2C_CONFIG_H_ */
