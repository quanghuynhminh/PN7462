/*
 *                  Copyright (c), NXP Semiconductors
 *
 *                     (C)NXP Semiconductors
 *       All rights are reserved. Reproduction in whole or in part is
 *      prohibited without the written consent of the copyright owner.
 *  NXP reserves the right to make changes without notice at any time.
 * NXP makes no warranty, expressed, implied or statutory, including but
 * not limited to any implied warranty of merchantability or fitness for any
 *particular purpose, or that the use will not infringe any third party patent,
 * copyright or trademark. NXP must not be liable for any loss or damage
 *                          arising from its use.
 */

/** \file
 * IAP.h
 * $Author: nxp47613 $
 * $Revision: 001 $
 * $Date: 2013-07-26 10:28:17 +0530 (Fri, 26 Jul 2013) $
 *
 * History:
 *
 */

#ifndef  _IAP_H
#define  _IAP_H

#include "stdint.h"

typedef enum
{
PREPARE_SECTOR_FOR_WRITE    =50,
COPY_RAM_TO_FLASH              =51,
ERASE_SECTOR                   =52,
BLANK_CHECK_SECTOR          =53,
READ_PART_ID                   =54,
READ_BOOT_VER                  =55,
COMPARE                        =56,
REINVOKE_IAP                   =57
}IAP_Command_Code;

#define CMD_SUCCESS 0
#define IAP_ADDRESS 0x1FFF1FF1

#define IAP_EXECUTE_CMD(a, b)       __asm("cpsid i");  \
                                      ((void (*)())(IAP_ADDRESS))(a, b);   \
                                      __asm("cpsie i");   \

#define USER_START_SECTOR 16
#define USER_FLASH_START  0x10000

#define IAP_ENTRY_FLASH_SECTOR_SIZE       256
#define IAP_ENTRY_FLASH_LOCATION       (USER_FLASH_START - 1)
#define IAP_ENTRY_FLASH_SECTOR_START_ADDR (USER_FLASH_START - IAP_ENTRY_FLASH_SECTOR_SIZE)
#define IAP_ENTRY_FLASH_SECTOR_NR         15

extern uint32_t erase_sector(unsigned start_sector,unsigned end_sector,unsigned cclk);
extern uint32_t prepare_sector(unsigned start_sector,unsigned end_sector,unsigned cclk);
extern uint32_t IAP_write_data(unsigned flash_address,unsigned * flash_data_buf, unsigned count, unsigned cclk);
void erase_user_flash(void);
void update_iap_entry_location(char val);

#endif /* _IAP_H */
