/*
 *                  Copyright (c), NXP Semiconductors
 *
 *                     (C)NXP Semiconductors
 *       All rights are reserved. Reproduction in whole or in part is
 *      prohibited without the written consent of the copyright owner.
 *  NXP reserves the right to make changes without notice at any time.
 * NXP makes no warranty, expressed, implied or statutory, including but
 * not limited to any implied warranty of merchantability or fitness for any
 *particular purpose, or that the use will not infringe any third party patent,
 * copyright or trademark. NXP must not be liable for any loss or damage
 *                          arising from its use.
 */

/** \file
 * lpcusb_type.h
 * $Author: nxp47613 $
 * $Revision: 001 $
 * $Date: 2013-07-26 10:28:17 +0530 (Fri, 26 Jul 2013) $
 *
 * History:
 *
 */
#ifndef _LPCUSB_TYPE_H_
#define _LPCUSB_TYPE_H_

#include "type.h"

typedef unsigned char       U8;     /**< unsigned 8-bit */
typedef unsigned short int  U16;    /**< unsigned 16-bit */
typedef unsigned int        U32;    /**< unsigned 32-bit */

/* some other useful macros */
#define MIN(x,y)    ((x)<(y)?(x):(y))   /**< MIN */
#define MAX(x,y)    ((x)>(y)?(x):(y))   /**< MAX */

#endif /* _LPCUSB_TYPE_H_ */
