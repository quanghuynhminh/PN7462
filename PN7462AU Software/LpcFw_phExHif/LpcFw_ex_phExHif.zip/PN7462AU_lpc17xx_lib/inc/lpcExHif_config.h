/**************************************************************************
 * Macros/Defines
 ************************************************************************/


/**
 * Gpio's 2.0 & 2.1 are used to select the Hif interface.
 *
 * GPIO2.0  GPIO2.1
 *   0        0         => Invalid
 *   0        1         => I2C
 *   1        0         => SPI
 *   1        1         => HSU
 */
#define PH_EXHIF_GPIO_HIF_INTERACE_L        0
#define PH_EXHIF_GPIO_HIF_INTERACE_H        1

/**
 * Gpio's 2.2, 2.3 & 2.4 are used to select the communication channels.
 *
 * GPIO2.2  GPIO2.3  GPIO2.4
 *   0      	0      0    => Loop back operation.
 *   0      	0      1    => Send across I2CM.
 *   0      	1      0    => Send across SPIM.
 *   0      	1      1    => Send across I2CM as well as SPIM.
 *   1      	0      0    => EEPROM Write.
 *   1      	0      1    => Flash Write.
 *   1      	1      0    => Forward Packet to CT.
 *   1      	1      1    => RFU
 */
#define PH_EXHIF_GPIO_COMM_CHANNEL_L        2
#define PH_EXHIF_GPIO_COMM_CHANNEL_M        3
#define PH_EXHIF_GPIO_COMM_CHANNEL_H        4

#define PH_EXHIF_INTERFACE_HIF_I2C			1
#define PH_EXHIF_INTERFACE_HIF_SPI			2
#define PH_EXHIF_INTERFACE_HIF_HSU			3

#define PH_EXHIF_LOOPBACK	        		0
#define PH_EXHIF_I2CM						1
#define PH_EXHIF_SPIM						2
#define PH_EXHIF_I2CM_SPIM					3
#define PH_EXHIF_EEPROM_WRITE				4
#define PH_EXHIF_FLASH_WRITE				5
#define PH_EXHIF_CT_TRANSACTION             6
#define PH_EXHIF_PERFORMANCE				7

/*I2C Configurable params*/
#define LPC_EXHIF_I2C_MASTER_DATARATE   	400000
#define LPC_EXHIF_I2C_SLAVE_DATARATE   		400000
#define LPC_EXHIF_I2C_SLAVE_ADDR        	0x28

/** SPI Configurable params*/
/** Phase and Polarity */
#define LPC_EXHIF_SPI_CPOL      			0
#define LPC_EXHIF_SPI_CPHA      			0
/** SPI Master Interface Datarate */
#define LPC_EXHIF_SPIM_DATARATE     		1000000
/** SPI Slave Interface Datarate */
#define LPC_EXHIF_SPIS_DATARATE     		7000000

/*HSU Configurable params*/
#define LPC_EXHIF_HSU_STOPBITS      		0   /*Indicates 1 Stopbit*/
#define LPC_EXHIF_HSU_DATARATE      		9600
#define LPC_EXHIF_HSU_PARITY        		0
#define LPC_EXHIF_HSU_DATABITS      		3   /*Indicates 8 databits*/

/** Number of bytes to be transmitted in the sample application*/
/** MAXIMUM SIZE IS 1024 for HIF and 512 for SPIM*/
#define LPC_EXHIF_BUFFERSIZE    			256


/*PN640 Specific EEPROM SIZE*/
#define PH_EXHIF_EEPROM_SIZE				4096
#define PH_EXHIF_USER_EEPROM_SIZE			256  /*Number of bytes to write in EEPROM*/
#define PH_EXHIF_EEPROM_PAGE_SIZE			64

/*PN640 Specific FLASH SIZE*/
#define PH_EXHIF_FLASH_PAGE_SIZE			128
#define PH_EXHIF_FLASH_PAGES_WRITE_COUNT	2


#define ZERO    							0
#define ONE     							1
#define TWO     							2
#define THREE   							3
