/*
 *                  Copyright (c), NXP Semiconductors
 *
 *                     (C)NXP Semiconductors
 *       All rights are reserved. Reproduction in whole or in part is
 *      prohibited without the written consent of the copyright owner.
 *  NXP reserves the right to make changes without notice at any time.
 * NXP makes no warranty, expressed, implied or statutory, including but
 * not limited to any implied warranty of merchantability or fitness for any
 *particular purpose, or that the use will not infringe any third party patent,
 * copyright or trademark. NXP must not be liable for any loss or damage
 *                          arising from its use.
 */

/* \file
 * lpc_types.h
 * $Author: nxp47613 $
 * $Revision: 001 $
 * $Date: 2013-07-26 10:28:17 +0530 (Fri, 26 Jul 2013) $
 *
 * History:
 *
 */

#ifndef LPC_TYPES_H
#define LPC_TYPES_H

#include <stdint.h>
#include "type.h"
#include "lpcusb_type.h"

#define PARAM_SETSTATE(State) ((State==RESET) || (State==SET))

#define PARAM_FUNCTIONALSTATE(State) ((State==DISABLE) || (State==ENABLE))

typedef enum {ERROR = 0, SUCCESS = !ERROR} Status;

/* Enum for TRUE AND FALSE */
//typedef enum {FALSE = 0, TRUE = !FALSE} Bool;
typedef enum {false = 0, true = !false} Bool;

typedef enum
{
    NONE_BLOCKING = 0,      /**< None Blocking type */
    BLOCKING,               /**< Blocking type */
} TRANSFER_BLOCK_Type;


typedef int32_t(*PFI)();

#undef _BIT

#define _BIT(n) (1<<n)

#undef _SBF

#define _SBF(f,v) (v<<f)

#undef _BITMASK

#define _BITMASK(field_width) ( _BIT(field_width) - 1)

/* NULL pointer */
#ifndef NULL
#define NULL ((void*) 0)
#endif

/* Number of elements in an array */
#define NELEMENTS(array)  (sizeof (array) / sizeof (array[0]))

/* Static data/function define */
#define STATIC static
/* External data/function define */
#define EXTERN extern



/* SMA type for character type */
typedef char CHAR;

/* SMA type for 8 bit unsigned value */
typedef uint8_t UNS_8;

/* SMA type for 8 bit signed value */
typedef int8_t INT_8;

/* SMA type for 16 bit unsigned value */
typedef uint16_t UNS_16;

/* SMA type for 16 bit signed value */
typedef int16_t INT_16;

/* SMA type for 32 bit unsigned value */
typedef uint32_t UNS_32;

/* SMA type for 32 bit signed value */
typedef int32_t INT_32;

/* SMA type for 64 bit signed value */
typedef int64_t INT_64;

/* SMA type for 64 bit unsigned value */
typedef uint64_t UNS_64;

/* 32 bit boolean type */
typedef Bool BOOL_32;

/* 16 bit boolean type */
typedef Bool BOOL_16;

/* 8 bit boolean type */
typedef Bool BOOL_8;

#endif /* LPC_TYPES_H */
