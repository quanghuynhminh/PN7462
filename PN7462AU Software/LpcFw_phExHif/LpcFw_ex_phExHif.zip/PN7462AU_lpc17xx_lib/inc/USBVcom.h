/*
 *                  Copyright (c), NXP Semiconductors
 *
 *                     (C)NXP Semiconductors
 *       All rights are reserved. Reproduction in whole or in part is
 *      prohibited without the written consent of the copyright owner.
 *  NXP reserves the right to make changes without notice at any time.
 * NXP makes no warranty, expressed, implied or statutory, including but
 * not limited to any implied warranty of merchantability or fitness for any
 *particular purpose, or that the use will not infringe any third party patent,
 * copyright or trademark. NXP must not be liable for any loss or damage
 *                          arising from its use.
 */

/** \file
 * usbvcom.h
 * $Author: nxp47613 $
 * $Revision: 001 $
 * $Date: 2013-07-26 10:28:17 +0530 (Fri, 26 Jul 2013) $
 *
 * History:
 *
 */
#ifndef __USBVCOM_H__
#define __USBVCOM_H__

#include "usbstruct.h"

/* Macro enabled for UHOST or CounterPart P2P */
#define USBVCOM_UHOST
//#define USBVCOM_CounterPart_P2P

#define INT_IN_EP          0x81
#define BULK_OUT_EP     0x05
#define BULK_IN_EP      0x82

#define MAX_PACKET_SIZE 64

#define LE_WORD(x)      ((x)&0xFF),((x)>>8)

/* CDC definitions */
#define CS_INTERFACE            0x24
#define CS_ENDPOINT             0x25

#define SET_LINE_CODING         0x20
#define GET_LINE_CODING         0x21
#define SET_CONTROL_LINE_STATE  0x22

void BulkOut(U8 bEP, U8 bEPStatus);
void BulkIn(U8 bEP, U8 bEPStatus);
BOOL HandleClassRequest(TSetupPacket *pSetup, int *piLen, U8 **ppbData);
void VCOM_init(void);
int VCOM_putchar(uint8_t c);
void VCOM_putstring (char datasend[]);
void VCOM_putstring2 (char datasend[]);
int VCOM_getchar(void);
void VCOM_putdata(uint8_t datasend[], uint16_t lenghtdata);
int VCOM_GetString(char *data);
char* VCOM_RecieveString(void);
int VCOM_Available(void);
int verifyincoming_data(void);
void USB_init (void);
void USB_IRQHandler(void);
void USBFrameHandler(U16 wFrame);
void enable_USB_interrupts(void);
void enable_USB_interrupts(void);

#endif /* __USBVCOM_H__ */
