/*
 * DUT_I2C.h
 *
 *  Created on:Mar 27, 2014
 *      Author: nxp74831
 */
/* *****************************************************************************************************************
 * Includes
 * ***************************************************************************************************************** */

#include "LPC17xx.h"
#include "lpc17xx_i2c.h"
#include "lpc17xx_pinsel.h"
#include "gpio_17xx_40xx.h"
#include "lpc17xx_ssp.h"
#include "lpc17xx_uart.h"
#include "lpc17xx_clkpwr.h"
/* *****************************************************************************************************************
 * Macros/Defines
 * ***************************************************************************************************************** */
#define DATA_IRQ_CMD_PIN 		   11
#define GET_IRQ_CMD_PIN            (LPC_GPIO2->FIOPIN & (1 << DATA_IRQ_CMD_PIN))
#define SET_IRQ_CMD_PIN_INPUT      (LPC_GPIO2->FIODIR &= ~(1 << DATA_IRQ_CMD_PIN))
#define SET_LOW_CMD_PIN            (LPC_PINCON->PINMODE4 |= (3<<22))

#define DATA_READY_PIN 			   0
#define GET_DATA_READY_PIN         (LPC_GPIO0->FIOPIN & (1 << DATA_READY_PIN))
#define SET_DATA_READY_PIN_INPUT   (LPC_GPIO0->FIODIR &= ~(1 << DATA_READY_PIN))

#define SET_GPIO_HIF_INTERACE_L_OUTPUT      (LPC_GPIO2->FIODIR |= (1 << PH_EXHIF_GPIO_HIF_INTERACE_L))
#define SET_GPIO_HIF_INTERACE_L     		(LPC_GPIO2->FIOSET |= (1 << PH_EXHIF_GPIO_HIF_INTERACE_L))
#define CLEAR_GPIO_HIF_INTERACE_L   		(LPC_GPIO2->FIOCLR |= (1 << PH_EXHIF_GPIO_HIF_INTERACE_L))

#define SET_GPIO_HIF_INTERACE_H_OUTPUT      (LPC_GPIO2->FIODIR |= (1 << PH_EXHIF_GPIO_HIF_INTERACE_H))
#define SET_GPIO_HIF_INTERACE_H     		(LPC_GPIO2->FIOSET |= (1 << PH_EXHIF_GPIO_HIF_INTERACE_H))
#define CLEAR_GPIO_HIF_INTERACE_H   		(LPC_GPIO2->FIOCLR |= (1 << PH_EXHIF_GPIO_HIF_INTERACE_H))

#define SET_GPIO_COMM_CHANNEL_L_OUTPUT      (LPC_GPIO2->FIODIR |= (1 << PH_EXHIF_GPIO_COMM_CHANNEL_L))
#define SET_GPIO_COMM_CHANNEL_L     		(LPC_GPIO2->FIOSET |= (1 << PH_EXHIF_GPIO_COMM_CHANNEL_L))
#define CLEAR_GPIO_COMM_CHANNEL_L   		(LPC_GPIO2->FIOCLR |= (1 << PH_EXHIF_GPIO_COMM_CHANNEL_L))

#define SET_GPIO_COMM_CHANNEL_M_OUTPUT      (LPC_GPIO2->FIODIR |= (1 << PH_EXHIF_GPIO_COMM_CHANNEL_M))
#define SET_GPIO_COMM_CHANNEL_M     		(LPC_GPIO2->FIOSET |= (1 << PH_EXHIF_GPIO_COMM_CHANNEL_M))
#define CLEAR_GPIO_COMM_CHANNEL_M   		(LPC_GPIO2->FIOCLR |= (1 << PH_EXHIF_GPIO_COMM_CHANNEL_M))

#define SET_GPIO_COMM_CHANNEL_H_OUTPUT      (LPC_GPIO2->FIODIR |= (1 << PH_EXHIF_GPIO_COMM_CHANNEL_H))
#define SET_GPIO_COMM_CHANNEL_H     		(LPC_GPIO2->FIOSET |= (1 << PH_EXHIF_GPIO_COMM_CHANNEL_H))
#define CLEAR_GPIO_COMM_CHANNEL_H   		(LPC_GPIO2->FIOCLR |= (1 << PH_EXHIF_GPIO_COMM_CHANNEL_H))

#define RST_PIN 5
#define SET_RST_PIN_OUTPUT         (LPC_GPIO2->FIODIR |= (1 << RST_PIN))
#define SET_RST_PIN                (LPC_GPIO2->FIOSET |= (1 << RST_PIN))
#define CLEAR_RST_PIN              (LPC_GPIO2->FIOCLR |= (1 << RST_PIN))

#define SW1     24
#define SET_GPIO_SW1_OUTPUT     (LPC_GPIO0->FIODIR |= (1 << SW1))
#define SET_GPIO_SW1            (LPC_GPIO0->FIOSET |= (1 << SW1))
#define CLEAR_GPIO_SW1          (LPC_GPIO0->FIOCLR |= (1 << SW1))

#define SW2     25
#define SET_GPIO_SW2_OUTPUT     (LPC_GPIO0->FIODIR |= (1 << SW2))
#define SET_GPIO_SW2            (LPC_GPIO0->FIOSET |= (1 << SW2))
#define CLEAR_GPIO_SW2          (LPC_GPIO0->FIOCLR |= (1 << SW2))

#define SW3     26
#define SET_GPIO_SW3_OUTPUT     (LPC_GPIO0->FIODIR |= (1 << SW3))
#define SET_GPIO_SW3            (LPC_GPIO0->FIOSET |= (1 << SW3))
#define CLEAR_GPIO_SW3          (LPC_GPIO0->FIOCLR |= (1 << SW3))

#define SW4     23
#define SET_GPIO_SW4_OUTPUT     (LPC_GPIO0->FIODIR |= (1 << SW4))
#define SET_GPIO_SW4            (LPC_GPIO0->FIOSET |= (1 << SW4))
#define CLEAR_GPIO_SW4          (LPC_GPIO0->FIOCLR |= (1 << SW4))


/*I2C peripheral pins*/
#define LPC_I2C0_SDA_PIN    27
#define LPC_I2C0_SCL_PIN    28
#define LPC_I2C2_SDA_PIN    10
#define LPC_I2C2_SCL_PIN    11

/*SSP0 master interface LPC1769 Pins*/
#define SSP_PORT    0
#define SSP_MISO0   17
#define SSP_MOSI0   18
#define SSP_SCLK0   15
#define SSP_SSEL0   16

/*SSP1 slave of LPC1769 interface Pins*/
#define SSP_MISO1   9
#define SSP_MOSI1   8
#define SSP_SCLK1   7
#define SSP_SSEL1   6
#define BUFSIZE 1024

/* *****************************************************************************************************************
 * Types/Structure Declarations
 * ***************************************************************************************************************** */
/*Ports available*/
typedef enum
{
    Port0=0x000,
    Port1,
    Port2,
    Port3,
    Port4,
}GPIO_Port_t;

/** @brief UART Ring buffer structure */
typedef struct
{
    //__IO uint32_t tx_head;                /*!< UART Tx ring buffer head index */
    //__IO uint32_t tx_tail;                /*!< UART Tx ring buffer tail index */
    __IO uint32_t rx_head;                /*!< UART Rx ring buffer head index */
    __IO uint32_t rx_tail;                /*!< UART Rx ring buffer tail index */
    //__IO uint8_t  tx[UART_RING_BUFSIZE];  /*!< UART Tx data ring buffer */
    __IO uint8_t  rx[BUFSIZE];  /*!< UART Rx data ring buffer */
} UART_RING_BUFFER_T;

// RTS State
__IO int32_t RTS_State;

// Current Tx Interrupt enable state
__IO FlagStatus TxIntStat;


/***********************************************************************************************************************
 *                                      Local Variables
 **********************************************************************************************************************/
UART_RING_BUFFER_T rb;

/*Structure to setup the slave interface which is in Interrupt mode*/
volatile I2C_S_SETUP_Type I2C_SlaveCfg;

volatile SSP_DATA_SETUP_Type SSP_slave_cfg_t;

/*Variable used in the slave modules*/
uint8_t SlaveI2CTxBuffer[BUFSIZE];
uint8_t SlaveI2CRxBuffer[BUFSIZE];

uint8_t SlaveSPITxBuffer[BUFSIZE/2];
uint8_t SlaveSPIRxBuffer[BUFSIZE/2];

/* *****************************************************************************************************************
 * Function Prototypes
 * ***************************************************************************************************************** */
Bool lpc_ExHif_GetRxPin(void);
/*Configure I2C peripheral*/
void LPC_I2C_Init(LPC_I2C_TypeDef *, uint8_t , uint8_t, uint8_t , uint8_t, uint32_t);
void LPC_I2C_SlaveConfig(LPC_I2C_TypeDef *,uint8_t );
void Lpc_ExHIF_I2C_TxRx(LPC_I2C_TypeDef *I2Cx,uint8_t bCommChannel);

/*Configure SSP0 Peripheral*/
void SSP0_Init(uint8_t SSP_CPOL, uint8_t SSP_CPHA, uint32_t clockrate);
void SSP1_Init(uint8_t SSP_CPOL, uint8_t SSP_CPHA, uint32_t clockrate);
void SPI_Slave_Config(LPC_SSP_TypeDef *SSPx);
void Lpc_ExHIF_SPI_TxRx(LPC_SSP_TypeDef *SSPx,uint8_t bCommChannel);
/*Configure UART1 Peripheral*/
void UART1_Config(uint8_t Databits, uint8_t Stopbits,uint8_t parity,uint32_t dwClockrate);
void Lpc_ExHIF_HSUTxRx(LPC_UART_TypeDef *UARTx, uint8_t bCommChannel);

Status uart_set_divisorsNew(LPC_UART_TypeDef *UARTx, uint32_t baudrate);
