/*
 *                  Copyright (c), NXP Semiconductors
 *
 *                     (C)NXP Semiconductors
 *       All rights are reserved. Reproduction in whole or in part is
 *      prohibited without the written consent of the copyright owner.
 *  NXP reserves the right to make changes without notice at any time.
 * NXP makes no warranty, expressed, implied or statutory, including but
 * not limited to any implied warranty of merchantability or fitness for any
 *particular purpose, or that the use will not infringe any third party patent,
 * copyright or trademark. NXP must not be liable for any loss or damage
 *                          arising from its use.
 */

/** \file
 * lpc17xx_libcfg_default.h
 * $Author: nxp47613 $
 * $Revision: 001 $
 * $Date: 2013-07-26 10:28:17 +0530 (Fri, 26 Jul 2013) $
 *
 * History:
 *
 */

#ifndef LPC17XX_LIBCFG_DEFAULT_H_
#define LPC17XX_LIBCFG_DEFAULT_H_

#include "lpc_types.h"


/* DEBUG_FRAMWORK ------------------------------ */
#define _DBGFWK

/* GPIO ------------------------------- */
#define _GPIO

/* EXTI ------------------------------- */
#define _EXTI

/* UART ------------------------------- */
#define _UART
#define _UART0
#define _UART1
#define _UART2
#define _UART3

/* SPI ------------------------------- */
#define _SPI

/* SYSTICK --------------------------- */
#define _SYSTICK

/* SSP ------------------------------- */
#define _SSP
#define _SSP0
#define _SSP1


/* I2C ------------------------------- */
#define _I2C
#define _I2C0
#define _I2C1
#define _I2C2

/* TIMER ------------------------------- */
#define _TIM

/* WDT ------------------------------- */
#define _WDT


/* GPDMA ------------------------------- */
#define _GPDMA


/* DAC ------------------------------- */
#define _DAC

/* DAC ------------------------------- */
#define _ADC


/* PWM ------------------------------- */
#define _PWM
#define _PWM1

/* RTC ------------------------------- */
#define _RTC

/* I2S ------------------------------- */
#define _I2S

/* USB device ------------------------------- */
#define _USBDEV
#define _USB_DMA

/* QEI ------------------------------- */
#define _QEI

/* MCPWM ------------------------------- */
#define _MCPWM

/* CAN--------------------------------*/
#define _CAN

/* RIT ------------------------------- */
#define _RIT

/* EMAC ------------------------------ */
#define _EMAC


#ifdef  DEBUG
#define CHECK_PARAM(expr) ((expr) ? (void)0 : check_failed((uint8_t *)__FILE__, __LINE__))
#else
#define CHECK_PARAM(expr)
#endif /* DEBUG */


#ifdef  DEBUG
void check_failed(uint8_t *file, uint32_t line);
#endif

#endif /* LPC17XX_LIBCFG_DEFAULT_H_ */
