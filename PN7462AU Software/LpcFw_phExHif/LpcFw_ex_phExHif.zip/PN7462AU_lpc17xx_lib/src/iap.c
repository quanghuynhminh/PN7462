/*
 *                  Copyright (c), NXP Semiconductors
 *
 *                     (C)NXP Semiconductors
 *       All rights are reserved. Reproduction in whole or in part is
 *      prohibited without the written consent of the copyright owner.
 *  NXP reserves the right to make changes without notice at any time.
 * NXP makes no warranty, expressed, implied or statutory, including but
 * not limited to any implied warranty of merchantability or fitness for any
 *particular purpose, or that the use will not infringe any third party patent,
 * copyright or trademark. NXP must not be liable for any loss or damage
 *                          arising from its use.
 */

/** \file
 * iap.c
 * $Author: nxp47613 $
 * $Revision: 001 $
 * $Date: 2013-07-26 10:28:17 +0530 (Fri, 26 Jul 2013) $
 *
 * History:
 *
 */
#include "type.h"
#include "iap.h"
#include "LPC17xx.h"

/* Routine to erase the sectors */
uint32_t IAP_erase_sector(unsigned start_sector,unsigned end_sector,unsigned cclk)
{
    uint32_t param_table[8];
    uint32_t result_table[8];
    param_table[0] = ERASE_SECTOR;
    param_table[1] = start_sector;
    param_table[2] = end_sector;
    param_table[3] = cclk;
    IAP_EXECUTE_CMD(param_table,result_table);
    return result_table[0];
}

/* Routine to prepare the sectors for writing */
uint32_t IAP_prepare_sector(unsigned start_sector,unsigned end_sector,unsigned cclk)
{
    uint32_t param_table[8];
    uint32_t result_table[8];
    param_table[0] = PREPARE_SECTOR_FOR_WRITE;
    param_table[1] = start_sector;
    param_table[2] = end_sector;
    param_table[3] = cclk;
    IAP_EXECUTE_CMD(param_table,result_table);
    return result_table[0];
}

/* Routine to check for blank */
uint32_t IAP_blank_check_sector(unsigned start_sector,unsigned end_sector)
{
    uint32_t param_table[8];
    uint32_t result_table[8];
    param_table[0] = BLANK_CHECK_SECTOR;
    param_table[1] = start_sector;
    param_table[2] = end_sector;
    IAP_EXECUTE_CMD(param_table,result_table);
    return result_table[0];
}

/* Routine to write data onto the sector */
uint32_t IAP_write_data(unsigned flash_address,unsigned * flash_data_buf, unsigned count, unsigned cclk)
{
    uint32_t param_table[8];
    uint32_t result_table[8];
    param_table[0] = COPY_RAM_TO_FLASH;
    param_table[1] = flash_address;
    param_table[2] = (unsigned)flash_data_buf;
    param_table[3] = count;
    param_table[4] = cclk;
    IAP_EXECUTE_CMD(param_table,result_table);
    return result_table[0];
}

/* Routine to erase entire user flash(Sector 16 to end of flash memory) */
void erase_user_flash(void)
{
   do
   {
      IAP_prepare_sector(USER_START_SECTOR,(USER_START_SECTOR + 1),SystemCoreClock/1000);
      IAP_erase_sector(USER_START_SECTOR,(USER_START_SECTOR + 1),SystemCoreClock/1000);
   }while(IAP_blank_check_sector(USER_START_SECTOR,USER_START_SECTOR) != CMD_SUCCESS);
}

/*
 * Routine to update the IAP entry location
 * This used to enter the bootloader mode via software mode
 */
void update_iap_entry_location(char val)
{
   uint8_t flash_buf[256];
   flash_buf[IAP_ENTRY_FLASH_SECTOR_SIZE - 1] = val;
   IAP_prepare_sector(IAP_ENTRY_FLASH_SECTOR_NR, IAP_ENTRY_FLASH_SECTOR_NR, SystemCoreClock/1000);
   IAP_erase_sector(IAP_ENTRY_FLASH_SECTOR_NR, IAP_ENTRY_FLASH_SECTOR_NR, SystemCoreClock/1000);

   IAP_prepare_sector(IAP_ENTRY_FLASH_SECTOR_NR, IAP_ENTRY_FLASH_SECTOR_NR, SystemCoreClock/1000);
   IAP_write_data((unsigned)IAP_ENTRY_FLASH_SECTOR_START_ADDR,(unsigned *)flash_buf, IAP_ENTRY_FLASH_SECTOR_SIZE, (SystemCoreClock/1000));
}
