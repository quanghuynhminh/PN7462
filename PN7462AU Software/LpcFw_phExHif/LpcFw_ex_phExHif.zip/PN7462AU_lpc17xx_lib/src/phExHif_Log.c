/*
 *                    Copyright (c), NXP Semiconductors
 *
 *                       (C) NXP Semiconductors 2014
 *
 *         All rights are reserved. Reproduction in whole or in part is
 *        prohibited without the written consent of the copyright owner.
 *    NXP reserves the right to make changes without notice at any time.
 *   NXP makes no warranty, expressed, implied or statutory, including but
 *   not limited to any implied warranty of merchantability or fitness for any
 *  particular purpose, or that the use will not infringe any third party patent,
 *   copyright or trademark. NXP must not be liable for any loss or damage
 *                            arising from its use.
 */

/** @file
 *
 * @todo Describe purpose and scope of this file
 *
 * Project:  PN640
 *
 * $Date: 2014-09-24 20:34:36 +0530 (Wed, 24 Sep 2014) $
 * $Author: Purnank H G (ing05193) $
 * $Revision: 7254 $
 */



/* *****************************************************************************************************************
 * Includes
 * ***************************************************************************************************************** */
#include "phExHif_Log.h"

/* *****************************************************************************************************************
 * Internal Definitions
 * ***************************************************************************************************************** */
#define LOG_CASE_ENUM(BR,STR) \
    case((BR)): LOG_TXT(STR); break

/* *****************************************************************************************************************
 * Type Definitions
 * ***************************************************************************************************************** */

/* *****************************************************************************************************************
 * Global and Static Variables
 * Total Size: NNNbytes
 * ***************************************************************************************************************** */

/* *****************************************************************************************************************
 * Private Functions Prototypes
 * ***************************************************************************************************************** */

/* *****************************************************************************************************************
 * Public Functions
 * ***************************************************************************************************************** */
#if PHEXHIF_ENABLE_LOG

#define ENTRIES_IN_ONE_ROW                     16  /* Should be multiple of 4 */
#define ENTRIES_IN_ONE_COLUMN_OF_A_ROW          4  /* Should be a factor of ENTRIES_IN_ONE_ROW */

void phExHif_Log_AU8(uint8_t * inBuf, const uint32_t inBufLen) {
    uint32_t i;

    printf("\tLen=%d\n\t\t",inBufLen);
    for (i = 0 ; i < inBufLen; i++) {
    	printf(" %02X",inBuf[i]);

        if ( ((i+1) % ENTRIES_IN_ONE_COLUMN_OF_A_ROW) == 0 ) {
        	printf("\t");
        }
        if (((i+1) % ENTRIES_IN_ONE_ROW) == 0 ) {
        	printf("\n\t\t");
        }
    }
	printf("\n");
}

#endif /* PHEXHIF_ENABLE_LOG */

/* *****************************************************************************************************************
 * Private Functions
 * ***************************************************************************************************************** */

