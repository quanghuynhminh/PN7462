/* *****************************************************************************************************************
 * Includes
 * ***************************************************************************************************************** */
#include "lpcExHif.h"
#include "lpcExHif_config.h"
#include "delay.h"
/* *****************************************************************************************************************
 * Internal Definitions
 * ***************************************************************************************************************** */

/* *****************************************************************************************************************
 * Private Functions Prototypes
 * ***************************************************************************************************************** */
void lpcExHif_Switch_I2C(void)
{
    /*Switching supported for only Performance board*/
    SET_GPIO_SW1_OUTPUT;
    CLEAR_GPIO_SW1;
    SET_GPIO_SW2_OUTPUT;
    CLEAR_GPIO_SW2;
    SET_GPIO_SW3_OUTPUT;
    SET_GPIO_SW3;
    SET_GPIO_SW4_OUTPUT;
    CLEAR_GPIO_SW4;
}

void lpcExHif_Switch_SPI(void)
{
    /*Switching supported for only Performance board*/
    SET_GPIO_SW1_OUTPUT;
    CLEAR_GPIO_SW1;
    SET_GPIO_SW2_OUTPUT;
    CLEAR_GPIO_SW2;
    SET_GPIO_SW3_OUTPUT;
    CLEAR_GPIO_SW3;
    SET_GPIO_SW4_OUTPUT;
    CLEAR_GPIO_SW4;
}

void lpcExHif_Switch_HSU(void)
{
    /*Switching supported for only Performance board*/
    SET_GPIO_SW1_OUTPUT;
    CLEAR_GPIO_SW1;
    SET_GPIO_SW2_OUTPUT;
    SET_GPIO_SW2;
    SET_GPIO_SW3_OUTPUT;
    SET_GPIO_SW3;
    SET_GPIO_SW4_OUTPUT;
    CLEAR_GPIO_SW4;
}

/* *****************************************************************************************************************
 * Public Functions
 * ***************************************************************************************************************** */


void lpcExHif_InitInterface(uint8_t bHifInterface)
{

    LPC_EXHIF_ASSERT(bHifInterface);


    switch(bHifInterface)
    {
        case ONE:

            /*Configure the switches to I2C in PN640 Board*/
            lpcExHif_Switch_I2C();

            /*Configure I2C0 as Master*/
            LPC_I2C_Init(LPC_I2C0,ONE,Port0,LPC_I2C0_SDA_PIN,LPC_I2C0_SCL_PIN,LPC_EXHIF_I2C_MASTER_DATARATE);

            /*I2C Config*/
            SET_GPIO_HIF_INTERACE_L;
            CLEAR_GPIO_HIF_INTERACE_H;
            break;
        case TWO:

            /*Configure the switches to SPI in PN640 Board*/
            lpcExHif_Switch_SPI();

            /*Configure SPI0 as Master*/
            SSP0_Init(LPC_EXHIF_SPI_CPOL,LPC_EXHIF_SPI_CPHA,LPC_EXHIF_SPIM_DATARATE);

            /*SPI Config*/
			CLEAR_GPIO_HIF_INTERACE_L;
			SET_GPIO_HIF_INTERACE_H;
            break;
        case THREE:

            /*Configure the switches to HSU in PN640 Perf Board*/
            lpcExHif_Switch_HSU();

            /*Configure UART1*/
            UART1_Config(LPC_EXHIF_HSU_DATABITS,LPC_EXHIF_HSU_STOPBITS,LPC_EXHIF_HSU_PARITY,LPC_EXHIF_HSU_DATARATE);

            /*HSU Config*/
			SET_GPIO_HIF_INTERACE_L;
			SET_GPIO_HIF_INTERACE_H;

            break;
        default:    /*It should not reach this point*/
            LPC_EXHIF_ASSERT(bHifInterface);
            break;
    }
}

void lpcExHif_InitCommChannel(uint8_t bHifInterface,uint8_t bHifCommChannel )
{

    CLEAR_GPIO_COMM_CHANNEL_L;
    CLEAR_GPIO_COMM_CHANNEL_M;
    CLEAR_GPIO_COMM_CHANNEL_H;

    if(((bHifCommChannel & PH_EXHIF_I2CM) == PH_EXHIF_I2CM) && (bHifCommChannel != PH_EXHIF_FLASH_WRITE) )
    {
        /*Configure GPIO for I2C slave communication channel*/
        SET_GPIO_COMM_CHANNEL_L;


        /*Config I2C Slave for reception*/
        LPC_I2C_Init(LPC_I2C2,TWO,Port0,LPC_I2C2_SDA_PIN,LPC_I2C2_SCL_PIN,LPC_EXHIF_I2C_SLAVE_DATARATE);
        LPC_I2C_SlaveConfig(LPC_I2C2,LPC_EXHIF_I2C_SLAVE_ADDR);
        NVIC_SetPriority(I2C0_IRQn, ((0x01<<4)|0x01));
    }

    if((bHifCommChannel & PH_EXHIF_SPIM) == PH_EXHIF_SPIM)
    {
        /*Configure GPIO for SPI slave communication channel*/
        SET_GPIO_COMM_CHANNEL_M;

        /*Config SPI slave for reception*/
        SSP1_Init(LPC_EXHIF_SPI_CPOL,LPC_EXHIF_SPI_CPHA,LPC_EXHIF_SPIS_DATARATE);

        /*Used to enable slave transmit data*/
        SSP_SlaveOutputCmd(LPC_SSP1,ENABLE);
        SPI_Slave_Config(LPC_SSP1);
        NVIC_EnableIRQ(SSP1_IRQn);
        NVIC_SetPriority(SSP1_IRQn, ((0x01<<3)|0x01));

    }

    if(bHifCommChannel == PH_EXHIF_EEPROM_WRITE)
    {
    	SET_GPIO_COMM_CHANNEL_H;
    }

    if(bHifCommChannel == PH_EXHIF_FLASH_WRITE)
    {
    	SET_GPIO_COMM_CHANNEL_H;
    	SET_GPIO_COMM_CHANNEL_L;
    }

    if(bHifCommChannel == PH_EXHIF_CT_TRANSACTION)
    {
        SET_GPIO_COMM_CHANNEL_H;
        SET_GPIO_COMM_CHANNEL_M;
    }

    /*Perform the transaction*/
    lpcExHif_TxRx(bHifInterface,bHifCommChannel );

}

void lpcExHif_TxRx(uint8_t bInterface, uint8_t bCommChannel)
{

    switch(bInterface)
    {
        case 1:
            /*I2C TxRx API needs to be called*/
            Lpc_ExHIF_I2C_TxRx(LPC_I2C0,bCommChannel);
            break;
        case 2:
            /*SPI TxRx API needs to be called*/
        Lpc_ExHIF_SPI_TxRx(LPC_SSP0, bCommChannel);
            break;
        case 3:
            /*HSU TxRx API needs to be called*/
            Lpc_ExHIF_HSUTxRx((LPC_UART_TypeDef *)LPC_UART1,bCommChannel);
            break;
        default:
            LPC_EXHIF_ASSERT(bInterface);
            break;
    }
}
