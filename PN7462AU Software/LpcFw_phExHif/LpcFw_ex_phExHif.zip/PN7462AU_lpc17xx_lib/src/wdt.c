/*
 *                  Copyright (c), NXP Semiconductors
 *
 *                     (C)NXP Semiconductors
 *       All rights are reserved. Reproduction in whole or in part is
 *      prohibited without the written consent of the copyright owner.
 *  NXP reserves the right to make changes without notice at any time.
 * NXP makes no warranty, expressed, implied or statutory, including but
 * not limited to any implied warranty of merchantability or fitness for any
 *particular purpose, or that the use will not infringe any third party patent,
 * copyright or trademark. NXP must not be liable for any loss or damage
 *                          arising from its use.
 */

/* \file
 * wdt.c
 * $Author: nxp47613 $
 * $Revision: 001 $
 * $Date: 2013-07-26 10:28:17 +0530 (Fri, 26 Jul 2013) $
 *
 * History:
 *
 */
#include "LPC17xx.h"
#include "type.h"
#include "wdt.h"
#include "lpcusb_type.h"

/* WDT Handler */
void WDT_IRQHandler(void)
{
  return;
}

/* WDT Initialisation routine */
uint32_t WDTInit( void )
{
  LPC_WDT->WDTC = WDT_FEED_VALUE;   /* once WDEN is set, the WDT will start after feeding */
  LPC_WDT->WDMOD = WDEN;// | WDRESET;

  LPC_WDT->WDFEED = 0xAA;       /* Feeding sequence */
  LPC_WDT->WDFEED = 0x55;

  NVIC_EnableIRQ(WDT_IRQn);

  return( TRUE );
}

/* WDT Feed routine */
void WDTFeed( void )
{
  LPC_WDT->WDFEED = 0xAA;       /* Feeding sequence */
  LPC_WDT->WDFEED = 0x55;
  return;
}

/* Force system reset upon feed expire */
void WDTForceSysRst( void )
{
    LPC_WDT->WDTC = WDT_FEED_VALUE; /* once WDEN is set, the WDT will start after feeding */
    LPC_WDT->WDMOD = WDEN | WDRESET;

    LPC_WDT->WDFEED = 0xAA; /* Feeding sequence */
    LPC_WDT->WDFEED = 0x55;
}
