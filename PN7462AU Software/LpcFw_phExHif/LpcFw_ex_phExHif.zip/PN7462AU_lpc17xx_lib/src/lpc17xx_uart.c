/**
 * @file        : lpc17xx_uart.c
 * @brief       : Contains all functions support for UART firmware library on LPC17xx
 * @version     : 1.0
 * @date        : 18. Mar. 2009
 * @author      : HieuNguyen
 **************************************************************************
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * products. This software is supplied "AS IS" without any warranties.
 * NXP Semiconductors assumes no responsibility or liability for the
 * use of the software, conveys no license or title under any patent,
 * copyright, or mask work right to the product. NXP Semiconductors
 * reserves the right to make changes in the software without
 * notification. NXP Semiconductors also make no representation or
 * warranty that such application will be suitable for the specified
 * use without further testing or modification.
 **********************************************************************/

/* Peripheral group ----------------------------------------------------------- */
/** @addtogroup UART
 * @{
 */

/* Includes ------------------------------------------------------------------- */
#include "lpc17xx_uart.h"
#include "lpc17xx_clkpwr.h"

/* If this source file built with example, the LPC17xx FW library configuration
 * file in each example directory ("lpc17xx_libcfg.h") must be included,
 * otherwise the default FW library configuration file must be included instead
 */
#ifdef __BUILD_WITH_EXAMPLE__
#include "lpc17xx_libcfg.h"
#else
#include "lpc17xx_libcfg_default.h"
#endif /* __BUILD_WITH_EXAMPLE__ */


#ifdef _UART

/* Private Types -------------------------------------------------------------- */
/** @defgroup UART_Private_Types
 * @{
 */

/**
 * @brief UART call-back function type definitions
 */
typedef struct {
    fnTxCbs_Type *pfnTxCbs;         // Transmit callback
    fnRxCbs_Type *pfnRxCbs;         // Receive callback
    fnABCbs_Type *pfnABCbs;         // Auto-Baudrate callback
    fnErrCbs_Type *pfnErrCbs;       // Error callback
} UART_CBS_Type;

/**
 * @}
 */


/* Private Variables ---------------------------------------------------------- */
/** @defgroup UART_Private_Variables
 * @{
 */


/** Call-back function pointer data */
UART_CBS_Type uartCbsDat[4] = {
        {NULL, NULL, NULL, NULL},
        {NULL, NULL, NULL, NULL},
        {NULL, NULL, NULL, NULL},
        {NULL, NULL, NULL, NULL},
};

/** UART1 modem status interrupt callback pointer data */
fnModemCbs_Type *pfnModemCbs = NULL;

/**
 * @}
 */


/* Private Functions ---------------------------------------------------------- */
/** @defgroup UART_Private_Functions
 * @{
 */

/**
 * @brief               Get UART number due to UART peripheral pointer
 * @param[in]   UARTx   UART pointer
 * @return              UART number
 */
uint8_t getUartNum(LPC_UART_TypeDef *UARTx) {
    if (UARTx == LPC_UART0) return (0);
    else if (UARTx == (LPC_UART_TypeDef *)LPC_UART1) return (1);
    else if (UARTx == LPC_UART2) return (2);
    else return (3);
}

/* PCLK is set to 100MHz. */
#define PLL_DIV_VAL (100000000UL/16UL)


Status Calculate_FDR(const uint32_t baudrate, volatile uint8_t *DLL, volatile uint8_t *ADDDIV, volatile uint8_t *MUL)
{
    double dwReqVal, dDiv, error, maxError = 0.001;

    dwReqVal = ((float)PLL_DIV_VAL)/((float)baudrate);

    for(*DLL = 1; *DLL <= 0x0F; (*DLL)++){
        for(*ADDDIV = 0; *ADDDIV <= 0x0F; (*ADDDIV)++){
            for(*MUL = 1; *MUL <= 0x0F; (*MUL)++){

                dDiv = ((float)*ADDDIV)/((float)*MUL);
                dDiv += (float)1;
                dDiv *= *DLL;

                if(dwReqVal == dDiv){
                    return SUCCESS;
                }else if(dwReqVal > dDiv){
                    error = dwReqVal - dDiv;
                    if(error < maxError)
                        return SUCCESS;

                }else{
                    error =  dDiv - dwReqVal ;
                    if(error < maxError)
                        return SUCCESS;
                }
            }
        }
    }

    return ERROR;
}

#ifdef LPC17XX_2_10
/**
 * @brief   Enable access to Divisor Latches
 * @param   pUART   : Pointer to selected UART peripheral
 * @return  Nothing
 */
void Chip_UART_EnableDivisorAccess(LPC_UART_TypeDef *pUART)
{
    pUART->LCR |= UART_LCR_DLAB_EN;
}

/**
 * @brief   Disable access to Divisor Latches
 * @param   pUART   : Pointer to selected UART peripheral
 * @return  Nothing
 */
void Chip_UART_DisableDivisorAccess(LPC_UART_TypeDef *pUART)
{
    pUART->LCR &= ~UART_LCR_DLAB_EN;
}

/**
 * @brief   Set LSB and MSB divisor latch registers
 * @param   pUART   : Pointer to selected UART peripheral
 * @param   dll     : Divisor Latch LSB value
 * @param   dlm     : Divisor Latch MSB value
 * @return  Nothing
 * @note    The Divisor Latch Access Bit (DLAB) in LCR must be set in
 *          order to access the USART Divisor Latches. This function
 *          doesn't alter the DLAB state.
 */
void Chip_UART_SetDivisorLatches(LPC_UART_TypeDef *pUART, uint8_t dll, uint8_t dlm)
{
    pUART->DLL = (uint32_t) dll;
    pUART->DLM = (uint32_t) dlm;
}

Status uart_set_divisors(LPC_UART_TypeDef *pUART, uint32_t baudrate)
{
    uint32_t uClk;
    uint32_t actualRate = 0, d, m, bestd, bestm, tmp;
    uint32_t current_error, best_error;
    uint64_t best_divisor, divisor;
    uint32_t recalcbaud;

    /* Get Clock rate */
    uClk = CLKPWR_GetPCLK (CLKPWR_PCLKSEL_UART1);

    /* In the Uart IP block, baud rate is calculated using FDR and DLL-DLM registers
    * The formula is :
    * BaudRate= uClk * (mulFracDiv/(mulFracDiv+dividerAddFracDiv) / (16 * (DLL)
    * It involves floating point calculations. That's the reason the formulae are adjusted with
    * Multiply and divide method.*/
    /* The value of mulFracDiv and dividerAddFracDiv should comply to the following expressions:
    * 0 < mulFracDiv <= 15, 0 <= dividerAddFracDiv <= 15 */
    best_error = 0xFFFFFFFF;// 0x0000C350;/* Worst case */
    bestd = 0;
    bestm = 0;
    best_divisor = 0;
    for (m = 1; m <= 15; m++) {
           for (d = 0; d < m; d++) {

                  /*   The result here is a fixed point number.  The integer portion is in the upper 32 bits.
                  * The fractional portion is in the lower 32 bits.
                  */
                  divisor = ((uint64_t) uClk << 28) * m / (baudrate * (m + d));

                  /*   The fractional portion is the error. */
                  current_error = divisor & 0xFFFFFFFF;

                  /*   Snag the integer portion of the divisor. */
                  tmp = divisor >> 32;

                  /*   If closer to the next divisor... */
                  if (current_error > ((uint32_t) 1 << 31)) {

                        /* Increment to the next divisor... */
                        tmp++;

                        /* Now the error is the distance to the next divisor... */
                        current_error = -current_error;
                  }

                  /*   Can't use a divisor that's less than 1 or more than 65535. */
                  if ((tmp < 1) || (tmp > 65535)) {
                        /* Out of range */
                        continue;
                  }

                  /*   Also, if fractional divider is enabled can't use a divisor that is less than 3. */
                  if ((d != 0) && (tmp < 3)) {
                        /* Out of range */
                        continue;
                  }

                  /*   Do we have a new best? */
                  if (current_error < best_error) {
                        best_error = current_error;
                        best_divisor = tmp;
                        bestd = d;
                        bestm = m;

                        /*   If error is 0, that's perfect.  We're done. */
                        if (best_error == 0) {
                               break;
                        }
                  }
           }      /* for (d) */

           /*   If error is 0, that's perfect.  We're done. */
           if (best_error == 0) {
                  break;
           }
    }      /* for (m) */

    if (best_divisor == 0) {
           /* can not find best match */
           return 0;
    }

    recalcbaud = (uClk >> 4) * bestm / (best_divisor * (bestm + bestd));

    /* reuse best_error to evaluate baud error */
    if (baudrate > recalcbaud) {
           best_error = baudrate - recalcbaud;
    }
    else {
           best_error = recalcbaud - baudrate;
    }

    best_error = (best_error * 100) / baudrate;

 /* Update UART registers */
    Chip_UART_EnableDivisorAccess(pUART);
    Chip_UART_SetDivisorLatches(pUART, UART_LOAD_DLL(best_divisor), UART_LOAD_DLM(best_divisor));
    Chip_UART_DisableDivisorAccess(pUART);

    /* Set best fractional divider */
    pUART->FDR = (UART_FDR_MULVAL(bestm) | UART_FDR_DIVADDVAL(bestd));

    /* Return actual baud rate */
    actualRate = recalcbaud;

    return actualRate;
}
#endif

#ifdef LPC17XX_OLD
/*********************private functions for the old drivers**********************************/

void CoreFrequency_FeedPll(void)
{
    LPC_SC->PLL0FEED  = 0xAA;
    LPC_SC->PLL0FEED  = 0x55;
}
uint8_t CoreFrequency_Set(uint32_t newFrequency)
{
    struct lut_cf_el
    {
        uint32_t    FCore;
        uint16_t    M;
        uint8_t     N;
        uint8_t     CClkSel;
    };

    const struct lut_cf_el lut[] =
    {
        {60000000, 59, 3, 5},
        {61000000, 60, 3, 5},
        {62000000, 61, 3, 5},
        {63000000, 62, 3, 5},
        {64000000, 63, 3, 5},
        {65000000, 64, 3, 5},
        {66000000, 65, 3, 5},
        {67000000, 66, 3, 5},
        {68000000, 67, 3, 5},
        {69000000, 68, 3, 5},
        {70000000, 69, 3, 5},
        {71000000, 70, 3, 5},
        {72000000, 71, 3, 5},
        {73000000, 72, 3, 5},
        {74000000, 73, 3, 5},
        {75000000, 74, 3, 5},
        {76000000, 75, 3, 5},
        {77000000, 76, 3, 5},
        {78000000, 77, 3, 5},
        {79000000, 78, 3, 5},
        {80000000, 79, 3, 5},
        {81000000, 80, 3, 5},
        {82000000, 81, 3, 5},
        {83000000, 82, 3, 5},
        {84000000, 83, 3, 5},
        {85000000, 84, 3, 5},
        {86000000, 85, 3, 5},
        {87000000, 86, 3, 5},
        {88000000, 87, 3, 5},
        {89000000, 88, 3, 5},
        {90000000, 89, 3, 5},
        {91000000, 90, 5, 3},
        {92000000, 91, 5, 3},
        {93000000, 61, 3, 3},
        {94000000, 93, 5, 3},
        {95000000, 94, 5, 3},
        {96000000, 63, 3, 3},
        {97000000, 96, 5, 3},
        {98000000, 97, 5, 3},
        {99000000, 65, 3, 3},
        {100000000, 99, 5, 3},
        {101000000, 100, 5, 3},
        {102000000, 67, 3, 3},
        {103000000, 102, 5, 3},
        {104000000, 103, 5, 3},
        {105000000, 69, 3, 3},
        {106000000, 105, 5, 3},
        {107000000, 106, 5, 3},
        {108000000, 71, 3, 3},
        {109000000, 108, 5, 3},
        {110000000, 109, 5, 3},
        {111000000, 73, 3, 3},
        {112000000, 111, 5, 3},
        {113000000, 112, 5, 3},
        {114000000, 75, 3, 3},
        {115000000, 114, 5, 3},
        {116000000, 115, 5, 3},
        {117000000, 77, 3, 3},
        {118000000, 117, 5, 3},
        {119000000, 118, 5, 3},
        {120000000, 79, 3, 3}
    };
    const size_t lut_size = sizeof(lut) / sizeof(struct lut_cf_el);

    uint8_t ret = 0;
    struct lut_cf_el *lut_p = NULL;
    size_t i;

    for (i = 0; i < lut_size; i++)
    {
        if (lut[i].FCore == newFrequency)
        {
            lut_p = (struct lut_cf_el*)&lut[i];
            break;
        }
    }

    if ((NULL != lut_p) && (newFrequency != SystemCoreClock))
    {
        // Mask Interrupts, prevent exceptions
        __asm volatile
        (
            "cpsid   i  \n"
        );

        // Set CPU frequency:
        LPC_SC->PLL0CON = 0x01u; // Disconnect PLL
        CoreFrequency_FeedPll();
        while ((LPC_SC->PLL0STAT & (1<<25))); // Wait for disconnect
        LPC_SC->PLL0CON = 0x00u; // Disable PLL
        CoreFrequency_FeedPll();
        while ((LPC_SC->PLL0STAT & (1<<24))); // Wait for disable
        LPC_SC->CCLKCFG = lut_p->CClkSel; // Clock sel
        LPC_SC->PLL0CFG = lut_p->M;
        LPC_SC->PLL0CFG |= (((uint32_t)(lut_p->N)) << 16);
        CoreFrequency_FeedPll();
        LPC_SC->PLL0CON = 0x01u; // Re-Enable PLL
        CoreFrequency_FeedPll();
        while (!(LPC_SC->PLL0STAT & (1<<26))); // Wait for PLOCK0
        LPC_SC->PLL0CON = 0x03u; // Connect PLL
        CoreFrequency_FeedPll();
        while (!(LPC_SC->PLL0STAT & ((1<<25) | (1<<24)))); // Wait for PLLC0_STAT & PLLE0_STAT

        // Update of clock frequency needed!
        SystemCoreClockUpdate();


        // Un-Mask Interrupts, allow exceptions
        __asm volatile
        (
            "cpsie   i  \n"
        );
    }

    return ret;
}

uint8_t FracBd_Range(uint32_t reqBaudRate, uint32_t compBaudRate, uint8_t closeMatch)
{
    const uint32_t d_1_5_p = 67u; // 1.5%
    uint8_t ret = 0;

    if (0 == closeMatch)
    {
        // Exact Match
        if (reqBaudRate == compBaudRate)
        {
            ret = 1u;
        } else
        {
            ret = 0;
        }
    } else
    {
        // Close match only
        uint32_t upper_lim = reqBaudRate + (reqBaudRate / d_1_5_p);
        uint32_t lower_lim = reqBaudRate - (reqBaudRate / d_1_5_p);

        if ((compBaudRate >= lower_lim) && (compBaudRate <= upper_lim))
        {
            ret = 1u;
        } else
        {
            ret = 0;
        }
    }

    return ret;
}

// ________________________________________________________________________________________________
//
// IMPLEMENTATION
// ________________________________________________________________________________________________

uint8_t FracBd_GetSettingsForBaudrate(uint32_t baudRate, uint32_t pClk, uint8_t *dLL, uint8_t *dLM, uint8_t *divAddVal, uint8_t *mulVal)
{
    struct lut_el
    {
        float       fr;     // Fraction
        uint8_t     dav;    // DivAddVal
        uint8_t     mv;     // MulVal
    };

    const struct lut_el lut[] =
    {
        {1.000, 0,  1}, // Start of list

        {1.000, 0,  1},
        {1.067, 1,  15},
        {1.071, 1,  14},
        {1.077, 1,  13},
        {1.083, 1,  12},
        {1.091, 1,  11},
        {1.100, 1,  10},
        {1.111, 1,  9},
        {1.125, 1,  8},
        {1.133, 2,  15},
        {1.143, 1,  7},
        {1.154, 2,  13},
        {1.167, 1,  6},
        {1.182, 2,  11},
        {1.200, 1,  5},
        {1.214, 3,  14},
        {1.222, 2,  9},
        {1.231, 3,  13},
        {1.250, 1,  4},
        {1.267, 4,  15},
        {1.273, 3,  11},
        {1.286, 2,  7},
        {1.300, 3,  10},
        {1.308, 4,  13},
        {1.333, 1,  3},
        {1.357, 5,  14},
        {1.364, 4,  11},
        {1.375, 3,  8},
        {1.385, 5,  13},
        {1.400, 2,  5},
        {1.417, 5,  12},
        {1.429, 3,  7},
        {1.444, 4,  9},
        {1.455, 5,  11},
        {1.462, 6,  13},
        {1.467, 7,  15},
        {1.500, 1,  2},
        {1.533, 8,  15},
        {1.538, 7,  13},
        {1.545, 6,  11},
        {1.556, 5,  9},
        {1.571, 4,  7},
        {1.583, 7,  12},
        {1.600, 3,  5},
        {1.615, 8,  13},
        {1.625, 5,  8},
        {1.636, 7,  11},
        {1.643, 9,  14},
        {1.667, 2,  3},
        {1.692, 9,  13},
        {1.700, 7,  10},
        {1.714, 5,  7},
        {1.727, 8,  11},
        {1.733, 11, 15},
        {1.750, 3,  4},
        {1.769, 10, 13},
        {1.778, 7,  9},
        {1.786, 11, 14},
        {1.800, 4,  5},
        {1.818, 9,  11},
        {1.833, 5,  6},
        {1.846, 11, 13},
        {1.857, 6,  7},
        {1.867, 13, 15},
        {1.875, 7,  8},
        {1.889, 8,  9},
        {1.900, 9,  10},
        {1.909, 10, 11},
        {1.917, 11, 12},
        {1.923, 12, 13},
        {1.929, 13, 14},
        {1.933, 14, 15},

        {1.933, 14, 15} // End Of List
    };
    const uint8_t lut_size = (uint8_t)(sizeof(lut) / sizeof(struct lut_el));

    const float min_val = lut[0].fr;
    const float max_val = lut[lut_size - 1].fr;

    uint32_t pclk     = pClk;
    uint32_t baudrate = baudRate;

    uint8_t     ret = 0;

    float       dl_est      = 3;
    float       fr_est      = 1.5;
    uint8_t     divaddval   = 0;
    uint8_t     mulval      = 1u;

    uint8_t     dll = 1u;
    uint8_t     dlm = 0;

    dl_est = (pclk / (16 * baudrate));
    if (0 == (pclk % (16 * baudrate)))
    {
        // OK, we are done, we got an integer
        divaddval   = 0;
        mulval      = 1;
    } else
    {
        uint8_t once      = 1u;
        uint8_t lut_index = 1u;
        do
        {
            if (0 != once)
            {
                fr_est = 1.5;
                once = 0;
            } else
            {
                if (lut_index < lut_size)
                {
                    // Pick another value from the table
                    fr_est = lut[lut_index].fr;
                    lut_index++;
                } else
                {
                    // We are done with the LUT; Probably found no match...
                    ret = 1u;
                    break;
                }
            }
            dl_est = pclk / (16 * baudrate * fr_est);
            dl_est = (float)(uint32_t)dl_est;
            dl_est = dl_est < 3 ? 3 : dl_est; // Datasheet limits the low value
            fr_est = pclk / (16 * baudrate * dl_est);
        } while ((fr_est < min_val) || (fr_est > max_val));

        // DivAddVal and MulVal from Table, selected by FR:
        for (lut_index = 0; lut_index <  lut_size; lut_index++)
        {
            if (fr_est < lut[lut_index].fr)
            {
                lut_index--; // We take one value less, this appears to be more accurate
                // Fractional Part
                divaddval = lut[lut_index].dav;
                mulval = lut[lut_index].mv;
                break;
            }
        }
    }

    // Base Factor
    dlm = (uint8_t)(((uint32_t)(dl_est))  >> 8);
    dll = (uint8_t)(((uint32_t)(dl_est))      );

    *dLL = dll;
    *dLM = dlm;
    *divAddVal = divaddval;
    *mulVal = mulval;

    return ret;
}

uint8_t FracBd_GetSettingsForBaudrateH(uint32_t baudRate, uint32_t *pClk, uint8_t *dLL, uint8_t *dLM, uint8_t *divAddVal, uint8_t *mulVal)
{
    struct lut_elh
    {
        uint32_t    pclk;       // PCLK (equal to core clock)
        uint32_t    br_at_dll1; // Baudrate at Divider LOW Register choice 1
        uint32_t    br_at_dll2; // Baudrate at Divider LOW Register choice 2
        uint32_t    br_at_dll3; // Baudrate at Divider LOW Register choice 3
    };

    const struct lut_elh lut[] =
    {
        {60000000, 3750000, 1875000, 1250000},
        {61000000, 3812500, 1906250, 1270833},
        {62000000, 3875000, 1937500, 1291666},
        {63000000, 3937500, 1968750, 1312500},
        {64000000, 4000000, 2000000, 1333333},
        {65000000, 4062500, 2031250, 1354166},
        {66000000, 4125000, 2062500, 1375000},
        {67000000, 4187500, 2093750, 1395833},
        {68000000, 4250000, 2125000, 1416666},
        {69000000, 4312500, 2156250, 1437500},
        {70000000, 4375000, 2187500, 1458333},
        {71000000, 4437500, 2218750, 1479166},
        {72000000, 4500000, 2250000, 1500000},
        {73000000, 4562500, 2281250, 1520833},
        {74000000, 4625000, 2312500, 1541666},
        {75000000, 4687500, 2343750, 1562500},
        {76000000, 4750000, 2375000, 1583333},
        {77000000, 4812500, 2406250, 1604166},
        {78000000, 4875000, 2437500, 1625000},
        {79000000, 4937500, 2468750, 1645833},
        {80000000, 5000000, 2500000, 1666666},
        {81000000, 5062500, 2531250, 1687500},
        {82000000, 5125000, 2562500, 1708333},
        {83000000, 5187500, 2593750, 1729166},
        {84000000, 5250000, 2625000, 1750000},
        {85000000, 5312500, 2656250, 1770833},
        {86000000, 5375000, 2687500, 1791666},
        {87000000, 5437500, 2718750, 1812500},
        {88000000, 5500000, 2750000, 1833333},
        {89000000, 5562500, 2781250, 1854166},
        {90000000, 5625000, 2812500, 1875000},
        {91000000, 5687500, 2843750, 1895833},
        {92000000, 5750000, 2875000, 1916666},
        {93000000, 5812500, 2906250, 1937500},
        {94000000, 5875000, 2937500, 1958333},
        {95000000, 5937500, 2968750, 1979166},
        {96000000, 6000000, 3000000, 2000000},
        {97000000, 6062500, 3031250, 2020833},
        {98000000, 6125000, 3062500, 2041666},
        {99000000, 6187500, 3093750, 2062500},
        {100000000, 6250000, 3125000, 2083333},
        {101000000, 6312500, 3156250, 2104166},
        {102000000, 6375000, 3187500, 2125000},
        {103000000, 6437500, 3218750, 2145833},
        {104000000, 6500000, 3250000, 2166666},
        {105000000, 6562500, 3281250, 2187500},
        {106000000, 6625000, 3312500, 2208333},
        {107000000, 6687500, 3343750, 2229166},
        {108000000, 6750000, 3375000, 2250000},
        {109000000, 6812500, 3406250, 2270833},
        {110000000, 6875000, 3437500, 2291666},
        {111000000, 6937500, 3468750, 2312500},
        {112000000, 7000000, 3500000, 2333333},
        {113000000, 7062500, 3531250, 2354166},
        {114000000, 7125000, 3562500, 2375000},
        {115000000, 7187500, 3593750, 2395833},
        {116000000, 7250000, 3625000, 2416666},
        {117000000, 7312500, 3656250, 2437500},
        {118000000, 7375000, 3687500, 2458333},
        {119000000, 7437500, 3718750, 2479166},
        {120000000, 7500000, 3750000, 2500000}
    };
    const uint8_t lut_size = (uint8_t)(sizeof(lut) / sizeof(struct lut_elh));

    const uint8_t dll1 = 1u;   // DLL, choice 1
    const uint8_t dll2 = 2u;   // DLL, choice 2
    const uint8_t dll3 = 3u;   // DLL, choice 3

    uint8_t         ret = 1u;
    int             i;              // Iterate LUT
    uint8_t         j;              // Iterate modes {exact, close match}
    uint32_t        f_max = *pClk;
    struct lut_elh *lut_p = NULL;

    for (j = 0; j < 2; j++)
    {
        for (i = (int)(lut_size - 1); i >= 0; i--)
        {
            lut_p = (struct lut_elh*)&lut[i];
            if (lut_p->pclk <= f_max)
            {
                // Find match
                uint8_t match = FracBd_Range(baudRate, lut_p->br_at_dll1, j);
                if (0 != match)
                {
                    *dLL = dll1;
                    *pClk = lut_p->pclk;
                    ret = 0;
                    break;
                }
                match = FracBd_Range(baudRate, lut_p->br_at_dll2, j);
                if (0 != match)
                {
                    *dLL = dll2;
                    *pClk = lut_p->pclk;
                    ret = 0;
                    break;
                }
                match = FracBd_Range(baudRate, lut_p->br_at_dll3, j);
                if (0 != match)
                {
                    *dLL = dll3;
                    *pClk = lut_p->pclk;
                    ret = 0;
                    break;
                }
            }
        }
        if (0 == ret)
        {
            // Complete
            break;
        }
    }

    if (0 != ret)
    {
        // Not found
        *dLL = 1u;
    }

    *dLM = 0;       // Not needed for the very high baud rates
    *divAddVal = 0; // Disable Fractional Baudrate generator
    *mulVal = 1u;   // Fractional generator not needed

    return ret;
}


/*********************************************************************//**
 * @brief		Determines best dividers to get a target clock rate
 * @param[in]	UARTx	Pointer to selected UART peripheral, should be:
 * 				- LPC_UART0: UART0 peripheral
 * 				- LPC_UART1: UART1 peripheral
 * 				- LPC_UART2: UART2 peripheral
 * 				- LPC_UART3: UART3 peripheral
 * @param[in]	baudrate Desired UART baud rate.
 * @return 		Error status, could be:
 * 				- SUCCESS
 * 				- ERROR
 **********************************************************************/
Status uart_set_divisors(LPC_UART_TypeDef *UARTx, uint32_t baudrate)
{
	Status errorStatus = SUCCESS;

    uint32_t uClk = 0;
    uint32_t div_val;
	uint8_t  dLL;
    uint8_t  dLM;
    uint8_t  divAddVal;
    uint8_t  mulVal;
    uint8_t  ret;


    if (baudrate > FRAC_BD_MAX_FDFREQUENCY)
    {
        // Very high baudrate: Non-fractional divider needed together with core clock change
        div_val = CLKPWR_PCLKSEL_CCLK_DIV_1;
        if (UARTx == (LPC_UART_TypeDef*)LPC_UART0)
        {
            CLKPWR_SetPCLKDiv(CLKPWR_PCLKSEL_UART0, div_val);
        }
        else if (UARTx == (LPC_UART_TypeDef*)LPC_UART1)
        {
            CLKPWR_SetPCLKDiv(CLKPWR_PCLKSEL_UART1, div_val);
        }
        else if (UARTx == LPC_UART2)
        {
            CLKPWR_SetPCLKDiv(CLKPWR_PCLKSEL_UART2, div_val);
        }
        else if (UARTx == LPC_UART3)
        {
            CLKPWR_SetPCLKDiv(CLKPWR_PCLKSEL_UART3, div_val);
        }

        // Determine a register and CPU clock setting and apply it:
        uClk = CLKPWR_GetPCLK (CLKPWR_PCLKSEL_UART1);
        ret = FracBd_GetSettingsForBaudrateH(baudrate, &uClk, &dLL, &dLM, &divAddVal, &mulVal);
        if (0 == ret)
        {
            // OK, CPU frequency can be changed now:
            ret = CoreFrequency_Set(uClk);
        }
    } else
    {
        // Fractional divider used
        // Peripheral Clock adjust according to BR:
        if (baudrate < 400000u)
        {
            div_val = CLKPWR_PCLKSEL_CCLK_DIV_4;
        } else if (baudrate < 800000u)
        {
            div_val = CLKPWR_PCLKSEL_CCLK_DIV_2;
        } else
        {
            div_val = CLKPWR_PCLKSEL_CCLK_DIV_1;
        }

        if (UARTx == (LPC_UART_TypeDef*)LPC_UART0)
        {
            CLKPWR_SetPCLKDiv(CLKPWR_PCLKSEL_UART0, div_val);
            uClk = CLKPWR_GetPCLK (CLKPWR_PCLKSEL_UART0);
        }
        else if (UARTx == (LPC_UART_TypeDef*)LPC_UART1)
        {
            CLKPWR_SetPCLKDiv(CLKPWR_PCLKSEL_UART1, div_val);
            uClk = CLKPWR_GetPCLK (CLKPWR_PCLKSEL_UART1);
        }
        else if (UARTx == LPC_UART2)
        {
            CLKPWR_SetPCLKDiv(CLKPWR_PCLKSEL_UART2, div_val);
            uClk = CLKPWR_GetPCLK (CLKPWR_PCLKSEL_UART2);
        }
        else if (UARTx == LPC_UART3)
        {
            CLKPWR_SetPCLKDiv(CLKPWR_PCLKSEL_UART3, div_val);
            uClk = CLKPWR_GetPCLK (CLKPWR_PCLKSEL_UART3);
        }

        ret = FracBd_GetSettingsForBaudrate(baudrate, uClk, &dLL, &dLM, &divAddVal, &mulVal); // KKG: Replaced original code by my function
    }

	errorStatus = (0 == ret) ? SUCCESS : ERROR;

    if (SUCCESS == errorStatus)
    {
        if (((LPC_UART1_TypeDef *)UARTx) == LPC_UART1)
        {
            ((LPC_UART1_TypeDef *)UARTx)->LCR |= UART_LCR_DLAB_EN;
            ((LPC_UART1_TypeDef *)UARTx)->DLM = dLM & 0xFFu;
            ((LPC_UART1_TypeDef *)UARTx)->DLL = dLL & 0xFFu;
            /* Then reset DLAB bit */
            ((LPC_UART1_TypeDef *)UARTx)->LCR &= (~UART_LCR_DLAB_EN) & UART_LCR_BITMASK;
            ((LPC_UART1_TypeDef *)UARTx)->FDR = 0;
            ((LPC_UART1_TypeDef *)UARTx)->FDR |= (divAddVal & 0x0Fu);
            ((LPC_UART1_TypeDef *)UARTx)->FDR |= ((mulVal & 0x0Fu) << 4);
        } else
        {
            UARTx->LCR |= UART_LCR_DLAB_EN;
            UARTx->DLM = dLM & 0xFFu;
            UARTx->DLL = dLL & 0xFFu;
            /* Then reset DLAB bit */
            UARTx->LCR &= (~UART_LCR_DLAB_EN) & UART_LCR_BITMASK;
            UARTx->FDR = 0;
            UARTx->FDR |= (divAddVal & 0x0Fu);
            UARTx->FDR |= ((mulVal & 0x0Fu) << 4);
        }
    }

	return errorStatus;
}

#endif




#if 0

/*********************************************************************//**
 * @brief               Determines best dividers to get a target clock rate
 * @param[in]   UARTx   Pointer to selected UART peripheral, should be
 *                                              UART0, UART1, UART2 or UART3.
 * @param[in]   baudrate Desired UART baud rate.
 * @return              Error status.
 **********************************************************************/

Status uart_set_divisors_org(LPC_UART_TypeDef *UARTx, uint32_t baudrate)
{
    Status errorStatus = ERROR;

    uint32_t uClk;
    uint32_t calcBaudrate = 0;
    uint32_t temp = 0;

    uint32_t mulFracDiv, dividerAddFracDiv;
    uint32_t diviser = 0 ;
    uint32_t mulFracDivOptimal = 2;
    uint32_t dividerAddOptimal = 0;
    uint32_t diviserOptimal = 0;

    uint32_t relativeError = 0;
    uint32_t relativeOptimalError = 50000;

    volatile uint8_t DLL, ADDDIV,  MUL;

    /* get UART block clock */
    if (UARTx == LPC_UART0)
    {
        uClk = CLKPWR_GetPCLK (CLKPWR_PCLKSEL_UART0);
    }
    else if (UARTx == (LPC_UART_TypeDef *)LPC_UART1)
    {
        uClk = CLKPWR_GetPCLK (CLKPWR_PCLKSEL_UART1);
    }
    else if (UARTx == LPC_UART2)
    {
        uClk = CLKPWR_GetPCLK (CLKPWR_PCLKSEL_UART2);
    }
    else if (UARTx == LPC_UART3)
    {
        uClk = CLKPWR_GetPCLK (CLKPWR_PCLKSEL_UART3);
    }

    if( (baudrate >= 9600) && (baudrate <= 1288000))
    {
        uClk = uClk >> 4; /* div by 16 */
        // uClk = uClk >> 2; /* div by 16 */
        /* In the Uart IP block, baud rate is calculated using FDR and DLL-DLM registers
         * The formula is :
         * BaudRate= uClk * (mulFracDiv/(mulFracDiv+dividerAddFracDiv) / (16 * (DLL)
         * It involves floating point calculations. That's the reason the formulae are adjusted with
         * Multiply and divide method.*/
        /* The value of mulFracDiv and dividerAddFracDiv should comply to the following expressions:
         * 0 < mulFracDiv <= 15, 0 <= dividerAddFracDiv <= 15 */
        for (mulFracDiv = 1 ; mulFracDiv <= 15 ;mulFracDiv++)
        {
            for (dividerAddFracDiv = 0 ; dividerAddFracDiv <= 15 ;dividerAddFracDiv++)
            {
                temp = (mulFracDiv * uClk) / ((mulFracDiv + dividerAddFracDiv));

                diviser = temp / baudrate;
                if ((temp % baudrate) > (baudrate / 2))
                    diviser++;

                if (diviser > 2 && diviser < 65536)
                {
                    calcBaudrate = temp / diviser;

                    if (calcBaudrate <= baudrate)
                        relativeError = baudrate - calcBaudrate;
                    else
                        relativeError = calcBaudrate - baudrate;

                    if ((relativeError < relativeOptimalError))
                    {
                        mulFracDivOptimal = mulFracDiv ;
                        dividerAddOptimal = dividerAddFracDiv;
                        diviserOptimal = diviser;
                        relativeOptimalError = relativeError;
                        if (relativeError == 0)
                            break;
                    }
                } /* End of if */
            } /* end of inner for loop */
            if (relativeError == 0)
                break;
        } /* end of outer for loop  */

        if (relativeOptimalError < ((baudrate * UART_ACCEPTED_BAUDRATE_ERROR)/100))
        {
            if (((LPC_UART1_TypeDef *)UARTx) == LPC_UART1)
            {
                ((LPC_UART1_TypeDef *)UARTx)->LCR |= UART_LCR_DLAB_EN;
                ((LPC_UART1_TypeDef *)UARTx)->/*DLIER.*/DLM = UART_LOAD_DLM(diviserOptimal);
                ((LPC_UART1_TypeDef *)UARTx)->/*RBTHDLR.*/DLL = UART_LOAD_DLL(diviserOptimal);
                /* Then reset DLAB bit */
                ((LPC_UART1_TypeDef *)UARTx)->LCR &= (~UART_LCR_DLAB_EN) & UART_LCR_BITMASK;
                ((LPC_UART1_TypeDef *)UARTx)->FDR = (UART_FDR_MULVAL(mulFracDivOptimal) \
                        | UART_FDR_DIVADDVAL(dividerAddOptimal)) & UART_FDR_BITMASK;
            }
            else
            {
                UARTx->LCR |= UART_LCR_DLAB_EN;
                UARTx->/*DLIER.*/DLM = UART_LOAD_DLM(diviserOptimal);
                UARTx->/*RBTHDLR.*/DLL = UART_LOAD_DLL(diviserOptimal);
                /* Then reset DLAB bit */
                UARTx->LCR &= (~UART_LCR_DLAB_EN) & UART_LCR_BITMASK;
                UARTx->FDR = (UART_FDR_MULVAL(mulFracDivOptimal) \
                        | UART_FDR_DIVADDVAL(dividerAddOptimal)) & UART_FDR_BITMASK;
            }
            errorStatus = SUCCESS;
        }
    }
    else
    {

        if(Calculate_FDR(baudrate, &DLL, &ADDDIV, &MUL) != SUCCESS){
            while(1);/*  catch bug. */
        }

        ((LPC_UART1_TypeDef *)UARTx)->LCR |= UART_LCR_DLAB_EN;
        ((LPC_UART1_TypeDef *)UARTx)->/*DLIER.*/DLM = UART_LOAD_DLM(0);
        ((LPC_UART1_TypeDef *)UARTx)->/*RBTHDLR.*/DLL = UART_LOAD_DLL(DLL);
        /* Then reset DLAB bit */
        ((LPC_UART1_TypeDef *)UARTx)->LCR &= (~UART_LCR_DLAB_EN) & UART_LCR_BITMASK;
        ((LPC_UART1_TypeDef *)UARTx)->FDR = (UART_FDR_MULVAL(MUL) \
                | UART_FDR_DIVADDVAL(ADDDIV)) & UART_FDR_BITMASK;
        return SUCCESS;
    }
    return errorStatus;
}


#endif


/********************************************************************//**
 * @brief Get Interrupt Identification value
 * @param[in] UARTx UART peripheral selected, should be:
 * - LPC_UART0: UART0 peripheral
 * - LPC_UART1: UART1 peripheral
 * - LPC_UART2: UART2 peripheral
 * - LPC_UART3: UART3 peripheral
 * @return Current value of UART UIIR register in UART peripheral.
 *********************************************************************/
uint32_t UART_GetIntId(LPC_UART_TypeDef* UARTx)
{
    CHECK_PARAM(PARAM_UARTx(UARTx));
    return (UARTx->IIR & 0x03CF);
}

/*********************************************************************//**
 * @brief               General UART interrupt handler and router
 * @param[in]   UARTx   Selected UART peripheral, should be UART0..3
 * @return              None
 *
 * Note:
 * - Handles transmit, receive, and status interrupts for the UART.
 * Based on the interrupt status, routes the interrupt to the
 * respective call-back to be handled by the user application using
 * this driver.
 * - If callback is not installed, corresponding interrupt will be disabled
 * - All these interrupt source below will be checked:
 *              - Transmit Holding Register Empty.
 *                      - Received Data Available and Character Time Out.
 *                      - Receive Line Status (not implemented)
 *                      - End of auto-baud interrupt (not implemented)
 *                      - Auto-Baudrate Time-Out interrupt (not implemented)
 *                      - Modem Status interrupt (UART0 Modem functionality)
 *                      - CTS signal transition interrupt (UART0 Modem functionality)
 **********************************************************************/
void UART_GenIntHandler(LPC_UART_TypeDef *UARTx)
{
    uint8_t pUart, modemsts;
    uint32_t intsrc, tmp, tmp1;

    pUart = getUartNum(UARTx);

    /* Determine the interrupt source */
    intsrc = UARTx->IIR;
    tmp = intsrc & UART_IIR_INTID_MASK;

    /*
     * In case of using UART1 with full modem,
     * interrupt ID = 0 that means modem status interrupt has been detected
     */
    if (pUart == 1) {
        if (tmp == 0){
            // Check Modem status
            modemsts = LPC_UART1->MSR & UART1_MSR_BITMASK;
            // Call modem status call-back
            if (pfnModemCbs != NULL){
                pfnModemCbs(modemsts);
            }
            // disable modem status interrupt and CTS status change interrupt
            // if its callback is not installed
            else {
                LPC_UART1->IER &= ~(UART1_IER_MSINT_EN | UART1_IER_CTSINT_EN);
            }
        }
    }

    // Receive Line Status
    if (tmp == UART_IIR_INTID_RLS){
        // Check line status
        tmp1 = UARTx->LSR;
        // Mask out the Receive Ready and Transmit Holding empty status
        tmp1 &= (UART_LSR_OE | UART_LSR_PE | UART_LSR_FE \
                | UART_LSR_BI | UART_LSR_RXFE);
        // If any error exist
        if (tmp1) {
            // Call Call-back function with error input value
            if (uartCbsDat[pUart].pfnErrCbs != NULL) {
                uartCbsDat[pUart].pfnErrCbs(tmp1);
            }
            // Disable interrupt if its call-back is not install
            else {
                UARTx->IER &= ~(UART_IER_RLSINT_EN);
            }
        }
    }

    // Receive Data Available or Character time-out
    if ((tmp == UART_IIR_INTID_RDA) || (tmp == UART_IIR_INTID_CTI)){
        // Call Rx call back function
        if (uartCbsDat[pUart].pfnRxCbs != NULL) {
            uartCbsDat[pUart].pfnRxCbs();
        }
        // Disable interrupt if its call-back is not install
        else {
            UARTx->IER &= ~(UART_IER_RBRINT_EN);
        }
    }

    // Transmit Holding Empty
    if (tmp == UART_IIR_INTID_THRE){
        // Call Tx call back function
        if (uartCbsDat[pUart].pfnTxCbs != NULL) {
            uartCbsDat[pUart].pfnTxCbs();
        }
        // Disable interrupt if its call-back is not install
        else {
            UARTx->IER &= ~(UART_IER_THREINT_EN);
        }
    }

    intsrc &= (UART_IIR_ABEO_INT | UART_IIR_ABTO_INT);
    // Check if End of auto-baudrate interrupt or Auto baudrate time out
    if (intsrc){
        // Clear interrupt pending
        UARTx->ACR |= ((intsrc & UART_IIR_ABEO_INT) ? UART_ACR_ABEOINT_CLR : 0) \
                | ((intsrc & UART_IIR_ABTO_INT) ? UART_ACR_ABTOINT_CLR : 0);
        if (uartCbsDat[pUart].pfnABCbs != NULL) {
            uartCbsDat[pUart].pfnABCbs(intsrc);
        } else {
            // Disable End of AB interrupt
            UARTx->IER &= ~(UART_IER_ABEOINT_EN | UART_IER_ABTOINT_EN);
        }
    }
}

/**
 * @}
 */


/* Public Functions ----------------------------------------------------------- */
/** @addtogroup UART_Public_Functions
 * @{
 */

/*********************************************************************//**
 * @brief               De-initializes the UARTx peripheral registers to their
 *                  default reset values.
 * @param[in]   UARTx   UART peripheral selected, should be UART0, UART1,
 *                                              UART2 or UART3.
 * @return              None
 **********************************************************************/
void UART_DeInit(LPC_UART_TypeDef* UARTx)
{
    // For debug mode
    CHECK_PARAM(PARAM_UARTx(UARTx));

    UART_TxCmd(UARTx, DISABLE);

#ifdef _UART0
    if (UARTx == LPC_UART0)
    {
        /* Set up clock and power for UART module */
        CLKPWR_ConfigPPWR (CLKPWR_PCONP_PCUART0, DISABLE);
    }
#endif

#ifdef _UART1
    if (((LPC_UART1_TypeDef *)UARTx) == LPC_UART1)
    {
        /* Set up clock and power for UART module */
        CLKPWR_ConfigPPWR (CLKPWR_PCONP_PCUART1, DISABLE);
    }
#endif

#ifdef _UART2
    if (UARTx == LPC_UART2)
    {
        /* Set up clock and power for UART module */
        CLKPWR_ConfigPPWR (CLKPWR_PCONP_PCUART2, DISABLE);
    }
#endif

#ifdef _UART3
    if (UARTx == LPC_UART3)
    {
        /* Set up clock and power for UART module */
        CLKPWR_ConfigPPWR (CLKPWR_PCONP_PCUART3, DISABLE);
    }
#endif
}

/********************************************************************//**
 * @brief               Initializes the UARTx peripheral according to the specified
 *               parameters in the UART_ConfigStruct.
 * @param[in]   UARTx   UART peripheral selected, should be UART0, UART1,
 *                                              UART2 or UART3.
 * @param[in]   UART_ConfigStruct Pointer to a UART_CFG_Type structure
 *                    that contains the configuration information for the
 *                    specified UART peripheral.
 * @return              None
 *********************************************************************/
void UART_Init(LPC_UART_TypeDef *UARTx, UART_CFG_Type *UART_ConfigStruct)
{
    uint32_t tmp;

    // For debug mode
    CHECK_PARAM(PARAM_UARTx(UARTx));
    CHECK_PARAM(PARAM_UART_DATABIT(UART_ConfigStruct->Databits));
    CHECK_PARAM(PARAM_UART_STOPBIT(UART_ConfigStruct->Stopbits));
    CHECK_PARAM(PARAM_UART_PARITY(UART_ConfigStruct->Parity));

#ifdef _UART0
    if(UARTx == LPC_UART0)
    {
        /* Set up clock and power for UART module */
        CLKPWR_ConfigPPWR (CLKPWR_PCONP_PCUART0, ENABLE);
    }
#endif

#ifdef _UART1
    if(((LPC_UART1_TypeDef *)UARTx) == LPC_UART1)
    {
        /* Set up clock and power for UART module */
        CLKPWR_ConfigPPWR (CLKPWR_PCONP_PCUART1, ENABLE);

        CLKPWR_SetPCLKDiv(CLKPWR_PCLKSEL_UART1,CLKPWR_PCLKSEL_CCLK_DIV_1);

    }
#endif

#ifdef _UART2
    if(UARTx == LPC_UART2)
    {
        /* Set up clock and power for UART module */
        CLKPWR_ConfigPPWR (CLKPWR_PCONP_PCUART2, ENABLE);
    }
#endif

#ifdef _UART3
    if(UARTx == LPC_UART3)
    {
        /* Set up clock and power for UART module */
        CLKPWR_ConfigPPWR (CLKPWR_PCONP_PCUART3, ENABLE);
    }
#endif

    if (((LPC_UART1_TypeDef *)UARTx) == LPC_UART1)
    {
        /* FIFOs are empty */
        ((LPC_UART1_TypeDef *)UARTx)->/*IIFCR.*/FCR = ( UART_FCR_FIFO_EN \
                | UART_FCR_RX_RS | UART_FCR_TX_RS);
        // Disable FIFO
        ((LPC_UART1_TypeDef *)UARTx)->/*IIFCR.*/FCR = 0;

        // Dummy reading
        while (((LPC_UART1_TypeDef *)UARTx)->LSR & UART_LSR_RDR)
        {
            tmp = ((LPC_UART1_TypeDef *)UARTx)->/*RBTHDLR.*/RBR;
        }

        ((LPC_UART1_TypeDef *)UARTx)->TER = UART_TER_TXEN;
        // Wait for current transmit complete
        while (!(((LPC_UART1_TypeDef *)UARTx)->LSR & UART_LSR_THRE));
        // Disable Tx
        ((LPC_UART1_TypeDef *)UARTx)->TER = 0;

        // Disable interrupt
        ((LPC_UART1_TypeDef *)UARTx)->/*DLIER.*/IER = 0;
        // Set LCR to default state
        ((LPC_UART1_TypeDef *)UARTx)->LCR = 0;
        // Set ACR to default state
        ((LPC_UART1_TypeDef *)UARTx)->ACR = 0;
        // Set Modem Control to default state
        ((LPC_UART1_TypeDef *)UARTx)->MCR = 0;
        // Set RS485 control to default state
        ((LPC_UART1_TypeDef *)UARTx)->RS485CTRL = 0;
        // Set RS485 delay timer to default state
        ((LPC_UART1_TypeDef *)UARTx)->RS485DLY = 0;
        // Set RS485 addr match to default state
        ((LPC_UART1_TypeDef *)UARTx)->ADRMATCH = 0;
        //Dummy Reading to Clear Status
        tmp = ((LPC_UART1_TypeDef *)UARTx)->MSR;
        tmp = ((LPC_UART1_TypeDef *)UARTx)->LSR;
    }
    else
    {
        /* FIFOs are empty */
        UARTx->/*IIFCR.*/FCR = ( UART_FCR_FIFO_EN | UART_FCR_RX_RS | UART_FCR_TX_RS);
        // Disable FIFO
        UARTx->/*IIFCR.*/FCR = 0;

        // Dummy reading
        while (UARTx->LSR & UART_LSR_RDR)
        {
            tmp = UARTx->/*RBTHDLR.*/RBR;
        }

        UARTx->TER = UART_TER_TXEN;
        // Wait for current transmit complete
        while (!(UARTx->LSR & UART_LSR_THRE));
        // Disable Tx
        UARTx->TER = 0;

        // Disable interrupt
        UARTx->/*DLIER.*/IER = 0;
        // Set LCR to default state
        UARTx->LCR = 0;
        // Set ACR to default state
        UARTx->ACR = 0;
        // Dummy reading
        tmp = UARTx->LSR;
    }

    if (UARTx == LPC_UART3)
    {
        // Set IrDA to default state
        UARTx->ICR = 0;
    }

    // Set Line Control register ----------------------------

    uart_set_divisors(UARTx, (UART_ConfigStruct->Baud_rate));

    if (((LPC_UART1_TypeDef *)UARTx) == LPC_UART1)
    {
        tmp = (((LPC_UART1_TypeDef *)UARTx)->LCR & (UART_LCR_DLAB_EN | UART_LCR_BREAK_EN)) \
                & UART_LCR_BITMASK;
    }
    else
    {
        tmp = (UARTx->LCR & (UART_LCR_DLAB_EN | UART_LCR_BREAK_EN)) & UART_LCR_BITMASK;
    }

    switch (UART_ConfigStruct->Databits){
    case UART_DATABIT_5:
        tmp |= UART_LCR_WLEN5;
        break;
    case UART_DATABIT_6:
        tmp |= UART_LCR_WLEN6;
        break;
    case UART_DATABIT_7:
        tmp |= UART_LCR_WLEN7;
        break;
    case UART_DATABIT_8:
    default:
        tmp |= UART_LCR_WLEN8;
        break;
    }

    if (UART_ConfigStruct->Parity == UART_PARITY_NONE)
    {
        // Do nothing...
    }
    else
    {
        tmp |= UART_LCR_PARITY_EN;
        switch (UART_ConfigStruct->Parity)
        {
        case UART_PARITY_ODD:
            tmp |= UART_LCR_PARITY_ODD;
            break;

        case UART_PARITY_EVEN:
            tmp |= UART_LCR_PARITY_EVEN;
            break;

        case UART_PARITY_SP_1:
            tmp |= UART_LCR_PARITY_F_1;
            break;

        case UART_PARITY_SP_0:
            tmp |= UART_LCR_PARITY_F_0;
            break;
        default:
            break;
        }
    }

    switch (UART_ConfigStruct->Stopbits){
    case UART_STOPBIT_2:
        tmp |= UART_LCR_STOPBIT_SEL;
        break;
    case UART_STOPBIT_1:
    default:
        // Do no thing
        break;
    }


    // Write back to LCR, configure FIFO and Disable Tx
    if (((LPC_UART1_TypeDef *)UARTx) ==  LPC_UART1)
    {
        ((LPC_UART1_TypeDef *)UARTx)->LCR = (uint8_t)(tmp & UART_LCR_BITMASK);
    }
    else
    {
        UARTx->LCR = (uint8_t)(tmp & UART_LCR_BITMASK);
    }
}


/*****************************************************************************//**
 * @brief                Fills each UART_InitStruct member with its default value:
 *                               9600 bps
 *                               8-bit data
 *                               1 Stopbit
 *                               None Parity
 * @param[in]    UART_InitStruct Pointer to a UART_CFG_Type structure
 *                    which will be initialized.
 * @return               None
 *******************************************************************************/
void UART_ConfigStructInit(UART_CFG_Type *UART_InitStruct)
{
    UART_InitStruct->Baud_rate = 9600;
    UART_InitStruct->Databits = UART_DATABIT_8;
    UART_InitStruct->Parity = UART_PARITY_NONE;
    UART_InitStruct->Stopbits = UART_STOPBIT_1;
}


/*********************************************************************//**
 * @brief               Transmit a single data through UART peripheral
 * @param[in]   UARTx   UART peripheral selected, should be UART0, UART1,
 *                                              UART2 or UART3.
 * @param[in]   Data    Data to transmit (must be 8-bit long)
 * @return none
 **********************************************************************/
void UART_SendData(LPC_UART_TypeDef* UARTx, uint8_t Data)
{
    CHECK_PARAM(PARAM_UARTx(UARTx));

    if (((LPC_UART1_TypeDef *)UARTx) == LPC_UART1)
    {
        ((LPC_UART1_TypeDef *)UARTx)->/*RBTHDLR.*/THR = Data & UART_THR_MASKBIT;
    }
    else
    {
        UARTx->/*RBTHDLR.*/THR = Data & UART_THR_MASKBIT;
    }

}


/*********************************************************************//**
 * @brief               Receive a single data from UART peripheral
 * @param[in]   UARTx   UART peripheral selected, should be UART0, UART1,
 *                                              UART2 or UART3.
 * @return              Data received
 **********************************************************************/
uint8_t UART_ReceiveData(LPC_UART_TypeDef* UARTx)
{
    CHECK_PARAM(PARAM_UARTx(UARTx));

    if (((LPC_UART1_TypeDef *)UARTx) == LPC_UART1)
    {
        return (((LPC_UART1_TypeDef *)UARTx)->/*RBTHDLR.*/RBR & UART_RBR_MASKBIT);
    }
    else
    {
        return (UARTx->/*RBTHDLR.*/RBR & UART_RBR_MASKBIT);
    }
}


/*********************************************************************//**
 * @brief               Force BREAK character on UART line, output pin UARTx TXD is
                                forced to logic 0.
 * @param[in]   UARTx   UART peripheral selected, should be UART0, UART1,
 *                                              UART2 or UART3.
 * @return none
 **********************************************************************/
void UART_ForceBreak(LPC_UART_TypeDef* UARTx)
{
    CHECK_PARAM(PARAM_UARTx(UARTx));

    if (((LPC_UART1_TypeDef *)UARTx) == LPC_UART1)
    {
        ((LPC_UART1_TypeDef *)UARTx)->LCR |= UART_LCR_BREAK_EN;
    }
    else
    {
        UARTx->LCR |= UART_LCR_BREAK_EN;
    }
}


#ifdef _UART3

/*********************************************************************//**
 * @brief               Enable or disable inverting serial input function of IrDA
 *                              on UART peripheral.
 * @param[in]   UARTx UART peripheral selected, should be UART3 (only)
 * @param[in]   NewState New state of inverting serial input, should be:
 *                              - ENABLE: Enable this function.
 *                              - DISABLE: Disable this function.
 * @return none
 **********************************************************************/
void UART_IrDAInvtInputCmd(LPC_UART_TypeDef* UARTx, FunctionalState NewState)
{
    CHECK_PARAM(PARAM_UART_IrDA(UARTx));
    CHECK_PARAM(PARAM_FUNCTIONALSTATE(NewState));

    if (NewState == ENABLE)
    {
        UARTx->ICR |= UART_ICR_IRDAINV;
    }
    else if (NewState == DISABLE)
    {
        UARTx->ICR &= (~UART_ICR_IRDAINV) & UART_ICR_BITMASK;
    }
}


/*********************************************************************//**
 * @brief               Enable or disable IrDA function on UART peripheral.
 * @param[in]   UARTx UART peripheral selected, should be UART3 (only)
 * @param[in]   NewState New state of IrDA function, should be:
 *                              - ENABLE: Enable this function.
 *                              - DISABLE: Disable this function.
 * @return none
 **********************************************************************/
void UART_IrDACmd(LPC_UART_TypeDef* UARTx, FunctionalState NewState)
{
    CHECK_PARAM(PARAM_UART_IrDA(UARTx));
    CHECK_PARAM(PARAM_FUNCTIONALSTATE(NewState));

    if (NewState == ENABLE)
    {
        UARTx->ICR |= UART_ICR_IRDAEN;
    }
    else
    {
        UARTx->ICR &= (~UART_ICR_IRDAEN) & UART_ICR_BITMASK;
    }
}


/*********************************************************************//**
 * @brief               Configure Pulse divider for IrDA function on UART peripheral.
 * @param[in]   UARTx UART peripheral selected, should be UART3 (only)
 * @param[in]   PulseDiv Pulse Divider value from Peripheral clock,
 *                              should be one of the following:
                                - UART_IrDA_PULSEDIV2   : Pulse width = 2 * Tpclk
                                - UART_IrDA_PULSEDIV4   : Pulse width = 4 * Tpclk
                                - UART_IrDA_PULSEDIV8   : Pulse width = 8 * Tpclk
                                - UART_IrDA_PULSEDIV16  : Pulse width = 16 * Tpclk
                                - UART_IrDA_PULSEDIV32  : Pulse width = 32 * Tpclk
                                - UART_IrDA_PULSEDIV64  : Pulse width = 64 * Tpclk
                                - UART_IrDA_PULSEDIV128 : Pulse width = 128 * Tpclk
                                - UART_IrDA_PULSEDIV256 : Pulse width = 256 * Tpclk

 * @return none
 **********************************************************************/
void UART_IrDAPulseDivConfig(LPC_UART_TypeDef *UARTx, UART_IrDA_PULSE_Type PulseDiv)
{
    uint32_t tmp, tmp1;
    CHECK_PARAM(PARAM_UART_IrDA(UARTx));
    CHECK_PARAM(PARAM_UART_IrDA_PULSEDIV(PulseDiv));

    tmp1 = UART_ICR_PULSEDIV(PulseDiv);
    tmp = UARTx->ICR & (~UART_ICR_PULSEDIV(7));
    tmp |= tmp1 | UART_ICR_FIXPULSE_EN;
    UARTx->ICR = tmp & UART_ICR_BITMASK;
}

#endif


/********************************************************************//**
 * @brief               Enable or disable specified UART interrupt.
 * @param[in]   UARTx   UART peripheral selected, should be UART0, UART1,
 *                                              UART2 or UART3.
 * @param[in]   UARTIntCfg      Specifies the interrupt flag,
 *                              should be one of the following:
                                - UART_INTCFG_RBR       :  RBR Interrupt enable
                                - UART_INTCFG_THRE      :  THR Interrupt enable
                                - UART_INTCFG_RLS       :  RX line status interrupt enable
                                - UART1_INTCFG_MS       :  Modem status interrupt enable (UART1 only)
                                - UART1_INTCFG_CTS      :  CTS1 signal transition interrupt enable (UART1 only)
                                - UART_INTCFG_ABEO      :  Enables the end of auto-baud interrupt
                                - UART_INTCFG_ABTO      :  Enables the auto-baud time-out interrupt
 * @param[in]   NewState New state of specified UART interrupt type,
 *                              should be:
 *                              - ENALBE: Enable this UART interrupt type.
 *                               - DISALBE: Disable this UART interrupt type.
 * @return              None
 *********************************************************************/
void UART_IntConfig(LPC_UART_TypeDef *UARTx, UART_INT_Type UARTIntCfg, FunctionalState NewState)
{
    uint32_t tmp = 0;

    CHECK_PARAM(PARAM_UARTx(UARTx));
    CHECK_PARAM(PARAM_FUNCTIONALSTATE(NewState));

    switch(UARTIntCfg){
    case UART_INTCFG_RBR:
        tmp = UART_IER_RBRINT_EN;
        break;
    case UART_INTCFG_THRE:
        tmp = UART_IER_THREINT_EN;
        break;
    case UART_INTCFG_RLS:
        tmp = UART_IER_RLSINT_EN;
        break;
    case UART1_INTCFG_MS:
        tmp = UART1_IER_MSINT_EN;
        break;
    case UART1_INTCFG_CTS:
        tmp = UART1_IER_CTSINT_EN;
        break;
    case UART_INTCFG_ABEO:
        tmp = UART_IER_ABEOINT_EN;
        break;
    case UART_INTCFG_ABTO:
        tmp = UART_IER_ABTOINT_EN;
        break;
    }

    if ((LPC_UART1_TypeDef *) UARTx == LPC_UART1)
    {
        CHECK_PARAM((PARAM_UART_INTCFG(UARTIntCfg)) || (PARAM_UART1_INTCFG(UARTIntCfg)));
    }
    else
    {
        CHECK_PARAM(PARAM_UART_INTCFG(UARTIntCfg));
    }

    if (NewState == ENABLE)
    {
        if ((LPC_UART1_TypeDef *) UARTx == LPC_UART1)
        {
            ((LPC_UART1_TypeDef *)UARTx)->/*DLIER.*/IER |= tmp;
        }
        else
        {
            UARTx->/*DLIER.*/IER |= tmp;
        }
    }
    else
    {
        if ((LPC_UART1_TypeDef *) UARTx == LPC_UART1)
        {
            ((LPC_UART1_TypeDef *)UARTx)->/*DLIER.*/IER &= (~tmp) & UART1_IER_BITMASK;
        }
        else
        {
            UARTx->/*DLIER.*/IER &= (~tmp) & UART_IER_BITMASK;
        }
    }
}


/********************************************************************//**
 * @brief               Get current value of Line Status register in UART peripheral.
 * @param[in]   UARTx   UART peripheral selected, should be UART0, UART1,
 *                                              UART2 or UART3.
 * @return              Current value of Line Status register in UART peripheral.
 * Note:        The return value of this function must be ANDed with each member in
 *                      UART_LS_Type enumeration to determine current flag status
 *                      corresponding to each Line status type. Because some flags in
 *                      Line Status register will be cleared after reading, the next reading
 *                      Line Status register could not be correct. So this function used to
 *                      read Line status register in one time only, then the return value
 *                      used to check all flags.
 *********************************************************************/
uint8_t UART_GetLineStatus(LPC_UART_TypeDef* UARTx)
{
    CHECK_PARAM(PARAM_UARTx(UARTx));

    if (((LPC_UART1_TypeDef *)UARTx) == LPC_UART1)
    {
        return ((((LPC_UART1_TypeDef *)LPC_UART1)->LSR) & UART_LSR_BITMASK);
    }
    else
    {
        return ((UARTx->LSR) & UART_LSR_BITMASK);
    }
}

/*********************************************************************//**
 * @brief               Check whether if UART is busy or not
 * @param[in]   UARTx   UART peripheral selected, should be UART0, UART1,
 *                                              UART2 or UART3.
 * @return              RESET if UART is not busy, otherwise return SET.
 **********************************************************************/
FlagStatus UART_CheckBusy(LPC_UART_TypeDef *UARTx)
{
    if (UARTx->LSR & UART_LSR_TEMT){
        return RESET;
    } else {
        return SET;
    }
}


/*********************************************************************//**
 * @brief               Configure FIFO function on selected UART peripheral
 * @param[in]   UARTx   UART peripheral selected, should be UART0, UART1,
 *                                              UART2 or UART3.
 * @param[in]   FIFOCfg Pointer to a UART_FIFO_CFG_Type Structure that
 *                                              contains specified information about FIFO configuration
 * @return              none
 **********************************************************************/
void UART_FIFOConfig(LPC_UART_TypeDef *UARTx, UART_FIFO_CFG_Type *FIFOCfg)
{
    uint8_t tmp = 0;

    CHECK_PARAM(PARAM_UARTx(UARTx));
    CHECK_PARAM(PARAM_UART_FIFO_LEVEL(FIFOCfg->FIFO_Level));
    CHECK_PARAM(PARAM_FUNCTIONALSTATE(FIFOCfg->FIFO_DMAMode));
    CHECK_PARAM(PARAM_FUNCTIONALSTATE(FIFOCfg->FIFO_ResetRxBuf));
    CHECK_PARAM(PARAM_FUNCTIONALSTATE(FIFOCfg->FIFO_ResetTxBuf));

    tmp |= UART_FCR_FIFO_EN;
    switch (FIFOCfg->FIFO_Level){
    case UART_FIFO_TRGLEV0:
        tmp |= UART_FCR_TRG_LEV0;
        break;
    case UART_FIFO_TRGLEV1:
        tmp |= UART_FCR_TRG_LEV1;
        break;
    case UART_FIFO_TRGLEV2:
        tmp |= UART_FCR_TRG_LEV2;
        break;
    case UART_FIFO_TRGLEV3:
    default:
        tmp |= UART_FCR_TRG_LEV3;
        break;
    }

    if (FIFOCfg->FIFO_ResetTxBuf == ENABLE)
    {
        tmp |= UART_FCR_TX_RS;
    }
    if (FIFOCfg->FIFO_ResetRxBuf == ENABLE)
    {
        tmp |= UART_FCR_RX_RS;
    }
    if (FIFOCfg->FIFO_DMAMode == ENABLE)
    {
        tmp |= UART_FCR_DMAMODE_SEL;
    }


    //write to FIFO control register
    if (((LPC_UART1_TypeDef *)UARTx) == LPC_UART1)
    {
        ((LPC_UART1_TypeDef *)UARTx)->/*IIFCR.*/FCR = tmp & UART_FCR_BITMASK;
    }
    else
    {
        UARTx->/*IIFCR.*/FCR = tmp & UART_FCR_BITMASK;
    }

}


/*****************************************************************************//**
 * @brief                Fills each UART_FIFOInitStruct member with its default value:
 *                               - FIFO_DMAMode = DISABLE
 *                               - FIFO_Level = UART_FIFO_TRGLEV0
 *                               - FIFO_ResetRxBuf = ENABLE
 *                               - FIFO_ResetTxBuf = ENABLE
 *                               - FIFO_State = ENABLE

 * @param[in]    UART_FIFOInitStruct Pointer to a UART_FIFO_CFG_Type structure
 *                    which will be initialized.
 * @return               None
 *******************************************************************************/
void UART_FIFOConfigStructInit(UART_FIFO_CFG_Type *UART_FIFOInitStruct)
{
    UART_FIFOInitStruct->FIFO_DMAMode = DISABLE;
    UART_FIFOInitStruct->FIFO_Level = UART_FIFO_TRGLEV0;
    UART_FIFOInitStruct->FIFO_ResetRxBuf = ENABLE;
    UART_FIFOInitStruct->FIFO_ResetTxBuf = ENABLE;
}


/*********************************************************************//**
 * @brief               Start/Stop Auto Baudrate activity
 * @param[in]   UARTx   UART peripheral selected, should be UART0, UART1,
 *                                              UART2 or UART3.
 * @param[in]   ABConfigStruct  A pointer to UART_AB_CFG_Type structure that
 *                                                              contains specified information about UART
 *                                                              auto baudrate configuration
 * @param[in]   NewState New State of Auto baudrate activity, should be:
 *                              - ENABLE: Start this activity
 *                              - DISABLE: Stop this activity
 * Note:                Auto-baudrate mode enable bit will be cleared once this mode
 *                              completed.
 * @return              none
 **********************************************************************/
void UART_ABCmd(LPC_UART_TypeDef *UARTx, UART_AB_CFG_Type *ABConfigStruct, \
        FunctionalState NewState)
{
    uint32_t tmp;

    CHECK_PARAM(PARAM_UARTx(UARTx));
    CHECK_PARAM(PARAM_FUNCTIONALSTATE(NewState));

    tmp = 0;
    if (NewState == ENABLE) {
        if (ABConfigStruct->ABMode == UART_AUTOBAUD_MODE1){
            tmp |= UART_ACR_MODE;
        }
        if (ABConfigStruct->AutoRestart == ENABLE){
            tmp |= UART_ACR_AUTO_RESTART;
        }
    }

    if (((LPC_UART1_TypeDef *)UARTx) == LPC_UART1)
    {
        if (NewState == ENABLE)
        {
            // Clear DLL and DLM value
            ((LPC_UART1_TypeDef *)UARTx)->LCR |= UART_LCR_DLAB_EN;
            ((LPC_UART1_TypeDef *)UARTx)->DLL = 0;
            ((LPC_UART1_TypeDef *)UARTx)->DLM = 0;
            ((LPC_UART1_TypeDef *)UARTx)->LCR &= ~UART_LCR_DLAB_EN;
            // FDR value must be reset to default value
            ((LPC_UART1_TypeDef *)UARTx)->FDR = 0x10;
            ((LPC_UART1_TypeDef *)UARTx)->ACR = UART_ACR_START | tmp;
        }
        else
        {
            ((LPC_UART1_TypeDef *)UARTx)->ACR = 0;
        }
    }
    else
    {
        if (NewState == ENABLE)
        {
            // Clear DLL and DLM value
            UARTx->LCR |= UART_LCR_DLAB_EN;
            UARTx->DLL = 0;
            UARTx->DLM = 0;
            UARTx->LCR &= ~UART_LCR_DLAB_EN;
            // FDR value must be reset to default value
            UARTx->FDR = 0x10;
            UARTx->ACR = UART_ACR_START | tmp;
        }
        else
        {
            UARTx->ACR = 0;
        }
    }
}


/*********************************************************************//**
 * @brief               Enable/Disable transmission on UART TxD pin
 * @param[in]   UARTx   UART peripheral selected, should be UART0, UART1,
 *                                              UART2 or UART3.
 * @param[in]   NewState New State of Tx transmission function, should be:
 *                              - ENABLE: Enable this function
                                - DISABLE: Disable this function
 * @return none
 **********************************************************************/
void UART_TxCmd(LPC_UART_TypeDef *UARTx, FunctionalState NewState)
{
    CHECK_PARAM(PARAM_UARTx(UARTx));
    CHECK_PARAM(PARAM_FUNCTIONALSTATE(NewState));

    if (NewState == ENABLE)
    {
        if (((LPC_UART1_TypeDef *)UARTx) == LPC_UART1)
        {
            ((LPC_UART1_TypeDef *)UARTx)->TER |= UART_TER_TXEN;
        }
        else
        {
            UARTx->TER |= UART_TER_TXEN;
        }
    }
    else
    {
        if (((LPC_UART1_TypeDef *)UARTx) == LPC_UART1)
        {
            ((LPC_UART1_TypeDef *)UARTx)->TER &= (~UART_TER_TXEN) & UART_TER_BITMASK;
        }
        else
        {
            UARTx->TER &= (~UART_TER_TXEN) & UART_TER_BITMASK;
        }
    }
}

#ifdef _UART1

/*********************************************************************//**
 * @brief               Force pin DTR/RTS corresponding to given state (Full modem mode)
 * @param[in]   UARTx   UART1 (only)
 * @param[in]   Pin     Pin that NewState will be applied to, should be:
 *                              - UART1_MODEM_PIN_DTR: DTR pin.
 *                              - UART1_MODEM_PIN_RTS: RTS pin.
 * @param[in]   NewState New State of DTR/RTS pin, should be:
 *                              - INACTIVE: Force the pin to inactive signal.
                                - ACTIVE: Force the pin to active signal.
 * @return none
 **********************************************************************/
void UART_FullModemForcePinState(LPC_UART1_TypeDef *UARTx, UART_MODEM_PIN_Type Pin, \
        UART1_SignalState NewState)
{
    uint8_t tmp = 0;

    CHECK_PARAM(PARAM_UART1_MODEM(UARTx));
    CHECK_PARAM(PARAM_UART1_MODEM_PIN(Pin));
    CHECK_PARAM(PARAM_UART1_SIGNALSTATE(NewState));

    switch (Pin){
    case UART1_MODEM_PIN_DTR:
        tmp = UART1_MCR_DTR_CTRL;
        break;
    case UART1_MODEM_PIN_RTS:
        tmp = UART1_MCR_RTS_CTRL;
        break;
    default:
        break;
    }

    if (NewState == ACTIVE){
        UARTx->MCR |= tmp;
    } else {
        UARTx->MCR &= (~tmp) & UART1_MCR_BITMASK;
    }
}


/*********************************************************************//**
 * @brief               Configure Full Modem mode for UART peripheral
 * @param[in]   UARTx   UART1 (only)
 * @param[in]   Mode Full Modem mode, should be:
 *                              - UART1_MODEM_MODE_LOOPBACK: Loop back mode.
 *                              - UART1_MODEM_MODE_AUTO_RTS: Auto-RTS mode.
 *                              - UART1_MODEM_MODE_AUTO_CTS: Auto-CTS mode.
 * @param[in]   NewState New State of this mode, should be:
 *                              - ENABLE: Enable this mode.
                                - DISABLE: Disable this mode.
 * @return none
 **********************************************************************/
void UART_FullModemConfigMode(LPC_UART1_TypeDef *UARTx, UART_MODEM_MODE_Type Mode, \
        FunctionalState NewState)
{
    uint8_t tmp = 0;

    CHECK_PARAM(PARAM_UART1_MODEM(UARTx));
    CHECK_PARAM(PARAM_UART1_MODEM_MODE(Mode));
    CHECK_PARAM(PARAM_FUNCTIONALSTATE(NewState));

    switch(Mode){
    case UART1_MODEM_MODE_LOOPBACK:
        tmp = UART1_MCR_LOOPB_EN;
        break;
    case UART1_MODEM_MODE_AUTO_RTS:
        tmp = UART1_MCR_AUTO_RTS_EN;
        break;
    case UART1_MODEM_MODE_AUTO_CTS:
        tmp = UART1_MCR_AUTO_CTS_EN;
        break;
    default:
        break;
    }

    if (NewState == ENABLE)
    {
        UARTx->MCR |= tmp;
    }
    else
    {
        UARTx->MCR &= (~tmp) & UART1_MCR_BITMASK;
    }
}


/*********************************************************************//**
 * @brief               Get current status of modem status register
 * @param[in]   UARTx   UART1 (only)
 * @return              Current value of modem status register
 * Note:        The return value of this function must be ANDed with each member
 *                      UART_MODEM_STAT_type enumeration to determine current flag status
 *                      corresponding to each modem flag status. Because some flags in
 *                      modem status register will be cleared after reading, the next reading
 *                      modem register could not be correct. So this function used to
 *                      read modem status register in one time only, then the return value
 *                      used to check all flags.
 **********************************************************************/
uint8_t UART_FullModemGetStatus(LPC_UART1_TypeDef *UARTx)
{
    CHECK_PARAM(PARAM_UART1_MODEM(UARTx));
    return ((UARTx->MSR) & UART1_MSR_BITMASK);
}


/*********************************************************************//**
 * @brief               Configure UART peripheral in RS485 mode according to the specified
 *               parameters in the RS485ConfigStruct.
 * @param[in]   UARTx   UART1 (only)
 * @param[in]   RS485ConfigStruct Pointer to a UART1_RS485_CTRLCFG_Type structure
 *                    that contains the configuration information for specified UART
 *                    in RS485 mode.
 * @return              None
 **********************************************************************/
void UART_RS485Config(LPC_UART1_TypeDef *UARTx, UART1_RS485_CTRLCFG_Type *RS485ConfigStruct)
{
    uint32_t tmp;

    CHECK_PARAM(PARAM_UART1_MODEM(UARTx));
    CHECK_PARAM(PARAM_FUNCTIONALSTATE(RS485ConfigStruct->AutoAddrDetect_State));
    CHECK_PARAM(PARAM_FUNCTIONALSTATE(RS485ConfigStruct->AutoDirCtrl_State));
    CHECK_PARAM(PARAM_UART1_RS485_CFG_DELAYVALUE(RS485ConfigStruct->DelayValue));
    CHECK_PARAM(PARAM_SETSTATE(RS485ConfigStruct->DirCtrlPol_Level));
    CHECK_PARAM(PARAM_UART_RS485_DIRCTRL_PIN(RS485ConfigStruct->DirCtrlPin));
    CHECK_PARAM(PARAM_UART1_RS485_CFG_MATCHADDRVALUE(RS485ConfigStruct->MatchAddrValue));
    CHECK_PARAM(PARAM_FUNCTIONALSTATE(RS485ConfigStruct->NormalMultiDropMode_State));
    CHECK_PARAM(PARAM_FUNCTIONALSTATE(RS485ConfigStruct->Rx_State));

    tmp = 0;
    // If Auto Direction Control is enabled -  This function is used in Master mode
    if (RS485ConfigStruct->AutoDirCtrl_State == ENABLE)
    {
        tmp |= UART1_RS485CTRL_DCTRL_EN;

        // Set polar
        if (RS485ConfigStruct->DirCtrlPol_Level == SET)
        {
            tmp |= UART1_RS485CTRL_OINV_1;
        }

        // Set pin according to
        if (RS485ConfigStruct->DirCtrlPin == UART1_RS485_DIRCTRL_DTR)
        {
            tmp |= UART1_RS485CTRL_SEL_DTR;
        }

        // Fill delay time
        UARTx->RS485DLY = RS485ConfigStruct->DelayValue & UART1_RS485DLY_BITMASK;
    }

    // MultiDrop mode is enable
    if (RS485ConfigStruct->NormalMultiDropMode_State == ENABLE)
    {
        tmp |= UART1_RS485CTRL_NMM_EN;
    }

    // Auto Address Detect function
    if (RS485ConfigStruct->AutoAddrDetect_State == ENABLE)
    {
        tmp |= UART1_RS485CTRL_AADEN;
        // Fill Match Address
        UARTx->ADRMATCH = RS485ConfigStruct->MatchAddrValue & UART1_RS485ADRMATCH_BITMASK;
    }


    // Receiver is disable
    if (RS485ConfigStruct->Rx_State == DISABLE)
    {
        tmp |= UART1_RS485CTRL_RX_DIS;
    }

    // write back to RS485 control register
    UARTx->RS485CTRL = tmp & UART1_RS485CTRL_BITMASK;

    // Enable Parity function and leave parity in stick '0' parity as default
    UARTx->LCR |= (UART_LCR_PARITY_F_0 | UART_LCR_PARITY_EN);
}


/**
 * @brief               Enable/Disable receiver in RS485 module in UART1
 * @param[in]   UARTx           UART1 only.
 * @param[in]   NewState        New State of command, should be:
 *                                                      - ENABLE: Enable this function.
 *                                                      - DISABLE: Disable this function.
 * @return              None
 */
void UART_RS485ReceiverCmd(LPC_UART1_TypeDef *UARTx, FunctionalState NewState)
{
    if (NewState == ENABLE){
        UARTx->RS485CTRL &= ~UART1_RS485CTRL_RX_DIS;
    } else {
        UARTx->RS485CTRL |= UART1_RS485CTRL_RX_DIS;
    }
}


/**
 * @brief               Send data on RS485 bus with specified parity stick value (9-bit mode).
 * @param[in]   UARTx           UART1 (only).
 * @param[in]   pDatFrm         Pointer to data frame.
 * @param[in]   size            Size of data.
 * @param[in]   ParityStick     Parity Stick value, should be 0 or 1.
 * @return              None.
 */
uint32_t UART_RS485Send(LPC_UART1_TypeDef *UARTx, uint8_t *pDatFrm, \
        uint32_t size, uint8_t ParityStick)
{
    uint8_t tmp, save;
    uint32_t cnt;

    if (ParityStick){
        save = tmp = UARTx->LCR & UART_LCR_BITMASK;
        tmp &= ~(UART_LCR_PARITY_EVEN);
        UARTx->LCR = tmp;
        cnt = UART_Send((LPC_UART_TypeDef *)UARTx, pDatFrm, size, BLOCKING);
        while (!(UARTx->LSR & UART_LSR_TEMT));
        UARTx->LCR = save;
    } else {
        cnt = UART_Send((LPC_UART_TypeDef *)UARTx, pDatFrm, size, BLOCKING);
        while (!(UARTx->LSR & UART_LSR_TEMT));
    }
    return cnt;
}


/**
 * @brief               Send Slave address frames on RS485 bus.
 * @param[in]   UARTx UART1 (only).
 * @param[in]   SlvAddr Slave Address.
 * @return              None.
 */
void UART_RS485SendSlvAddr(LPC_UART1_TypeDef *UARTx, uint8_t SlvAddr)
{
    UART_RS485Send(UARTx, &SlvAddr, 1, 1);
}


/**
 * @brief               Send Data frames on RS485 bus.
 * @param[in]   UARTx UART1 (only).
 * @param[in]   pData Pointer to data to be sent.
 * @param[in]   size Size of data frame to be sent.
 * @return              None.
 */
uint32_t UART_RS485SendData(LPC_UART1_TypeDef *UARTx, uint8_t *pData, uint32_t size)
{
    return (UART_RS485Send(UARTx, pData, size, 0));
}

#endif /* _UART1 */


/* Additional driver APIs ----------------------------------------------------------------------- */

/*********************************************************************//**
 * @brief               Send a block of data via UART peripheral
 * @param[in]   UARTx   Selected UART peripheral used to send data,
 *                              should be UART0, UART1, UART2 or UART3.
 * @param[in]   txbuf   Pointer to Transmit buffer
 * @param[in]   buflen  Length of Transmit buffer
 * @param[in]   flag    Flag used in  UART transfer, should be
 *                                              NONE_BLOCKING or BLOCKING
 * @return              Number of bytes sent.
 *
 * Note: when using UART in BLOCKING mode, a time-out condition is used
 * via defined symbol UART_BLOCKING_TIMEOUT.
 **********************************************************************/
uint32_t UART_Send(LPC_UART_TypeDef *UARTx, uint8_t *txbuf,
        uint32_t buflen, TRANSFER_BLOCK_Type flag)
{
    uint32_t bToSend, bSent, timeOut, fifo_cnt;
    uint8_t *pChar = txbuf;

    bToSend = buflen;

    // blocking mode
    if (flag == BLOCKING) {
        bSent = 0;
        while (bToSend){
            timeOut = UART_BLOCKING_TIMEOUT;
            // Wait for THR empty with timeout
            while (!(UARTx->LSR & UART_LSR_THRE)) {
                if (timeOut == 0) break;
                timeOut--;
            }
            // Time out!
            if(timeOut == 0) break;
            fifo_cnt = UART_TX_FIFO_SIZE;
            while (fifo_cnt && bToSend){
                UART_SendData(UARTx, (*pChar++));
                fifo_cnt--;
                bToSend--;
                bSent++;
            }
        }
    }
    // None blocking mode
    else {
        bSent = 0;
        while (bToSend) {
            if (!(UARTx->LSR & UART_LSR_THRE)){
                break;
            }
            fifo_cnt = UART_TX_FIFO_SIZE;
            while (fifo_cnt && bToSend) {
                UART_SendData(UARTx, (*pChar++));
                bToSend--;
                fifo_cnt--;
                bSent++;
            }
        }
    }
    return bSent;
}

/*********************************************************************//**
 * @brief               Receive a block of data via UART peripheral
 * @param[in]   UARTx   Selected UART peripheral used to send data,
 *                              should be UART0, UART1, UART2 or UART3.
 * @param[out]  rxbuf   Pointer to Received buffer
 * @param[in]   buflen  Length of Received buffer
 * @param[in]   flag    Flag mode, should be NONE_BLOCKING or BLOCKING

 * @return              Number of bytes received
 *
 * Note: when using UART in BLOCKING mode, a time-out condition is used
 * via defined symbol UART_BLOCKING_TIMEOUT.
 **********************************************************************/
uint32_t UART_Receive(LPC_UART_TypeDef *UARTx, uint8_t *rxbuf, \
        uint32_t buflen, TRANSFER_BLOCK_Type flag)
{
    uint32_t bToRecv, bRecv, timeOut;
    uint8_t *pChar = rxbuf;

    bToRecv = buflen;

    // Blocking mode
    if (flag == BLOCKING) {
        bRecv = 0;
        while (bToRecv){
            timeOut = UART_BLOCKING_TIMEOUT;
            while (!(UARTx->LSR & UART_LSR_RDR)){
                if (timeOut == 0) break;
                timeOut--;
            }
            // Time out!
            if(timeOut == 0) break;
            // Get data from the buffer
            (*pChar++) = UART_ReceiveData(UARTx);
            bToRecv--;
            bRecv++;
        }
    }
    // None blocking mode
    else {
        bRecv = 0;
        while (bToRecv) {
            if (!(UARTx->LSR & UART_LSR_RDR)) {
                break;
            } else {
                (*pChar++) = UART_ReceiveData(UARTx);
                bRecv++;
                bToRecv--;
            }
        }
    }
    return bRecv;
}


/*********************************************************************//**
 * @brief               Setup call-back function for UART interrupt handler for each
 *                              UART peripheral
 * @param[in]   UARTx   Selected UART peripheral, should be UART0..3
 * @param[in]   CbType  Call-back type, should be:
 *                                              0 - Receive Call-back
 *                                              1 - Transmit Call-back
 *                                              2 - Auto Baudrate Callback
 *                                              3 - Error Call-back
 *                                              4 - Modem Status Call-back (UART1 only)
 * @param[in]   pfnCbs  Pointer to Call-back function
 * @return              None
 **********************************************************************/
void UART_SetupCbs(LPC_UART_TypeDef *UARTx, uint8_t CbType, void *pfnCbs)
{
    uint8_t pUartNum;

    pUartNum = getUartNum(UARTx);
    switch(CbType){
    case 0:
        uartCbsDat[pUartNum].pfnRxCbs = (fnTxCbs_Type *)pfnCbs;
        break;
    case 1:
        uartCbsDat[pUartNum].pfnTxCbs = (fnRxCbs_Type *)pfnCbs;
        break;
    case 2:
        uartCbsDat[pUartNum].pfnABCbs = (fnABCbs_Type *)pfnCbs;
        break;
    case 3:
        uartCbsDat[pUartNum].pfnErrCbs = (fnErrCbs_Type *)pfnCbs;
        break;
    case 4:
        pfnModemCbs = (fnModemCbs_Type *)pfnCbs;
        break;
    default:
        break;
    }
}

/*********************************************************************//**
 * @brief               Standard UART0 interrupt handler
 * @param[in]   None
 * @return              None
 **********************************************************************/
void UART0_StdIntHandler(void)
{
    UART_GenIntHandler(LPC_UART0);
}

/*********************************************************************//**
 * @brief               Standard UART1 interrupt handler
 * @param[in]   None
 * @return              None
 **********************************************************************/
void UART1_StdIntHandler(void)
{
    UART_GenIntHandler((LPC_UART_TypeDef *)LPC_UART1);
}

/*********************************************************************//**
 * @brief               Standard UART2 interrupt handler
 * @param[in]   None
 * @return              None
 **********************************************************************/
void UART2_StdIntHandler(void)
{
    UART_GenIntHandler(LPC_UART2);
}

/*********************************************************************//**
 * @brief               Standard UART3 interrupt handler
 * @param[in]   None
 * @return
 **********************************************************************/
void UART3_StdIntHandler(void)
{
    UART_GenIntHandler(LPC_UART3);
}

/**
 * @}
 */


#endif /* _UART */

/**
 * @}
 */

/* --------------------------------- End Of File ------------------------------ */
