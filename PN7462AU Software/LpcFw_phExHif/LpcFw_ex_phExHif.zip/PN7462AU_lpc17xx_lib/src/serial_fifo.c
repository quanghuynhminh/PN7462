/*
 *                  Copyright (c), NXP Semiconductors
 *
 *                     (C)NXP Semiconductors
 *       All rights are reserved. Reproduction in whole or in part is
 *      prohibited without the written consent of the copyright owner.
 *  NXP reserves the right to make changes without notice at any time.
 * NXP makes no warranty, expressed, implied or statutory, including but
 * not limited to any implied warranty of merchantability or fitness for any
 *particular purpose, or that the use will not infringe any third party patent,
 * copyright or trademark. NXP must not be liable for any loss or damage
 *                          arising from its use.
 */

/** \file
 * lpcusb_type.c
 * $Author: nxp47613 $
 * $Revision: 001 $
 * $Date: 2013-07-26 10:28:17 +0530 (Fri, 26 Jul 2013) $
 *
 * History:
 *
 */
#include "lpcusb_type.h"
#include "serial_fifo.h"

void fifo_init(fifo_t *fifo, U8 *buf)
{
    fifo->head = 0;
    fifo->tail = 0;
    fifo->buf = buf;
}

void fifo_flush(fifo_t *fifo)
{
    fifo->head = 0;
    fifo->tail = 0;
}
BOOL fifo_put(fifo_t *fifo, U8 c)
{
    int next;

    // check if FIFO has room
    next = (fifo->head + 1) % VCOM_FIFO_SIZE;
    if (next == fifo->tail) {
        // full
        return FALSE;
    }

    fifo->buf[fifo->head] = c;
    fifo->head = next;

    return TRUE;
}


BOOL fifo_get(fifo_t *fifo, U8 *pc)
{
    int next;

    // check if FIFO has data
    if (fifo->head == fifo->tail) {
        return FALSE;
    }

    next = (fifo->tail + 1) % VCOM_FIFO_SIZE;

    *pc = fifo->buf[fifo->tail];
    fifo->tail = next;

    return TRUE;
}


int fifo_avail(fifo_t *fifo)
{
    return (VCOM_FIFO_SIZE + fifo->head - fifo->tail) % VCOM_FIFO_SIZE;
}


int fifo_free(fifo_t *fifo)
{
    return (VCOM_FIFO_SIZE - 1 - fifo_avail(fifo));
}
