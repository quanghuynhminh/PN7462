/*
 * DUT_I2C.c
 *
 *  Created on: Mar 27, 2014
 *      Author: nxp74831
 */

#include "lpc_ExHif_HW.h"
#include "lpcExHif_config.h"
#include "string.h"
#include "delay.h"
#include "stdio.h"
#include "phExHif_Log.h"
/*******************************************************************************************************************
 *                                      LOCAL DEFINES
 ******************************************************************************************************************/
/* Buf mask */
#define __BUF_MASK (BUFSIZE-1)
/* Check buf is full or not */
#define __BUF_IS_FULL(head, tail) ((tail&__BUF_MASK)==((head+1)&__BUF_MASK))
/* Check buf will be full in next receiving or not */
#define __BUF_WILL_FULL(head, tail) ((tail&__BUF_MASK)==((head+2)&__BUF_MASK))
/* Check buf is empty */
#define __BUF_IS_EMPTY(head, tail) ((head&__BUF_MASK)==(tail&__BUF_MASK))
/* Reset buf */
#define __BUF_RESET(bufidx) (bufidx=0)
#define __BUF_INCR(bufidx)  (bufidx=(bufidx+1)&__BUF_MASK)

#define RTS_MASK    (1<<7)
#define UART1_RTS_OUTPUT    LPC_GPIO2->FIODIR |= RTS_MASK
#define UART1_RTS_SET       LPC_GPIO2->FIOSET |= RTS_MASK
#define UART1_RTS_CLEAR     LPC_GPIO2->FIOCLR |= RTS_MASK

#define CTS_MASK    (1<<17)
#define UART1_CTS_INPUT         (LPC_GPIO0->FIODIR &= ~(CTS_MASK))
#define UART1_CTS_SET_LOW       (LPC_PINCON->PINMODE1 |= (3<<2))
#define UART1_GET_CTS_VAL       (LPC_GPIO0->FIOPIN & (CTS_MASK))

/* Number of APDU's checked for card inserted.
 *  Increment the count here if NEW APDU's are added
 */
#define PH_EXHIFCT_MAX_NO_APDU          10
/*******************************************************************************************************************
 *                                      LOCAL Variables
 ******************************************************************************************************************/
uint8_t MasterTxBuffer[BUFSIZE];
uint8_t MasterRxBuffer[BUFSIZE];

/* *****************************************************************************************************************
 * Global and Static Variables
 * Total Size: NNNbytes
 * ***************************************************************************************************************** */

/*  Add NEW APDU's here */
static const uint8_t bApduCommandArray[PH_EXHIFCT_MAX_NO_APDU][32] =
{
    /* SELECT MasterCard credit or debit command */
    {0x00,0xA4,0x04,0x00,0x07,0xA0,0x00,0x00,0x00,0x04,0x10,0x10,0x00},

    /* SELECT Visa credit or debit card command */
    {0x00,0xA4,0x04,0x00,0x07,0xA0,0x00,0x00,0x00,0x03,0x10,0x10,0x00},

    /* SELECT Maestro (debit card) command */
    {0x00,0xA4,0x04,0x00,0x07,0xA0,0x00,0x00,0x00,0x04,0x30,0x60,0x00},

    /* SELECT Cirrus (interbank network) ATM card only command */
    {0x00,0xA4,0x04,0x00,0x07,0xA0,0x00,0x00,0x00,0x04,0x60,0x00,0x00},

    /* SELECT Maestro UK card command */
    {0x00,0xA4,0x04,0x00,0x07,0xA0,0x00,0x00,0x00,0x05,0x00,0x01,0x00},

    /* SELECT Visa Electron card command */
    {0x00,0xA4,0x04,0x00,0x07,0xA0,0x00,0x00,0x00,0x03,0x20,0x10,0x00},

    /* SELECT V PAY command */
    {0x00,0xA4,0x04,0x00,0x07,0xA0,0x00,0x00,0x00,0x03,0x20,0x20,0x00},

    /* SELECT VISA Plus card command */
    {0x00,0xA4,0x04,0x00,0x07,0xA0,0x00,0x00,0x00,0x03,0x80,0x10,0x00},

    /* SELECT Amex card */
    {0x00,0xA4,0x04,0x00,0x06,0xA0,0x00,0x00,0x00,0x25,0x01,0x00},

    /* Get Version SAM Card*/
    {0x80,0x60,0x00,0x00,0x00},
};


/** Stores the APDU length */
static const uint8_t bApduCommandLength[PH_EXHIFCT_MAX_NO_APDU]=
{
    13,13,13,
    13,13,13,
    13,13,12,
    5
};

static const char bApduInfo[PH_EXHIFCT_MAX_NO_APDU][50]=
{
   {"Master Card : Credit or Debit\n"},
   {"Visa Card   : Credit or Debit\n"},
   {"Master Card : Maestro(debit card)\n"},
   {"Master Card : Cirrus(interbank network)\n"},
   {"Master Card : Maestro UK\n"},
   {"Visa Card   : Electron card\n"},
   {"Visa Card   : V PAY card\n"},
   {"Visa Card   : VISA Plus card\n"},
   {"Amex Card\n"},
   {"SAM Card    : GetVersion Command\n"}
};




/*********************************************************************************************************************
 *                                      Private Functions
 *******************************************************************************************************************/
/*
 *Function Name     : LPC_I2Cx_S_Config
 *Description       :Used for I2C slave configuration for communication
 *
 *Input Parameters  :I2C channel
 *Output Parameters :Status 1. SUCCESS
 *                          2. ERROR
 *
 *Note:             :The Interrupt of the slave is disabled everytime a transaction completes.
 */
Status LPC_I2Cx_S_Config(
    LPC_I2C_TypeDef *I2Cx)
{
    I2C_SlaveCfg.tx_length = sizeof(SlaveI2CTxBuffer);
    I2C_SlaveCfg.tx_data = SlaveI2CTxBuffer;

    I2C_SlaveCfg.rx_length = sizeof(SlaveI2CRxBuffer);
    I2C_SlaveCfg.rx_data = SlaveI2CRxBuffer;
    I2C_SlaveCfg.rx_count = I2C_SlaveCfg.tx_count = 0;

    return (I2C_SlaveTransferData(I2Cx, &I2C_SlaveCfg, I2C_TRANSFER_INTERRUPT));

}

/*Interrupt handler for the I2C2 peripheral*/
void I2C2_IRQHandler(
    void)
{
    I2C_SlaveHandler(LPC_I2C2);
}

void SSP1_IRQHandler()
{
    SSP1_StdIntHandler();

}

/********************************************************************//**
 * @brief       UART1 receive function (ring buffer used)
 * @param[in]   None
 * @return      None
 *********************************************************************/
void UART1_IntReceive(
    void)
{
    uint8_t tmpc;
    uint32_t rLen;

    while (1)
    {
        // Call UART read function in UART driver
        rLen = UART_Receive((LPC_UART_TypeDef *) LPC_UART1, &tmpc, 1, NONE_BLOCKING);
        // If data received
        if (rLen)
        {

            /* Check if buffer is more space
             * If no more space, remaining character will be trimmed out
             */
            if (!__BUF_IS_FULL(rb.rx_head, rb.rx_tail))
            {
                rb.rx[rb.rx_head] = tmpc;
                __BUF_INCR(rb.rx_head);
            }
        }
        // no more data
        else
        {
            break;
        }
    }
}

/*********************************************************************//**
 * @brief       UART Line Status Error
 * @param[in]   bLSErrType  UART Line Status Error Type
 * @return      None
 **********************************************************************/
void UART_IntErr(
    uint8_t bLSErrType)
{

    // Loop forever
    while (1)
    {
        LPC_GPIO0->FIOSET |= (1 << 22);
        delay(500);
        LPC_GPIO0->FIOCLR |= (1 << 22);
        delay(500);
        // For testing purpose
    }
}

/* @brief       UART Line Status Error
 * @param[in]   bLSErrType  UART Line Status Error Type
 * @return      None
 **********************************************************************/
Status GET_CTS_STATUS(
    void)
{
    if (UART1_GET_CTS_VAL)
        return ERROR;
    else
        return SUCCESS;
}

/*********************************************************************//**
 * @brief       UART1 interrupt handler sub-routine
 * @param[in]   None
 * @return      None
 **********************************************************************/
void UART1_IRQHandler(
    void)
{
    //uint8_t modemsts;
    uint32_t intsrc, tmp, tmp1;

    /* Determine the interrupt source */
    intsrc = UART_GetIntId((LPC_UART_TypeDef *) LPC_UART1);
    tmp = intsrc & UART_IIR_INTID_MASK;

    /*
     * In case of using UART1 with full modem,
     * interrupt ID = 0 that means modem status interrupt has been detected
     */
    // Receive Line Status
    if (tmp == UART_IIR_INTID_RLS)
    {
        // Check line status
        tmp1 = UART_GetLineStatus((LPC_UART_TypeDef *) LPC_UART1);
        // Mask out the Receive Ready and Transmit Holding empty status
        tmp1 &= (UART_LSR_OE | UART_LSR_PE | UART_LSR_FE
            | UART_LSR_BI | UART_LSR_RXFE);
        //If any error exist
        if (tmp1)
        {
            UART_IntErr(tmp1);
        }
    }

    // Receive Data Available or Character time-out
    if ((tmp == UART_IIR_INTID_RDA) || (tmp == UART_IIR_INTID_CTI))
    {
        UART1_IntReceive();
    }
}

/*API to populate the transmit buffer*/
void Lpc_ExHif_HW_Init_BUffer(
    uint16_t wBuffLength)
{
    uint16_t wlength;
    for (wlength = 0; wlength < wBuffLength; wlength++)
        MasterTxBuffer[wlength] = 0xAA; //(uint8_t)(wlength%255);
}

/*I2C related private functions*/
uint16_t Lpc_EXHIF_I2CTx(
    LPC_I2C_TypeDef *I2Cx, uint8_t *buff, uint16_t len, uint8_t slaveAddr)
{
    I2C_M_SETUP_Type Send_M_data;
    Send_M_data.sl_addr7bit = slaveAddr;
    Send_M_data.tx_length = len;
    Send_M_data.tx_data = buff;
    Send_M_data.rx_data = NULL;
    Send_M_data.rx_length = 0;
    Send_M_data.retransmissions_max = 2;
    return (I2C_MasterTransferData(I2Cx, &Send_M_data, I2C_TRANSFER_POLLING));
}

uint16_t Lpc_ExHif_I2CRx(
    LPC_I2C_TypeDef *I2Cx, uint8_t *pbBuff, uint16_t wlen, uint8_t bslaveAddr, uint8_t bCommChannel)
{
    uint16_t wRecvLength = 0;
    if (bCommChannel == 0 || bCommChannel == 4)
    {
        I2C_M_SETUP_Type Receive_data;
        Receive_data.sl_addr7bit = bslaveAddr;
        Receive_data.rx_data = pbBuff;
        Receive_data.tx_length = 0;
        Receive_data.rx_length = wlen;
        Receive_data.tx_data = NULL;
        Receive_data.retransmissions_max = 5;
        if (I2C_MasterTransferData(I2Cx, &Receive_data, I2C_TRANSFER_POLLING))
            wRecvLength = ((uint16_t) Receive_data.rx_count);
        else
            wRecvLength = 0;
    }
    else
    {
        /* while (I2C_SlaveCfg.rx_count != wlen); */
        delay(2000);
        /*I2C Slave Receive*/
        if ((I2C_SlaveCfg.rx_count) == (wlen))
        {
            wRecvLength = (uint16_t) (I2C_SlaveCfg.rx_count);
            I2C_SlaveCfg.rx_count = 0;
        }
        else
        {
            wRecvLength = 0;
        }
    }
    return wRecvLength;
}

/*SPI related private functions*/
uint16_t Lpc_ExHIF_SPITx(
    LPC_SSP_TypeDef *SSPx, uint8_t *buff, uint16_t len)
{
    uint16_t wRet;

    SSP_DATA_SETUP_Type SSPx_M_Send;
    SSPx_M_Send.tx_data = buff;
    SSPx_M_Send.length = len;
    SSPx_M_Send.rx_data = NULL;

    Chip_GPIO_SetPinState(LPC_GPIO_0, Port0, SSP_SSEL0, 0);
    wRet = SSP_ReadWrite(SSPx, &SSPx_M_Send, SSP_TRANSFER_POLLING);
    Chip_GPIO_SetPinState(LPC_GPIO_0, Port0, SSP_SSEL0, 1);
    if (wRet != 0)
        return ((uint16_t) SSPx_M_Send.tx_cnt);
    else
        return 0;
}

uint16_t Lpc_ExHIF_SPIRx(
    LPC_SSP_TypeDef *SSPx, uint8_t *pbBuff, uint16_t wlen, uint8_t bCommChannel)
{
    uint16_t wRecvLength;
    if (bCommChannel == 0 || bCommChannel == 4 || bCommChannel == 5 || bCommChannel == 6)
    {
        /*Master receive*/
        SSP_DATA_SETUP_Type SSPx_M_Receive;
        SSPx_M_Receive.tx_data = NULL;
        SSPx_M_Receive.rx_data = pbBuff;
        SSPx_M_Receive.length = wlen + 1;/*Read one extra byte as PN640 slave take direction indicator as first byte*/
        Chip_GPIO_SetPinState(LPC_GPIO_0, Port0, SSP_SSEL0, 0);
        if (SSP_ReadWrite(SSPx, &SSPx_M_Receive, SSP_TRANSFER_POLLING))
        {
            Chip_GPIO_SetPinState(LPC_GPIO_0, Port0, SSP_SSEL0, 1);
            return ((uint16_t) SSPx_M_Receive.rx_cnt);/*Successful reception of the data*/
        }
        else
        {
            Chip_GPIO_SetPinState(LPC_GPIO_0, Port0, SSP_SSEL0, 1);
            return 0;/*Failed to receive the data*/
        }
    }
    else
    {
    	if(SSP_slave_cfg_t.rx_cnt != wlen)
    	{
    		LOG_TXT("TRANSACTION COMPLETED");
    		while (SSP_slave_cfg_t.rx_cnt != wlen)
    			;
    	}
        /* Wait for the complete data reception*/
        /*SSP1 Slave Receive*/
        if (SSP_slave_cfg_t.rx_cnt == (wlen))
        {
            wRecvLength = (uint16_t) (SSP_slave_cfg_t.rx_cnt);
            SSP_slave_cfg_t.rx_cnt = 0;
            return (wRecvLength);
        }
        else
        {
            return 0;
        }
    }
}

/*HSU related private functions*/
uint16_t Lpc_ExHIF_HSUTx(
    LPC_UART_TypeDef *UARTx, uint8_t *pbBuff, uint16_t wlen)
{
    uint16_t ret;
    while (UART_CheckBusy(UARTx) == SET)
        ;
    /*Checking for CTS before transmitting*/
    if (GET_CTS_STATUS())
    {
        ret = UART_Send(UARTx, pbBuff, wlen, BLOCKING);
        if (ret != wlen)
            return 0; //ERROR
        else
            return ret; //SUCCESS
    }
    else
        return 0; //CTS UNAVAILABLE
}

uint16_t Lpc_ExHIF_HSURx(
    LPC_UART_TypeDef *UARTx, uint16_t wlen)
{
    //while(rb.rx_head == rb.rx_tail);
    while (rb.rx_head != (wlen));

    //delay(200);/*Temporary timeout of 200ms waiting for the HSU Rx to complete*/
    while (!(UARTx->IIR & 0x01))
        ;
    NVIC_DisableIRQ(UART1_IRQn);
    UART1_RTS_SET;/*To disable accepting of data when LPC is responding to PC*/
    if (rb.rx_head != rb.rx_tail)
    {
        if (((rb.rx_head) - (rb.rx_tail)) == (wlen))
        {
            /*Success*/
            return (((rb.rx_head) - (rb.rx_tail)));
        }
    }
    return 0;
}

/**************************************************LED blinker to indidcate pass and failure**************
 *
 *val =0 Fail
 *val =1 Pass
 *********************************************************************************************************/

void Pass_Fail_indicator(
    uint8_t val)
{
    uint16_t time;
    if (val)
        time = 200;
    else
        time = 2000;

    LPC_GPIO0->FIOSET |= (1 << 22);
    delay(time);
    LPC_GPIO0->FIOCLR |= (1 << 22);
    delay(time);
    LPC_GPIO0->FIOSET |= (1 << 22);
    delay(time);
    LPC_GPIO0->FIOCLR |= (1 << 22);
}

uint32_t Get_Systick_CurrentValue(
    void)
{
    return SysTick->VAL;
}

/*********************************************************************************************************************
 *                                      Public Functions
 *******************************************************************************************************************/

/* Get status of the Data IRQ pin*/
Bool lpc_ExHif_GetRxPin(
    void)
{
    /*Return Data Ready IRQ pin status. */
    if (GET_IRQ_CMD_PIN)
        return true;
    else
        return false;
}

/* Get status of the Data READY pin*/
Bool lpc_ExHif_GetDataReadyPin(
    void)
{
    /*Return Data Ready IRQ pin status. */
    if (GET_DATA_READY_PIN)
        return true;
    else
        return false;
}

/******************************************I2C Peripheral Configuration*********************************************/

/*
 *Function Name     : LPC_I2C_Init
 *Description       : Used for I2C Peripheral Initialization
 *
 *Input Parameters  : I2C channel
 *Input             : Function number of the pins
 *Input             : Port Number of the PINS
 *Input             : SDA pin number
 *Input             : SCL pin Num
 *Input             : Clockrate
 *Output Parameters :
 *
 *Note:             :
 */
void LPC_I2C_Init(
    LPC_I2C_TypeDef *I2Cx, uint8_t bfnum, uint8_t bportnum, uint8_t bSDA_pinnum, uint8_t bSCL_pinnum,
    uint32_t dwclockrate)
{
    PINSEL_CFG_Type PinCfg;

    PinCfg.OpenDrain = PINSEL_PINMODE_OPENDRAIN;
    PinCfg.Pinmode = PINSEL_PINMODE_TRISTATE;
    PinCfg.Funcnum = bfnum;
    PinCfg.Portnum = bportnum;

    PinCfg.Pinnum = bSDA_pinnum;/*SDA0 Pin of I2C0 port0 pin 27*/
    PINSEL_ConfigPin(&PinCfg);

    PinCfg.Pinnum = bSCL_pinnum;/*SCL0 Pin of I2C0 port0 pin 28*/
    PINSEL_ConfigPin(&PinCfg);

    I2C_Init(I2Cx, dwclockrate);

    /*To enable I2Cx*/
    I2C_Cmd(I2Cx, ENABLE);
}

void LPC_I2C_SlaveConfig(
    LPC_I2C_TypeDef *I2Cx, uint8_t bSlaveAddr)
{
    I2C_OWNSLAVEADDR_CFG_Type I2C2_Slavecfg;
    I2C2_Slavecfg.GeneralCallState = ENABLE;
    I2C2_Slavecfg.SlaveAddrChannel = 0;
    I2C2_Slavecfg.SlaveAddrMaskValue = 0;
    I2C2_Slavecfg.SlaveAddr_7bit = bSlaveAddr;

    /*Configure the slave address and other parameters*/
    I2C_SetOwnSlaveAddr(LPC_I2C2, &I2C2_Slavecfg);

    /*Initialise the Slave Buffers*/
    LPC_I2Cx_S_Config(I2Cx);
}

/*I2C TxRX function with a variable to perform only Rx on slave and master*/
void Lpc_ExHIF_I2C_TxRx(
    LPC_I2C_TypeDef *I2Cx, uint8_t bCommChannel)
{
    uint16_t phwRetStatus = 0;
    uint8_t phbPageNum;
    uint8_t phbUserPageStart;
    uint8_t phbUserPageEnd;

    switch (bCommChannel)
    {
    case PH_EXHIF_LOOPBACK:
        case PH_EXHIF_I2CM:
        case PH_EXHIF_SPIM:
        case PH_EXHIF_I2CM_SPIM:
        /*Populate the buffer to be transmitted*/
        Lpc_ExHif_HW_Init_BUffer(LPC_EXHIF_BUFFERSIZE);

        /** Wait for the DATA READY line to be asserted by PN640 before sending data */
        while (!lpc_ExHif_GetDataReadyPin());

        /*Always transmit over Master interface*/
        phwRetStatus = Lpc_EXHIF_I2CTx(I2Cx, MasterTxBuffer, LPC_EXHIF_BUFFERSIZE,
        LPC_EXHIF_I2C_SLAVE_ADDR);

        /* Added delay to ensure the data received over SPI or I2C interrupt is received correctly.*/
        if ((bCommChannel & 2) == 2)
            delay(1000);

        if (phwRetStatus != 0)
        {
            LOG_TXT("uHost: I2C Master Tx : SUCCESS");
            /*Receive over I2C Master or Slave when the communication channel is 1 or 3*/
            if ((bCommChannel == 0) || ((bCommChannel & 1) == 1))
            {
                while ((!lpc_ExHif_GetRxPin()) && !bCommChannel);

                phwRetStatus = 0;
                phwRetStatus = Lpc_ExHif_I2CRx(LPC_I2C0, MasterRxBuffer, LPC_EXHIF_BUFFERSIZE,
                LPC_EXHIF_I2C_SLAVE_ADDR, bCommChannel);

                if (phwRetStatus == 0)
                {
                    /*Failure scenario due to reception failure*/
                    if (!bCommChannel)
                    {
                        LOG_TXT("uHost: I2C Master Rx : FAILED");
                        Pass_Fail_indicator(0);
                    }
                }
                else
                {
                    /*Used for reception on I2C Master when the communication channel is 0*/
                    if (bCommChannel == 0)
                    {
                        /*compare the data received on the master*/
                        if (!memcmp((uint8_t *) MasterTxBuffer, (uint8_t *) MasterRxBuffer, LPC_EXHIF_BUFFERSIZE))
                        {
                            /*Loopback was Successful*/
                            LOG_TXT("uHost: I2C Master Rx : SUCCESS");
                            Pass_Fail_indicator(1);
                        }
                        else
                        {
                            /*Received buffer mismatch. Loopback Failed*/
                            LOG_TXT("uHost: I2C Master Rx : FAILED");
                            Pass_Fail_indicator(0);
                        }
                    }
                    else
                    {
                        /*Data received on the slave needs to be verified*/
                        LOG_TXT("uHost: I2C SLAVE Rx : SUCCESS");
                        Pass_Fail_indicator(1);
                    }
                }
            }

            /*Used for reception on SPI slave when the communication channel is 2 or 3*/
            if ((bCommChannel & 2) == 2)
            {
                delay(50);
                phwRetStatus = 0;
                phwRetStatus = Lpc_ExHIF_SPIRx(LPC_SSP1, NULL, LPC_EXHIF_BUFFERSIZE, bCommChannel);

                if ((phwRetStatus != 0)
                    && (!memcmp((uint8_t *) SSP_slave_cfg_t.rx_data, MasterTxBuffer, LPC_EXHIF_BUFFERSIZE)))
                {
                    /*Success on  SPI Slave reception*/
                    LOG_TXT("uHost: SPI SLAVE Rx : SUCCESS");
                    Pass_Fail_indicator(1);
                }
                else
                {
                    /*Failure on SPI Slave reception*/
                    Pass_Fail_indicator(0);
                }
            }
        }
        else
        {
            /*Failed to transmit*/
            LOG_TXT("uHost: I2C Master Tx : FAILED");
        }
        break;
        /*Write to the EEPROM Pagewise*/
    case PH_EXHIF_EEPROM_WRITE:

        /*Use for EEPROM Communication Channel*/
        phbUserPageStart = ((((PH_EXHIF_EEPROM_SIZE) - (PH_EXHIF_USER_EEPROM_SIZE)) / (PH_EXHIF_EEPROM_PAGE_SIZE)) + 5);
        phbUserPageEnd = (PH_EXHIF_EEPROM_SIZE) / (PH_EXHIF_EEPROM_PAGE_SIZE);

        for (phbPageNum = phbUserPageStart; phbPageNum < phbUserPageEnd; phbPageNum++)
        {
            uint8_t i;
            delay(5);
            MasterTxBuffer[64] = phbPageNum;
            /*Populate the Data for EEPROM*/
            for (i = 0; i < PH_EXHIF_EEPROM_PAGE_SIZE; i++)
            {
                MasterTxBuffer[i] = ((i * phbPageNum) % 255);
            }

            /** Wait for the DATA READY line to be asserted by PN640 before sending data */
            while (!lpc_ExHif_GetDataReadyPin());

            /*Always transmit over Master interface*/
            if (Lpc_EXHIF_I2CTx(I2Cx, MasterTxBuffer, (PH_EXHIF_EEPROM_PAGE_SIZE + 1), LPC_EXHIF_I2C_SLAVE_ADDR))
            {
                //delay(1000);
                while ((!lpc_ExHif_GetRxPin()));
                Lpc_ExHif_I2CRx(LPC_I2C0, MasterRxBuffer, 2, LPC_EXHIF_I2C_SLAVE_ADDR, bCommChannel);
                if (((MasterRxBuffer[0] << 8) | (MasterRxBuffer[1])) == 0)
                {
                    /*Received response*/
                    Pass_Fail_indicator(1);
#ifndef NDEBUG
                    printf("EEPROM Write response is SUCCESS(%d) for Sector %d\n",
                        ((MasterRxBuffer[0] << 8) | (MasterRxBuffer[1])), phbPageNum);
#endif
                }
                else
                {
                    /*Failed Response*/
                    Pass_Fail_indicator(0);
#ifndef NDEBUG
                    printf("EEPROM Write response is FAIL(%d) for Sector %d\n",
                        ((MasterRxBuffer[0] << 8) | (MasterRxBuffer[1])), phbPageNum);
#endif
                }
            }
            else
            {
                /*Transmit to PN640 failed.*/
                LOG_TXT("uHost: I2C MASTER Tx : FAILED");
            }
            /*Reinit the Receive Queue in PN640*/
            CLEAR_GPIO_HIF_INTERACE_L;
            CLEAR_GPIO_HIF_INTERACE_H;

            delay(500);

            SET_GPIO_HIF_INTERACE_L;
            CLEAR_GPIO_HIF_INTERACE_H;
        }
        break;
#if PH_EXHIF_ENABLE_PERFORMANCE
        case PH_EXHIF_PERFORMANCE:
        /* Run the performance about 1K times */
        /*Populate the buffer to be transmitted*/
        Lpc_ExHif_HW_Init_BUffer(LPC_EXHIF_BUFFERSIZE);

        /** Wait for the DATA READY line to be asserted by PN640 before sending data */
        while(!lpc_ExHif_GetDataReadyPin());

        /*Always transmit over Master interface*/
        phwRetStatus = Lpc_EXHIF_I2CTx(I2Cx,MasterTxBuffer,LPC_EXHIF_BUFFERSIZE,
            LPC_EXHIF_I2C_SLAVE_ADDR);
        break;
#endif
    default:
        /*Not Supposed to reach here...*/
        Pass_Fail_indicator(0);
        break;

    }

}

/******************************************SPI Peripheral Configurations*********************************************/

/*
 **Function Name     : SSP0_Init
 *Description       : Initialize the SSP0 Peripheral in Motorola SPI mode
 *
 *Input Parameters  :Clock polarity(0 or 1).
 *Input             :Clock Phase(0 or 1).
 *Input             :Clock rate(Maximum data bit rate of one eighth of the peripheral clock rate).
 *Output Parameters : STATUS
 *
 *Note:             :
 */
void SSP0_Init(
    uint8_t SSP_CPOL, uint8_t SSP_CPHA, uint32_t clockrate)
{
    PINSEL_CFG_Type pin_cfg = {
        .Portnum = SSP_PORT,
        .Pinmode = PINSEL_PINMODE_TRISTATE,
        .OpenDrain = PINSEL_PINMODE_OPENDRAIN,
    };

    SSP_CFG_Type ssp_cfg = {
        .CPHA = SSP_CPHA,
        .CPOL = SSP_CPOL,
        .ClockRate = clockrate,
        .Databit = SSP_DATABIT_8,
        .Mode = SSP_MASTER_MODE,
        .FrameFormat = SSP_FRAME_SPI
    };

    /*SSP PINSEL configuration*/
    pin_cfg.Funcnum = 2;
    pin_cfg.Pinnum = SSP_MISO0;
    PINSEL_ConfigPin(&pin_cfg);

    pin_cfg.Pinnum = SSP_MOSI0;
    PINSEL_ConfigPin(&pin_cfg);

    pin_cfg.Pinnum = SSP_SCLK0;
    PINSEL_ConfigPin(&pin_cfg);

    /*Configuring the Pin0.16 to Output for using as Slave select*/
    Chip_GPIO_SetPinDIROutput(LPC_GPIO_0, Port0, SSP_SSEL0);
    Chip_GPIO_SetPinState(LPC_GPIO_0, Port0, SSP_SSEL0, 1);/*By default set the value to HIGH*/
    /*initialize SSP*/
    SSP_Init(LPC_SSP0, &ssp_cfg);
    SSP_Cmd(LPC_SSP0, ENABLE);
    return;

}

/*
 *Function Name     : SSP1_Init
 *Description       : Initialize the SSP1 Peripheral in Motorola SPI mode
 *
 *Input Parameters  :Clock polarity(0 or 1).
 *Input             :Clock Phase(0 or 1).
 *Input             :Clock rate(Maximum data bit rate of one eighth of the peripheral clock rate).
 *Output Parameters : STATUS
 *
 *Note:             :
 */
void SSP1_Init(
    uint8_t SSP_CPOL, uint8_t SSP_CPHA, uint32_t clockrate)
{
    PINSEL_CFG_Type pin_cfg = {
        .Portnum = SSP_PORT,
        .Pinmode = PINSEL_PINMODE_TRISTATE,
        .OpenDrain = PINSEL_PINMODE_OPENDRAIN,
    };

    SSP_CFG_Type ssp_cfg = {
        .CPHA = SSP_CPHA,
        .CPOL = SSP_CPOL,
        .ClockRate = clockrate,
        .Databit = SSP_DATABIT_8,
        .Mode = SSP_SLAVE_MODE,
        .FrameFormat = SSP_FRAME_SPI
    };

    /*SSP PINSEL configuration*/
    pin_cfg.Funcnum = 2;
    pin_cfg.Pinnum = SSP_MISO1;
    PINSEL_ConfigPin(&pin_cfg);

    pin_cfg.Pinnum = SSP_MOSI1;
    PINSEL_ConfigPin(&pin_cfg);

    pin_cfg.Pinnum = SSP_SCLK1;
    PINSEL_ConfigPin(&pin_cfg);

    pin_cfg.Pinnum = SSP_SSEL1;
    PINSEL_ConfigPin(&pin_cfg);

    /*initialize SSP*/
    SSP_Init(LPC_SSP1, &ssp_cfg);
    SSP_Cmd(LPC_SSP1, ENABLE);
    return;
}

/*Function Name     : SPI_Slave_Config
 *Description       : Configure the SSP slave
 *Input Parameters  : SSP Peripheral number
 *Output Parameters : NA
 *Note:             :
 */
void SPI_Slave_Config(
    LPC_SSP_TypeDef *SSPx)
{
    SSP_slave_cfg_t.length = 0;
    SSP_slave_cfg_t.rx_data = SlaveSPIRxBuffer;
    SSP_slave_cfg_t.tx_data = NULL;
    SSP_slave_cfg_t.rx_cnt = 0;
    SSP_slave_cfg_t.tx_cnt = 0;

    SSP_ReadWrite(LPC_SSP1, &SSP_slave_cfg_t, SSP_TRANSFER_INTERRUPT);
}

/*SPI TxRX function with a variable to perform only Rx on slave and master*/
void Lpc_ExHIF_SPI_TxRx(
    LPC_SSP_TypeDef *SSPx, uint8_t bCommChannel)
{
    uint16_t phwRetStatus;
    uint8_t phbPageNum = 0;
    uint8_t phbUserPageStart;
    uint8_t phbUserPageEnd;
    uint16_t wCount = 0;

    switch (bCommChannel)
    {

    case PH_EXHIF_LOOPBACK:
        case PH_EXHIF_I2CM:
        case PH_EXHIF_SPIM:
        case PH_EXHIF_I2CM_SPIM:
        /*Populate the buffer to transmit*/
        Lpc_ExHif_HW_Init_BUffer(LPC_EXHIF_BUFFERSIZE);

        /*First byte made Zero since we need a direction indicator///*/
        MasterTxBuffer[0] = 0;

        /** Wait for the DATA READY line to be asserted by PN640 before sending data */
        while (!lpc_ExHif_GetDataReadyPin());

        //delay(1000);
        /*Always transmit over Master interface. Transmit one additional Direction indicator byte*/
        phwRetStatus = Lpc_ExHIF_SPITx(SSPx, MasterTxBuffer, LPC_EXHIF_BUFFERSIZE + 1);

        if (phwRetStatus != 0)
        {
            //LOG_TXT("uHost: SPI Master Tx : SUCCESS");
            if ((bCommChannel == 0) || ((bCommChannel & 2) == 2))
            {/*Used for reception on SPI master/slave reception when the communication channel is 1 or 3*/
                while ((!lpc_ExHif_GetRxPin()) && !bCommChannel)
                    ;
                phwRetStatus = 0;
                phwRetStatus = Lpc_ExHIF_SPIRx(LPC_SSP0, MasterRxBuffer, (LPC_EXHIF_BUFFERSIZE), bCommChannel);

                if (phwRetStatus == 0)
                {
                    /*Failure scenario due to reception failure*/
                    LOG_TXT("uHost: SPI Master Rx : FAILED");
                }
                else
                {
                    if (bCommChannel == 0)
                    {
                        /*compare the data received on the slave*/
                        if (!memcmp((uint8_t *) (&MasterTxBuffer[1]), (uint8_t *) (&MasterRxBuffer[1]),
                            (LPC_EXHIF_BUFFERSIZE - 1)))
                        {
                            /*Success*/
                            LOG_TXT("uHost: SPI Master Rx : SUCCESS");
                            Pass_Fail_indicator(1);
                        }
                        else
                        {
                            /*Received buffer mismatch*/
                            LOG_TXT("uHost: SPI Master Rx : FAILED");
                            Pass_Fail_indicator(0);
                        }
                    }
                    else
                    {
                        /*Data received on the slave needs to be verified*/
                        LOG_TXT("uHost: SPI Slave Rx : SUCCESS");
                        Pass_Fail_indicator(1);
                    }
                }
            }

            if ((bCommChannel & 1) == 1)
            {
                /*I2C Slave reception*/
                phwRetStatus = 0;
                phwRetStatus = Lpc_ExHif_I2CRx(LPC_I2C0, MasterRxBuffer, (LPC_EXHIF_BUFFERSIZE),
                    LPC_EXHIF_I2C_SLAVE_ADDR, bCommChannel);
                if (phwRetStatus == 0)
                {
                    /*Failure on SPI Slave reception*/
                    LOG_TXT("uHost: I2C Slave Rx : FAILED");
                    Pass_Fail_indicator(0);
                }
                else
                {
                    /*Success on  SPI Slave reception*/
                    LOG_TXT("uHost: I2C Slave Rx : SUCCESS");
                    Pass_Fail_indicator(1);
                }
            }
        }
        else
        {
            /*Failed to transmit to PN640*/
            LOG_TXT("uHost: SPI Master Tx : FAILED");
        }
        break;
        /** Write to the EEPROM Pagewise*/
    case PH_EXHIF_EEPROM_WRITE:

        /*Use for EEPROM Communication Channel. Write last four 64byte sectors*/
        phbUserPageStart = ((((PH_EXHIF_EEPROM_SIZE) - (PH_EXHIF_USER_EEPROM_SIZE)) / (PH_EXHIF_EEPROM_PAGE_SIZE)));
        phbUserPageEnd = (PH_EXHIF_EEPROM_SIZE) / (PH_EXHIF_EEPROM_PAGE_SIZE);
        for (phbPageNum = phbUserPageStart; phbPageNum < phbUserPageEnd; phbPageNum++)
        {
            delay(5);
            MasterTxBuffer[65] = phbPageNum;
            /*Populate the Data for EEPROM*/
            for (wCount = 0; wCount < PH_EXHIF_EEPROM_PAGE_SIZE; wCount++)
            {
                MasterTxBuffer[wCount + 1] = 0xAA;
            }

            /*Direction Indicator first byte*/
            MasterTxBuffer[0] = 0;

            /** Wait for the DATA READY line to be asserted by PN640 before sending data */
            while (!lpc_ExHif_GetDataReadyPin());

            /*Always transmit over Master interface*/
            if (Lpc_ExHIF_SPITx(SSPx, MasterTxBuffer, (PH_EXHIF_EEPROM_PAGE_SIZE + 2)))
            {

                //delay(1000);
                while ((!lpc_ExHif_GetRxPin()));
                /*The first byte received is the director indicator and next two bytes is response.*/
                Lpc_ExHIF_SPIRx(LPC_SSP0, MasterRxBuffer, 5, bCommChannel);

                if (((MasterRxBuffer[3] << 8) | (MasterRxBuffer[4])) == 0)
                {
                    /*Recieved response*/
                    Pass_Fail_indicator(1);
#ifndef NDEBUG
                    printf("EEPROM Write response is SUCCESS(%d) for Sector %d\n",
                        ((MasterRxBuffer[3] << 8) | (MasterRxBuffer[4])), phbPageNum);
#endif
                }
                else
                {
                    Pass_Fail_indicator(0);
#ifndef NDEBUG
                    printf("EEPROM Write response is FAIL(%d) for Sector %d\n",
                        ((MasterRxBuffer[3] << 8) | (MasterRxBuffer[4])), phbPageNum);
#endif
                }

            }
            else
            {
                /*Transmit to PN640 failed.*/
                LOG_TXT("uHost: SPI Master Tx : FAILED");
            }
            /*Reinit the Receive Queue in PN640*/
            CLEAR_GPIO_HIF_INTERACE_L;
            CLEAR_GPIO_HIF_INTERACE_H;

            delay(500);

            CLEAR_GPIO_HIF_INTERACE_L;
            SET_GPIO_HIF_INTERACE_H;
        }
        break;
        /* Write two pages in flash*/
    case PH_EXHIF_FLASH_WRITE:

        /*Populate the Data for EEPROM*/
        for (wCount = 0; wCount < PH_EXHIF_FLASH_PAGE_SIZE; wCount++)
        {
            MasterTxBuffer[wCount + 1] = 0xCD;
        }

        /*Direction Indicator first byte*/
        MasterTxBuffer[0] = 0;

        /** Wait for the DATA READY line to be asserted by PN640 before sending data */
        while (!lpc_ExHif_GetDataReadyPin());

        /*Always transmit over Master interface*/
        if (Lpc_ExHIF_SPITx(SSPx, MasterTxBuffer, ((PH_EXHIF_FLASH_PAGE_SIZE) + 1)))
        {
            while ((!lpc_ExHif_GetRxPin()))
                ;
            /*The first byte received is the director indicator and next two bytes is response.*/
            Lpc_ExHIF_SPIRx(LPC_SSP0, MasterRxBuffer, 5, bCommChannel);

            if (((MasterRxBuffer[3] << 8) | (MasterRxBuffer[4])) == 0)
            {
                /*Recieved response*/
                Pass_Fail_indicator(1);
#ifndef NDEBUG
                printf("FLASH Write response is SUCCESS(%d) for Page %d\n",
                    ((MasterRxBuffer[3] << 8) | (MasterRxBuffer[4])), phbPageNum);
#endif
            }
            else
            {
                Pass_Fail_indicator(0);
#ifndef NDEBUG
                printf("FLASH Write response is FAIL(%d) for Page %d\n",
                    ((MasterRxBuffer[3] << 8) | (MasterRxBuffer[4])), phbPageNum);
#endif
            }

        }
        else
        {
            /*Transmit to PN640 failed.*/
            LOG_TXT("uHost: SPI Master Tx : FAILED");
        }
        /*Reinit the Receive Queue in PN640*/
        CLEAR_GPIO_HIF_INTERACE_L;
        CLEAR_GPIO_HIF_INTERACE_H;

        delay(500);

        CLEAR_GPIO_HIF_INTERACE_L;
        SET_GPIO_HIF_INTERACE_H;

        break;

    case PH_EXHIF_CT_TRANSACTION:

        for(wCount = 0; wCount < PH_EXHIFCT_MAX_NO_APDU ; wCount++)
        {
            memcpy(&(MasterTxBuffer[1]),&(bApduCommandArray[wCount][0]),bApduCommandLength[wCount] );

            /*First byte made Zero since we need a direction indicator///*/
            MasterTxBuffer[0] = 0;

            /** Wait for the DATA READY line to be asserted by PN640 before sending data */
            while (!lpc_ExHif_GetDataReadyPin());

            /*Always transmit over Master interface. Transmit one additional Direction indicator byte*/
            if(Lpc_ExHIF_SPITx(SSPx, MasterTxBuffer, bApduCommandLength[wCount] + 1))
            {
               while ((!lpc_ExHif_GetRxPin()))
                   ;
               /*The first byte received is the director indicator and next two bytes is response.*/
               Lpc_ExHIF_SPIRx(LPC_SSP0, MasterRxBuffer, 3, bCommChannel);

               if(MasterRxBuffer[1] == 0x90 && MasterRxBuffer[2] == 0x00 )
               {
#ifndef NDEBUG
                   printf("APDU Accepted for Card Type: %s\n",(bApduInfo[wCount]));
#endif
                   break;
               }
               else
               {
#ifndef NDEBUG
                   printf("APDU Rejected for Card Type: %s\n",(bApduInfo[wCount]));
#endif
               }
            }

            /*Reinit the Receive Queue in PN640*/
            CLEAR_GPIO_HIF_INTERACE_L;
            CLEAR_GPIO_HIF_INTERACE_H;

            delay(500);

            CLEAR_GPIO_HIF_INTERACE_L;
            SET_GPIO_HIF_INTERACE_H;

        }
        break;
    case PH_EXHIF_PERFORMANCE:
        break;

    default:
        break;
    }
}

/******************************************HSU Peripheral Configurations*********************************************/
/*
 *Function Name     : UART1_Init
 *Description       : Initialize the UART1 Peripheral
 *Input Parameters  : Clock polarity(0 or 1).
 *Input             : Clock Phase(0 or 1).
 *Input             : Clock rate(Maximum data bit rate of one eighth of the peripheral clock rate).
 *Output Parameters : STATUS
 *
 *Note:             :
 */
void UART1_Config(
    uint8_t Databits, uint8_t Stopbits, uint8_t parity, uint32_t dwClockrate)
{
    uint8_t idx;
    UART_CFG_Type UART_CFG;
    UART_FIFO_CFG_Type UARTFIFOConfigStruct;

    UART_CFG.Baud_rate = dwClockrate;
    UART_CFG.Parity = parity;
    UART_CFG.Databits = Databits;
    UART_CFG.Stopbits = Stopbits;

    PINSEL_CFG_Type PinCfg;
    PinCfg.Funcnum = 1;
    PinCfg.OpenDrain = PINSEL_PINMODE_OPENDRAIN;
    PinCfg.Pinmode = PINSEL_PINMODE_TRISTATE;
    PinCfg.Portnum = 0;
    for (idx = 15; idx <= 16; idx++)
    {
        PinCfg.Pinnum = idx;
        PINSEL_ConfigPin(&PinCfg);
    }

    // Initialize UART0 peripheral with given to corresponding parameter
    UART_Init((LPC_UART_TypeDef *) LPC_UART1, &UART_CFG);

    // Initialize FIFO for UART1 peripheral
    UART_FIFOConfigStructInit(&UARTFIFOConfigStruct);
    UART_FIFOConfig((LPC_UART_TypeDef *) LPC_UART1, &UARTFIFOConfigStruct);

    // Enable CTS1 signal transition interrupt
    //UART_IntConfig((LPC_UART_TypeDef *)LPC_UART1, UART1_INTCFG_CTS, ENABLE);
    //// Force RTS pin state to ACTIVE
    //UART_FullModemForcePinState(LPC_UART1, UART1_MODEM_PIN_RTS, ACTIVE);
    /* Enable UART Rx interrupt */
    UART_IntConfig((LPC_UART_TypeDef *) LPC_UART1, UART_INTCFG_RBR, ENABLE);
    /* Enable UART line status interrupt */
    UART_IntConfig((LPC_UART_TypeDef *) LPC_UART1, UART_INTCFG_RLS, ENABLE);

    // Reset ring buf head and tail idx
    __BUF_RESET(rb.rx_head);
    __BUF_RESET(rb.rx_tail);

    UART_TxCmd((LPC_UART_TypeDef *) LPC_UART1, ENABLE);
    /* preemption = 1, sub-priority = 1 */
    NVIC_SetPriority(UART1_IRQn, ((0x01 << 3) | 0x01));
    NVIC_EnableIRQ(UART1_IRQn);

    /*Since the RTS pin used is P2(7), we need to configure this pin to be OUTPUT*/
    UART1_RTS_OUTPUT;
    UART1_RTS_CLEAR;

    /*Since CTS P0-17 is used as input we need to initialize */
    UART1_CTS_INPUT;
    //UART1_CTS_SET_LOW;

}

/*HSU TxRX function*/

void Lpc_ExHIF_HSUTxRx(
    LPC_UART_TypeDef *UARTx, uint8_t bCommChannel)
{
    uint16_t phwRetStatus;
    uint8_t phbPageNum;
    uint8_t phbUserPageStart;
    uint8_t phbUserPageEnd;
    switch (bCommChannel)
    {

    case PH_EXHIF_LOOPBACK:
        case PH_EXHIF_I2CM:
        case PH_EXHIF_SPIM:
        case PH_EXHIF_I2CM_SPIM:
        Lpc_ExHif_HW_Init_BUffer(LPC_EXHIF_BUFFERSIZE);

        //delay(100);

        /** Wait for the DATA READY line to be asserted by PN640 before sending data */
        while (!lpc_ExHif_GetDataReadyPin());

        /*Transmit over the master interface*/
        phwRetStatus = Lpc_ExHIF_HSUTx((LPC_UART_TypeDef *) LPC_UART1, MasterTxBuffer, LPC_EXHIF_BUFFERSIZE);

        if (phwRetStatus != 0)
        {

            LOG_TXT("uHost: HSU Tx : SUCCESS");
            if (bCommChannel == PH_EXHIF_LOOPBACK)/*Loop back scenario*/
            {
                phwRetStatus = 0;
                phwRetStatus = Lpc_ExHIF_HSURx((LPC_UART_TypeDef *) LPC_UART1, LPC_EXHIF_BUFFERSIZE);

                if (phwRetStatus != 0)
                {
                    /*Success scenario*/
                    LOG_TXT("uHost: HSU Rx : SUCCESS");
                    Pass_Fail_indicator(1);
                }
                else
                {
                    /*Failure scenario*/
                    LOG_TXT("uHost: HSU Rx : FAILED");
                    Pass_Fail_indicator(0);
                }
            }
            else
            { /*Receive over the I2C slave*/
                if ((bCommChannel & 1) == PH_EXHIF_I2CM)
                {
                    if (!(Lpc_ExHif_I2CRx(LPC_I2C0, MasterRxBuffer, LPC_EXHIF_BUFFERSIZE, LPC_EXHIF_I2C_SLAVE_ADDR,
                        bCommChannel)))
                    {
                        /*Failure to receive over the I2C Slave*/
                        LOG_TXT("uHost: I2C SLAVE Rx : FAILED");
                        Pass_Fail_indicator(0);
                    }
                    else/*Successful reception on I2C Slave*/
                    {
                        LOG_TXT("uHost: I2C SLAVE Rx : SUCCESS");
                        Pass_Fail_indicator(1);
                    }
                }

                if ((bCommChannel & 2) == PH_EXHIF_SPIM)
                { /*Receive over the SPI slave*/
                    if (!(Lpc_ExHIF_SPIRx(LPC_SSP0, MasterRxBuffer, LPC_EXHIF_BUFFERSIZE, bCommChannel)))
                    {
                        /*Failure to receive over the SPI Slave*/
                        LOG_TXT("uHost: SPI SLAVE Rx : FAILED");
                        Pass_Fail_indicator(0);
                    }
                    else
                        /*Successful reception on SPI Slave*/
                        LOG_TXT("uHost: SPI SLAVE Rx : SUCCESS");
                    Pass_Fail_indicator(1);
                }
            }
        }
        break;
    case PH_EXHIF_EEPROM_WRITE:
        /*Use for EEPROM Communication Channel*/
        phbUserPageStart = ((((PH_EXHIF_EEPROM_SIZE) - (PH_EXHIF_USER_EEPROM_SIZE)) / (PH_EXHIF_EEPROM_PAGE_SIZE)) + 5);
        phbUserPageEnd = (PH_EXHIF_EEPROM_SIZE) / (PH_EXHIF_EEPROM_PAGE_SIZE);
        for (phbPageNum = phbUserPageStart; phbPageNum < phbUserPageEnd; phbPageNum++)
        {
            uint8_t i;
            delay(10);
            MasterTxBuffer[64] = phbPageNum;
            /*Populate the Data for EEPROM*/
            for (i = 0; i < PH_EXHIF_EEPROM_PAGE_SIZE; i++)
            {
                MasterTxBuffer[i] = 0xAA;
            }

            /*Always transmit over Master interface*/
            if (Lpc_ExHIF_HSUTx((LPC_UART_TypeDef *) LPC_UART1, MasterTxBuffer, (PH_EXHIF_EEPROM_PAGE_SIZE + 1)))
            {
                delay(400);
                LOG_TXT("uHost: HSU Tx : SUCCESS");
                /*Receive data over the HSU*/
                Lpc_ExHIF_HSURx((LPC_UART_TypeDef *) LPC_UART1, 2);

                if (((MasterRxBuffer[0] << 8) | (MasterRxBuffer[1])) == 0)
                {
                    /*Received response*/
                    Pass_Fail_indicator(1);
#ifndef NDEBUG
                    printf("EEPROM Write response is SUCCESS(%d) for Sector %d\n",
                        ((MasterRxBuffer[0] << 8) | (MasterRxBuffer[1])), phbPageNum);
#endif
                }
                else
                {
                    Pass_Fail_indicator(0);
#ifndef NDEBUG
                    printf("EEPROM Write response is FAIL(%d) for Sector %d\n",
                        ((MasterRxBuffer[0] << 8) | (MasterRxBuffer[1])), phbPageNum);
#endif
                }

            }
            else
            {
                /*Transmit to PN640 failed.*/
                LOG_TXT("uHost: HSU Tx : FAILED");
            }

            /*Reinit the Receive Queue in PN640*/
            CLEAR_GPIO_HIF_INTERACE_L;
            CLEAR_GPIO_HIF_INTERACE_H;

            delay(500);
            SET_GPIO_HIF_INTERACE_L;
            SET_GPIO_HIF_INTERACE_H;
        }
        break;
    default:
        break;
    }

}

