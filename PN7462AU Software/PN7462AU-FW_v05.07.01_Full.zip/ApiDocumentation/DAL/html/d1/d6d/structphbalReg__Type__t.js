var structphbalReg__Type__t =
[
    [ "wId", "d1/d6d/structphbalReg__Type__t.html#a313cfd41cf4a4e77dc1f8c4ab7be2257", null ],
    [ "bBalType", "d1/d6d/structphbalReg__Type__t.html#a19dedc5b517bac403221e55f18529289", null ]
];