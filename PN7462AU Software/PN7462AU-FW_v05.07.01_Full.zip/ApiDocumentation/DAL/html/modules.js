var modules =
[
    [ "Driver Abstraction Layer (DAL)", "df/df0/group__phDriver.html", "df/df0/group__phDriver" ],
    [ "Bus Abstraction Layer (BAL)", "d8/da7/group__phbalReg.html", "d8/da7/group__phbalReg" ]
];