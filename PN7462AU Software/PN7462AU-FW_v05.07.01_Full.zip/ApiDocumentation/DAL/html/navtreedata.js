var NAVTREE =
[
  [ "NXP DAL", "index.html", [
    [ "Introduction", "index.html#phsec_Intro", null ],
    [ "API Reference", "index.html#phsec_ApiReference", null ],
    [ "DISCLAIMER OF WARRANTIES:", "index.html#phMfpLib_DisclaimerInfo", null ],
    [ "LIMITATION OF LIABILITY:", "index.html#phMfpLib_LiabilityInfo", null ],
    [ "Revision History", "index.html#phsec_RevisionHistory", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';