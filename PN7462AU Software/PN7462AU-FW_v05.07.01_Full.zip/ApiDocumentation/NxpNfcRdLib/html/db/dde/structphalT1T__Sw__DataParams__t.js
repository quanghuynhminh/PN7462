var structphalT1T__Sw__DataParams__t =
[
    [ "wId", "db/dde/structphalT1T__Sw__DataParams__t.html#a20d6a870995b5d7aeaa700734e3449c9", null ],
    [ "pPalI14443p3aDataParams", "db/dde/structphalT1T__Sw__DataParams__t.html#a90db891ea290375c8e1899234892379f", null ],
    [ "abHR", "db/dde/structphalT1T__Sw__DataParams__t.html#a43180e8ebbade5fb1b9075202b222ae0", null ],
    [ "abUid", "db/dde/structphalT1T__Sw__DataParams__t.html#aef87600bd310e848cb2fd22126971c0f", null ]
];