var structphNfcLib__MFC__t =
[
    [ "bCommand", "d4/d9d/structphNfcLib__MFC__t.html#a9fa59b938d327729c1d16d1c79b04195", null ],
    [ "bBlockNumber", "d4/d9d/structphNfcLib__MFC__t.html#a37e4d01447465cd5e128aaca9d71ce87", null ],
    [ "bKeyType", "d4/d9d/structphNfcLib__MFC__t.html#ae6795cc53e325e56b6ec7c6fce1c3a0e", null ],
    [ "bKeyNumber", "d4/d9d/structphNfcLib__MFC__t.html#a4c43e41f8f96d8e88ccdea2be63a7775", null ],
    [ "bKeyVersion", "d4/d9d/structphNfcLib__MFC__t.html#aca66369d3a207b19d22cdec6685afbde", null ],
    [ "bUidType", "d4/d9d/structphNfcLib__MFC__t.html#a423bc0eb46c98f4767181777aac0c8d3", null ]
];