var structphTools__Q =
[
    [ "pSender", "d4/df8/structphTools__Q.html#a6cd68e9f3f90f38e8ef3e92972aba52d", null ],
    [ "pbData", "d4/df8/structphTools__Q.html#ad5bef3e04badd6ba7042e6e45feccf36", null ],
    [ "dwLength", "d4/df8/structphTools__Q.html#ab2ab238703ffa7b328b5093496b9a9ed", null ],
    [ "bLlcpBuf", "d4/df8/structphTools__Q.html#af926e787d0c1e904b12f45093f3a752b", null ],
    [ "bLlcpData", "d4/df8/structphTools__Q.html#a292bd9c9be61626a60f05f9ed5a7349a", null ],
    [ "pNext", "d4/df8/structphTools__Q.html#a8141998b6aeb6ab6eed43530c199ef0a", null ],
    [ "wFrameOpt", "d4/df8/structphTools__Q.html#aa0197ae4377954e17f4cb070882af963", null ],
    [ "bSenderType", "d4/df8/structphTools__Q.html#acd8eedcba0686d68390d04d9c8760636", null ],
    [ "bType", "d4/df8/structphTools__Q.html#aa9ca2283ef7d088fb1916c91915afd31", null ]
];