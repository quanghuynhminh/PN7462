var group__grpsApi =
[
    [ "NXP NFC Library Top Level API", "d7/dfa/group__nfc__lib.html", "d7/dfa/group__nfc__lib" ]
];