var group__phnpSnep__Sw =
[
    [ "phnpSnep_Sw_DataParams_t", "d4/d9c/structphnpSnep__Sw__DataParams__t.html", [
      [ "wId", "d4/d9c/structphnpSnep__Sw__DataParams__t.html#a85d45680479232dbed6c865ecd5528bb", null ],
      [ "plnLlcpDataParams", "d4/d9c/structphnpSnep__Sw__DataParams__t.html#a8f5df530c1a7acd76c638787cbcbc3c0", null ],
      [ "psSocket", "d4/d9c/structphnpSnep__Sw__DataParams__t.html#a0b5c437862543e2a356dbbbd8c6fd6f3", null ],
      [ "bSnepVersion", "d4/d9c/structphnpSnep__Sw__DataParams__t.html#affe488f5e6587d26a358dc777b31fab0", null ],
      [ "eServerType", "d4/d9c/structphnpSnep__Sw__DataParams__t.html#a760305dfa036043aaff827d8f929a9d8", null ]
    ] ],
    [ "PHNP_SNEP_SW_ID", "d2/dc6/group__phnpSnep__Sw.html#ga2416f9580d5bbe318533e34ce38487f2", null ],
    [ "phnpSnep_Server_type_t", "d2/dc6/group__phnpSnep__Sw.html#ga9380e8b28cdcd5033cbe98394950169c", [
      [ "phnpSnep_Default_Server", "d2/dc6/group__phnpSnep__Sw.html#gga9380e8b28cdcd5033cbe98394950169ca2a0e80919b9591fcdc0f07c2043ef3ab", null ],
      [ "phnpSnep_NonDefault_Server", "d2/dc6/group__phnpSnep__Sw.html#gga9380e8b28cdcd5033cbe98394950169ca2fc88209558044d09b10cab06bab6e9a", null ]
    ] ],
    [ "phnpSnep_Sw_Init", "d2/dc6/group__phnpSnep__Sw.html#ga35346f3c948415ff36820f237f9c02de", null ]
];