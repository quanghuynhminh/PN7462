var group__phalMfc__Sw =
[
    [ "phalMfc_Sw_DataParams_t", "d4/d5a/structphalMfc__Sw__DataParams__t.html", [
      [ "wId", "d4/d5a/structphalMfc__Sw__DataParams__t.html#a546853dde6351d5f2f51e80d074ac5ec", null ],
      [ "pPalMifareDataParams", "d4/d5a/structphalMfc__Sw__DataParams__t.html#ab2d1fbd8230f47566b98b68a33459042", null ],
      [ "pKeyStoreDataParams", "d4/d5a/structphalMfc__Sw__DataParams__t.html#a08856cc119a212c99cebe7adad5c664c", null ]
    ] ],
    [ "PHAL_MFC_SW_ID", "dc/d86/group__phalMfc__Sw.html#ga4a7ede24f83d5253a962653db6fb4450", null ],
    [ "phalMfc_Sw_Init", "dc/d86/group__phalMfc__Sw.html#ga57cb6b0e2bdc2aacab02d5e2a0210b92", null ]
];