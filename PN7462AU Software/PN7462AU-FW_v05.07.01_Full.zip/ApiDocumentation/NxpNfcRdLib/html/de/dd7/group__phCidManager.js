var group__phCidManager =
[
    [ "Component : Software", "d8/d83/group__phCidManager__Sw.html", "d8/d83/group__phCidManager__Sw" ],
    [ "PH_CIDMANAGER_LAST_CID", "de/dd7/group__phCidManager.html#ga975befd6991f057841e5d3622bb916d3", null ],
    [ "phCidManager_GetFreeCid", "de/dd7/group__phCidManager.html#ga2b30bb04c1294ceb76a3907229ef29f4", null ],
    [ "phCidManager_FreeCid", "de/dd7/group__phCidManager.html#ga069e711ae04508dffae93de18819e0ea", null ]
];