var structphLog__DataParams__t =
[
    [ "pLogCallback", "de/de7/structphLog__DataParams__t.html#aa8b2f24cea101bace1194c00a8622569", null ],
    [ "pRegisterEntries", "de/de7/structphLog__DataParams__t.html#aa2ac5f6864c929e403049a68e33b0c20", null ],
    [ "wNumRegisterEntries", "de/de7/structphLog__DataParams__t.html#ac0dc3336e6bbabd01529debe70d478ac", null ],
    [ "wMaxRegisterEntries", "de/de7/structphLog__DataParams__t.html#af4373e7d614f824d106c36e0477d7278", null ]
];