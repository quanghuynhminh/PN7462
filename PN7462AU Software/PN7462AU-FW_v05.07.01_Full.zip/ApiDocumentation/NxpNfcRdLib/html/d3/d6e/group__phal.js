var group__phal =
[
    [ "MIFARE(R) Classic", "dd/d1b/group__phalMfc.html", "dd/d1b/group__phalMfc" ],
    [ "Type 1 tag", "df/d72/group__phalT1T.html", "df/d72/group__phalT1T" ],
    [ "MIFARE(R) Ultralight", "df/d5c/group__phalMful.html", "df/d5c/group__phalMful" ],
    [ "Felica", "d9/d1c/group__phalFelica.html", "d9/d1c/group__phalFelica" ],
    [ "MIFARE DESFire (R)", "da/d7d/group__phalMfdf.html", "da/d7d/group__phalMfdf" ],
    [ "ICode", "d2/d02/group__phalICode.html", "d2/d02/group__phalICode" ],
    [ "ISO/IEC 18000-3 Mode3", "d3/db9/group__phalI18000p3m3.html", "d3/db9/group__phalI18000p3m3" ],
    [ "Tag Operation Layer", "d1/d43/group__phalTop.html", "d1/d43/group__phalTop" ],
    [ "MIFARE DESFire (R) EV2", "dc/d00/group__phalMfdfEv2.html", "dc/d00/group__phalMfdfEv2" ],
    [ "MIFARE Plus (R)", "da/d83/group__phalMfp.html", "da/d83/group__phalMfp" ],
    [ "MIFARE Plus (R) EV1", "d3/d5c/group__phalMfpEv1.html", "d3/d5c/group__phalMfpEv1" ]
];