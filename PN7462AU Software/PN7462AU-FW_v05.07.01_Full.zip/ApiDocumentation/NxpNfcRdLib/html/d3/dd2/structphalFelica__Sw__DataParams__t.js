var structphalFelica__Sw__DataParams__t =
[
    [ "wId", "d3/dd2/structphalFelica__Sw__DataParams__t.html#a36b27ac56e05463b4b507cde99d2bfa6", null ],
    [ "pPalFelicaDataParams", "d3/dd2/structphalFelica__Sw__DataParams__t.html#ab162708037d05dffe2232ddd72d320b5", null ],
    [ "wAdditionalInfo", "d3/dd2/structphalFelica__Sw__DataParams__t.html#a316e839e11e020259a1418102797b6fa", null ]
];