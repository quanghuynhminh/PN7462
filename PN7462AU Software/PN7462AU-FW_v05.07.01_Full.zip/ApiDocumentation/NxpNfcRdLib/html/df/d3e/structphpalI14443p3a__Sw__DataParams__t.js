var structphpalI14443p3a__Sw__DataParams__t =
[
    [ "wId", "df/d3e/structphpalI14443p3a__Sw__DataParams__t.html#a6a9e233a6de0d51ab9edd230ee3a1fe7", null ],
    [ "pHalDataParams", "df/d3e/structphpalI14443p3a__Sw__DataParams__t.html#ae0866819516c7254de9d9ae4740d073d", null ],
    [ "abUid", "df/d3e/structphpalI14443p3a__Sw__DataParams__t.html#a9905990f69da1f50c5c3bb30fb34c4f3", null ],
    [ "bUidLength", "df/d3e/structphpalI14443p3a__Sw__DataParams__t.html#a030aafc9c44b2d489da9e9c22510f7e0", null ],
    [ "bUidComplete", "df/d3e/structphpalI14443p3a__Sw__DataParams__t.html#ac4f6eaf8ff39c73a4081396556659c7d", null ],
    [ "bOpeMode", "df/d3e/structphpalI14443p3a__Sw__DataParams__t.html#a94f45382312f97178b6ce46bc03de8ea", null ],
    [ "bPollCmd", "df/d3e/structphpalI14443p3a__Sw__DataParams__t.html#a16ca81f95017d69f91502eac1a5e00da", null ]
];