var group__nfc__lib__definitions =
[
    [ "PH_NFCLIB_TECHNOLOGY_INITIATOR_ISO_14443_A", "d1/d90/group__nfc__lib__definitions.html#gabf8f589aad659abe3bd5ec4694f92bd6", null ],
    [ "PH_NFCLIB_TECHNOLOGY_INITIATOR_ISO_14443_B", "d1/d90/group__nfc__lib__definitions.html#gaae4e2a14521fc185a88b2663608c5e37", null ],
    [ "PH_NFCLIB_TECHNOLOGY_INITIATOR_FELICA", "d1/d90/group__nfc__lib__definitions.html#gaaa6b4dab4be65f708d153397f701dbd9", null ],
    [ "PH_NFCLIB_TECHNOLOGY_INITIATOR_ISO_15693", "d1/d90/group__nfc__lib__definitions.html#ga68d396b3bffdf2983f8debbc8694cf04", null ],
    [ "PH_NFCLIB_TECHNOLOGY_INITIATOR_ISO_18000_3_3", "d1/d90/group__nfc__lib__definitions.html#ga205ecc2a51b06d6d1057d0ecfa366118", null ],
    [ "PH_NFCLIB_TECHNOLOGY_INITIATOR_ISO_18092", "d1/d90/group__nfc__lib__definitions.html#gac8e8f37fd710dd89faacb317bdcecb13", null ],
    [ "PH_NFCLIB_TECHNOLOGY_TARGET_ISO_14443_A", "d1/d90/group__nfc__lib__definitions.html#ga87d5331bcc608ec6a62ffd4ebd8c3272", null ],
    [ "PH_NFCLIB_TECHNOLOGY_TARGET_ISO_14443_B", "d1/d90/group__nfc__lib__definitions.html#ga54e91e834f6f585782ea0730e3883532", null ],
    [ "PH_NFCLIB_TECHNOLOGY_TARGET_FELICA", "d1/d90/group__nfc__lib__definitions.html#ga5a85c749ffa45e430a202562007e27ab", null ],
    [ "PH_NFCLIB_TECHNOLOGY_TARGET_ISO_18092", "d1/d90/group__nfc__lib__definitions.html#gaf80ea51631f60d0b232807940b301e95", null ],
    [ "PH_NFCLIB_ACTIVATION_MERGED_SAK_PRIO_14443", "d1/d90/group__nfc__lib__definitions.html#ga96ef50f973a4c2e4b94e8019e420165f", null ],
    [ "PH_NFCLIB_ACTIVATION_MERGED_SAK_PRIO_18092", "d1/d90/group__nfc__lib__definitions.html#ga1b6a2fb22a79ba6a82657de00e770e86", null ],
    [ "PH_NFCLIB_DEACTIVATION_MODE_RF_OFF", "d1/d90/group__nfc__lib__definitions.html#ga2c23e7b1616f9764ddd36e5e015278fd", null ],
    [ "PH_NFCLIB_DEACTIVATION_MODE_RELEASE", "d1/d90/group__nfc__lib__definitions.html#ga794eca4d0830c65540d2dc9374a3d956", null ],
    [ "PH_NFCLIB_ACTIVATION_PROFILE_NFC", "d1/d90/group__nfc__lib__definitions.html#gab8b439c05f6593207bb5bfa22d3101e4", null ],
    [ "PH_NFCLIB_ACTIVATION_PROFILE_EMVCO", "d1/d90/group__nfc__lib__definitions.html#gac6b286e5c20fb6c389990a358808756d", null ],
    [ "PH_NFCLIB_ACTIVATION_PROFILE_ISO", "d1/d90/group__nfc__lib__definitions.html#ga22018fe5f21b307e9e6351c77e91adb0", null ]
];