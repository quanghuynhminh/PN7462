var structphKeyStore__Sw__KeyVersionPair__t =
[
    [ "pKey", "d0/da0/structphKeyStore__Sw__KeyVersionPair__t.html#a957adb5a18f724bd5280a7a89dd4b212", null ],
    [ "wVersion", "d0/da0/structphKeyStore__Sw__KeyVersionPair__t.html#a665127aabd35dae08e886dae85983425", null ]
];