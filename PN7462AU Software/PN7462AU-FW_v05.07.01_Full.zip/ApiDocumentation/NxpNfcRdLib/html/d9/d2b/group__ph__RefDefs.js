var group__ph__RefDefs =
[
    [ "PH_MEMLOC_BUF", "d9/d2b/group__ph__RefDefs.html#ga3cbb548dd0df794f754dbbd818cb01a4", null ],
    [ "PH_MEMLOC_COUNT", "d9/d2b/group__ph__RefDefs.html#gad91c060cfcb63e0f39300a7125152f7a", null ],
    [ "PH_MEMLOC_REM", "d9/d2b/group__ph__RefDefs.html#gaee9f9ddd906558f9fd9ca21b4969a052", null ],
    [ "PH_MEMLOC_CONST_ROM", "d9/d2b/group__ph__RefDefs.html#gaebdfb872a8d9c03828948829ff69e909", null ]
];