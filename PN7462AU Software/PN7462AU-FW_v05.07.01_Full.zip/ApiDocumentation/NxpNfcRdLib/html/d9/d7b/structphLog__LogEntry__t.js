var structphLog__LogEntry__t =
[
    [ "bLogType", "d9/d7b/structphLog__LogEntry__t.html#af0f6fbf2b367c9140cef0a4321ea00c4", null ],
    [ "pString", "d9/d7b/structphLog__LogEntry__t.html#aed2e4cbc6a415c539e81ee8ef50abac6", null ],
    [ "pData", "d9/d7b/structphLog__LogEntry__t.html#aba0d11b9f36597e9c3283265f448d4f2", null ],
    [ "wDataLen", "d9/d7b/structphLog__LogEntry__t.html#a16cd0f176eb14d8f779933693b0de3a5", null ],
    [ "bDataType", "d9/d7b/structphLog__LogEntry__t.html#a7a02cf6cb124b8039fc734aebc301637", null ]
];