var structphLog__RegisterEntry__t =
[
    [ "pDataParams", "d7/dd7/structphLog__RegisterEntry__t.html#aa50dea31d4306a0944a507cd1857514a", null ],
    [ "pLogEntries", "d7/dd7/structphLog__RegisterEntry__t.html#a9c7bc7c7c4258e85675fb4e1fc86204e", null ],
    [ "wNumLogEntries", "d7/dd7/structphLog__RegisterEntry__t.html#af04dee6cbfda74a98423a5e32ef55be4", null ],
    [ "wMaxLogEntries", "d7/dd7/structphLog__RegisterEntry__t.html#a6e7650a2801950104f6f63542307c7a9", null ]
];