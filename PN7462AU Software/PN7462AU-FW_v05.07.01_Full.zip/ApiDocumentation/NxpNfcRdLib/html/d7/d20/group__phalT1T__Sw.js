var group__phalT1T__Sw =
[
    [ "phalT1T_Sw_DataParams_t", "db/dde/structphalT1T__Sw__DataParams__t.html", [
      [ "wId", "db/dde/structphalT1T__Sw__DataParams__t.html#a20d6a870995b5d7aeaa700734e3449c9", null ],
      [ "pPalI14443p3aDataParams", "db/dde/structphalT1T__Sw__DataParams__t.html#a90db891ea290375c8e1899234892379f", null ],
      [ "abHR", "db/dde/structphalT1T__Sw__DataParams__t.html#a43180e8ebbade5fb1b9075202b222ae0", null ],
      [ "abUid", "db/dde/structphalT1T__Sw__DataParams__t.html#aef87600bd310e848cb2fd22126971c0f", null ]
    ] ],
    [ "PHAL_T1T_SW_ID", "d7/d20/group__phalT1T__Sw.html#gaee9794feae0f6c941bb4ae783532a15f", null ],
    [ "phalT1T_Sw_Init", "d7/d20/group__phalT1T__Sw.html#ga164611bbd61143bf8d06e408cec86d4a", null ]
];