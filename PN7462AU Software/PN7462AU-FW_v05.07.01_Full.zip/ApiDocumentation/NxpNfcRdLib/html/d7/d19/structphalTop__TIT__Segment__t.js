var structphalTop__TIT__Segment__t =
[
    [ "bAddress", "d2/d7b/group__phalTop__Sw.html#ga7cba951eac901556752c286e5d63e566", null ],
    [ "pData", "d2/d7b/group__phalTop__Sw.html#gad3b0949ef39b29be3e70d4b5b5edd989", null ],
    [ "bLockReservedOtp", "d2/d7b/group__phalTop__Sw.html#ga16bac46e14007b7ee036d6bed696f51b", null ]
];