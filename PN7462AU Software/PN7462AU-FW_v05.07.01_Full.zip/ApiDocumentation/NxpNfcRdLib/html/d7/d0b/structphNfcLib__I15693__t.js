var structphNfcLib__I15693__t =
[
    [ "bCommand", "d7/d0b/structphNfcLib__I15693__t.html#ab2e2465ac69df6c61ab6e98688650f4f", null ],
    [ "bOption", "d7/d0b/structphNfcLib__I15693__t.html#a9ab499d6ae188cddc8fb54251469382f", null ],
    [ "bAfi", "d7/d0b/structphNfcLib__I15693__t.html#a7e51ecf66f80c12ef2191bbb1aebfe91", null ],
    [ "bDsfid", "d7/d0b/structphNfcLib__I15693__t.html#a272b18aee5a410745344e673dd07091e", null ],
    [ "wBlockNumber", "d7/d0b/structphNfcLib__I15693__t.html#a9fa3721bcbb28a28b950b533225a89d7", null ],
    [ "wNumBlocks", "d7/d0b/structphNfcLib__I15693__t.html#a09191900b8cbeb60f53680665525b0d2", null ]
];