var group__phother =
[
    [ "Generic Definitions", "d1/d20/group__ph__Status.html", "d1/d20/group__ph__Status" ],
    [ "Type Definitions", "d7/d83/group__ph__Typedefs.html", "d7/d83/group__ph__Typedefs" ],
    [ "Platform Definitions", "d9/d2b/group__ph__RefDefs.html", "d9/d2b/group__ph__RefDefs" ],
    [ "Error Code Collection", "dc/dce/group__ph__Error.html", "dc/dce/group__ph__Error" ],
    [ "(Private definitions)", "dc/d52/group__ph__Private.html", "dc/d52/group__ph__Private" ],
    [ "NXP Build", "d8/d4c/group__ph__NxpBuild.html", "d8/d4c/group__ph__NxpBuild" ]
];