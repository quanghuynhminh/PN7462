var group__phCidManager__Sw =
[
    [ "phCidManager_Sw_DataParams_t", "de/dd7/structphCidManager__Sw__DataParams__t.html", [
      [ "wId", "de/dd7/structphCidManager__Sw__DataParams__t.html#a39eb3a4b5a3f30993804bf2bc5441b22", null ],
      [ "bCidList", "de/dd7/structphCidManager__Sw__DataParams__t.html#a08c568bfd86cf67b25bf6af315399ff5", null ]
    ] ],
    [ "PH_CIDMANAGER_SW_ID", "d8/d83/group__phCidManager__Sw.html#ga51624ae988db5e640d0febb9b03925a2", null ],
    [ "phCidManager_Sw_Init", "d8/d83/group__phCidManager__Sw.html#ga0cb45af8b57c17e30e642650d305b64d", null ]
];