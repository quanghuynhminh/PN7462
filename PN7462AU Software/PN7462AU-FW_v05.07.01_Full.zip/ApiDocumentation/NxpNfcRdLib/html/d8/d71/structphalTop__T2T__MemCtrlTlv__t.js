var structphalTop__T2T__MemCtrlTlv__t =
[
    [ "wOffset", "d2/d7b/group__phalTop__Sw.html#gadd1dabbbaa90f102128743b63d3e9269", null ],
    [ "wByteAddr", "d2/d7b/group__phalTop__Sw.html#gaa77e5ae9d85a62c71ce6e663e30398a4", null ],
    [ "bSizeInBytes", "d2/d7b/group__phalTop__Sw.html#ga1b42d5ae4134a96218e90b8252fb3ed2", null ],
    [ "bBytesPerPage", "d2/d7b/group__phalTop__Sw.html#ga476c059db5fa707ca41801b75989ac44", null ]
];