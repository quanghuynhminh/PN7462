var structphKeyStore__Sw__KUCEntry__t =
[
    [ "dwLimit", "d8/d21/structphKeyStore__Sw__KUCEntry__t.html#a9d37c2099c77ceefbe97ac053b3a341f", null ],
    [ "dwCurVal", "d8/d21/structphKeyStore__Sw__KUCEntry__t.html#af0548de8fec0f0e4f905ae422990fc63", null ]
];