var group__phCryptoRng__Sw =
[
    [ "phCryptoRng_Sw_DataParams_t", "d4/dad/structphCryptoRng__Sw__DataParams__t.html", [
      [ "wId", "d4/dad/structphCryptoRng__Sw__DataParams__t.html#af51b3a70b0a022f9c203402a3a907ee7", null ],
      [ "pCryptoDataParams", "d4/dad/structphCryptoRng__Sw__DataParams__t.html#a177f550c349a6fcc73bd5b690822370a", null ],
      [ "dwRequestCounter", "d4/dad/structphCryptoRng__Sw__DataParams__t.html#a193a3dd23877e0273e9120781e25403a", null ]
    ] ],
    [ "PH_CRYPTORNG_SW_ID", "d5/d34/group__phCryptoRng__Sw.html#ga221ea1bef8a7f169ca333d7d337e9584", null ],
    [ "phCryptoRng_Sw_Init", "d5/d34/group__phCryptoRng__Sw.html#ga1f50f3425751bb66ad8ffb258640dffd", null ]
];