var structphacDiscLoop__Sw__TargetParams__t =
[
    [ "pRxBuffer", "d5/de5/structphacDiscLoop__Sw__TargetParams__t.html#a6fc51b852591f1717a62d774b9ab7c10", null ],
    [ "wRxBufferLen", "d5/de5/structphacDiscLoop__Sw__TargetParams__t.html#a9f322f2434a27d808259d7a5e81e8a13", null ],
    [ "wProtParams", "d5/de5/structphacDiscLoop__Sw__TargetParams__t.html#a86ef6bd6c6fa08ab73d9972cbf618973", null ],
    [ "bRetryCount", "d5/de5/structphacDiscLoop__Sw__TargetParams__t.html#a030b67c71c1834bf91bf7605980dafa6", null ]
];