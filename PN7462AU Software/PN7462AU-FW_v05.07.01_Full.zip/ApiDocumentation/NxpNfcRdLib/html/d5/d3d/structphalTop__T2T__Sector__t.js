var structphalTop__T2T__Sector__t =
[
    [ "bAddress", "d2/d7b/group__phalTop__Sw.html#ga16a46b3bd42b403c9cea76dd11a1c2ba", null ],
    [ "bBlockAddress", "d2/d7b/group__phalTop__Sw.html#gab903a84d8e2a2d709ebec7b53e0ad3cb", null ],
    [ "bLockReservedOtp", "d2/d7b/group__phalTop__Sw.html#ga1337de8219ec87176e703e223b6eb623", null ],
    [ "bValidity", "d2/d7b/group__phalTop__Sw.html#ga54e2c3e2c7f105bde9b178d80083000d", null ]
];