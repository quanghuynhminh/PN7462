var structphalI18000p3m3__Sw__DataParams__t =
[
    [ "wId", "d6/d09/structphalI18000p3m3__Sw__DataParams__t.html#a97ef4f9da9e92dd2dad082a1d63550f6", null ],
    [ "pPalI18000p3m3DataParams", "d6/d09/structphalI18000p3m3__Sw__DataParams__t.html#a680e8232281c5787db334c5c8b0c75a3", null ],
    [ "abHandle", "d6/d09/structphalI18000p3m3__Sw__DataParams__t.html#ab174047c6f42c1e70c4a2783499ba78e", null ],
    [ "bHandleValid", "d6/d09/structphalI18000p3m3__Sw__DataParams__t.html#a52be86fbae5e046e57ed36e42b04efc3", null ]
];