var group__phpalMifare__Sw =
[
    [ "phpalMifare_Sw_DataParams_t", "d8/ddc/structphpalMifare__Sw__DataParams__t.html", [
      [ "wId", "d8/ddc/structphpalMifare__Sw__DataParams__t.html#ab139b8bcdaab98106a9e2efa9178b8f6", null ],
      [ "pHalDataParams", "d8/ddc/structphpalMifare__Sw__DataParams__t.html#ac4121790ce16928ea09bcc26d25d03e3", null ],
      [ "pPalI14443p4DataParams", "d8/ddc/structphpalMifare__Sw__DataParams__t.html#a5e93771a7d68e819b609e8e6eaf75166", null ]
    ] ],
    [ "PHPAL_MIFARE_SW_ID", "da/d53/group__phpalMifare__Sw.html#ga3bc52c03f99575ac14980ddec1003870", null ],
    [ "phpalMifare_Sw_Init", "da/d53/group__phpalMifare__Sw.html#gaf66c51ea22d24fa225a26b0c82d140ce", null ]
];