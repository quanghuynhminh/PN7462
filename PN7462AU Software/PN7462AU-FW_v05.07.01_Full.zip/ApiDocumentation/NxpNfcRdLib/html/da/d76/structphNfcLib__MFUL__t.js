var structphNfcLib__MFUL__t =
[
    [ "bCommand", "da/d76/structphNfcLib__MFUL__t.html#a12e38166329f282ec8453bf5b2dc9e9f", null ],
    [ "bPageNumber", "da/d76/structphNfcLib__MFUL__t.html#a64c9eaff789f3cc8919e4474d34a886e", null ]
];