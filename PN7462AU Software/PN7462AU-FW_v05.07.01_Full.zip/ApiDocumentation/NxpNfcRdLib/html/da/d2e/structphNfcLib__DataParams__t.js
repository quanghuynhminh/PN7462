var structphNfcLib__DataParams__t =
[
    [ "wId", "da/d2e/structphNfcLib__DataParams__t.html#ae9a04ae5a21347ca25b8bd2f9121caaa", null ],
    [ "pBal", "da/d2e/structphNfcLib__DataParams__t.html#a783758e1ed500e75bd4d6eabb408a767", null ],
    [ "sHal", "da/d2e/structphNfcLib__DataParams__t.html#abf4142eeafccd9259043781584c45833", null ],
    [ "sHal", "da/d2e/structphNfcLib__DataParams__t.html#ab53db234f2a44455ae24036bc735b4eb", null ],
    [ "sHal", "da/d2e/structphNfcLib__DataParams__t.html#adc8e0effadf8c0ff46c829d8286b5a62", null ],
    [ "sKeyStore", "da/d2e/structphNfcLib__DataParams__t.html#a42d93818530b6746af27832ab21be45f", null ],
    [ "pNfcLib_ErrCallbck", "da/d2e/structphNfcLib__DataParams__t.html#a5024360200d259abd8d585ec29fb69cb", null ],
    [ "pRtoxCallback", "da/d2e/structphNfcLib__DataParams__t.html#a515de7f58f1a53925e1c071d938fdfcc", null ],
    [ "pWtxCallback", "da/d2e/structphNfcLib__DataParams__t.html#aba8374ef9de84e669d811121e25acc74", null ]
];