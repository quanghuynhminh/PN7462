/*
 *                  Copyright (c), NXP Semiconductors
 *
 *                     (C)NXP Semiconductors
 *       All rights are reserved. Reproduction in whole or in part is
 *      prohibited without the written consent of the copyright owner.
 *  NXP reserves the right to make changes without notice at any time.
 * NXP makes no warranty, expressed, implied or statutory, including but
 * not limited to any implied warranty of merchantability or fitness for any
 *particular purpose, or that the use will not infringe any third party patent,
 * copyright or trademark. NXP must not be liable for any loss or damage
 *                          arising from its use.
 */

/** \file
 * main.c
 * $Author: NXP74831 $
 * $Revision: 4133 $
 * $Date: 2014-05-06 15:22:51 +0530 (Tue, 06 May 2014) $
 *
 * History:
 *
 */
#include <cr_section_macros.h>
#include <NXP/crp.h>
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

#include "string.h"
#include "LPC17xx.h"
#include "usbapi.h"
#include "usbvcom.h"
#include "stdlib.h"
#include "serial_fifo.h"
#include "delay.h"
#include "iap.h"
#include "wdt.h"
#include "main.h"
#include "lpc_types.h"
#include "i2c_config.h"
#include "DUT.h"
#include "lpc17xx_i2c.h"
#include "gpio_17xx_40xx.h"
#include "DUT_I2C.h"
#include "DUT_SPI.h"
#include "DUT_HSU.h"
#include "stdint.h"
#include "phSysPOSApp.h"

#include "phSysCommon.h"

extern fifo_t txfifo;
extern fifo_t rxfifo;

/*
 * Function Name     : main
 * Description       : Entry point.
 * Input Parameters  : void
 * Output Parameters :
 * NOTE				 :
 */

int main(void)
{

	//uint16_t wbuf_len;
	/* Update the system core clock */
	SystemCoreClockUpdate();

	/* Configure P0.22 as output for LED usage */
	LPC_GPIO0->FIODIR |= LED_MASK;
	LPC_GPIO0->FIOSET |= LED_MASK;
	/*configure USB pins */
	Config_USB_Pins();

	/* Initialise the USB IP, Register all the callbacks required */
	USB_init();

	/* Initialise the FIFO */
	VCOM_init();

	/* Issue USB Connect command */
	USBHwConnect(TRUE);

	/*Set Data ready IRQ as INPUT*/
	DUT_GPIO_Config();

	/*Init Global variables*/
	LPC_FW_INIT();

	set_pinoutput();
	while(1)
		{
#if 0
		if (VCOM_Available() )
		{
			if(verifyincoming_data())
			{
						LPC_GPIO0->FIOCLR |= LED_MASK;
						SysPos_App(VCOM_getchar());
						LPC_GPIO0->FIOSET |= LED_MASK;
			}
		}
#endif

#if 1
		/*Enter POS Application*/
		SysPosAppMain();
#endif
		}


	return 0;

 }
