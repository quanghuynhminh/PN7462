/*
 *                  Copyright (c), NXP Semiconductors
 *
 *                     (C)NXP Semiconductors
 *       All rights are reserved. Reproduction in whole or in part is
 *      prohibited without the written consent of the copyright owner.
 *  NXP reserves the right to make changes without notice at any time.
 * NXP makes no warranty, expressed, implied or statutory, including but
 * not limited to any implied warranty of merchantability or fitness for any
 *particular purpose, or that the use will not infringe any third party patent,
 * copyright or trademark. NXP must not be liable for any loss or damage
 *                          arising from its use.
 */

/** \file
 * wdt.h
 * $Author: nxp47613 $
 * $Revision: 001 $
 * $Date: 2013-07-26 10:28:17 +0530 (Fri, 26 Jul 2013) $
 *
 * History:
 *
 */
#ifndef __WDT_H__
#define __WDT_H__

#include "stdint.h"

#define WDEN		(0x1<<0)
#define WDRESET		(0x1<<1)
#define WDTOF		(0x1<<2)
#define WDINT		(0x1<<3)

#define WDT_FEED_VALUE	0x0006FFFF


extern void WDT_IRQHandler(void);
extern uint32_t WDTInit( void );
extern void WDTFeed( void );
extern void WDTForceSysRst( void );

#endif /* __WDT_H__ */
