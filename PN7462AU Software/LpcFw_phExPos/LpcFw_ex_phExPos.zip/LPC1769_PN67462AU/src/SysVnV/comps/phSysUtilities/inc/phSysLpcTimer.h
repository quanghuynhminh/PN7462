/*
 * phSysLpcTimer.h
 *
 *  Created on: Jul 07, 2014
 *      Author: zz6036
 */

#ifndef _PHSYSLPCTIMER_H_
#define _PHSYSLPCTIMER_H_

#include "lpc17xx_clkpwr.h"
#include "lpc17xx_pinsel.h"
#include "LPC17xx.h"
#include "lpc_types.h"

void InitTimer1(void);
void StartTimer1(void);
void StopTimer1(void);
uint32_t GetTimer1Count(void);
uint32_t GetPeripheralClockRate(void);

#endif		//_PHSYSLPCTIMER_H_

/*************************************************************************************************************
 * 		EOF - End Of File
 ************************************************************************************************************/
