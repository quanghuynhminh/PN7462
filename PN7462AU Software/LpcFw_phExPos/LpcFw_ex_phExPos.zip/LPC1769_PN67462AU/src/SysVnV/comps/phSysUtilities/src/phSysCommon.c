#include "phSysCommon.h"

void delay_nop(volatile unsigned int Count)
{
	while(Count)
	{
		asm("nop");
		Count--;
	}


}
/**********************************************************************************/
// 					Configuration for the Evalution board                         //
/**********************************************************************************
 * 	HIF_SW1	| HIF_SW2 | HIF_SW3 | HIF_SW4 | HIF_SW5 | HIF_SW6	--> MODE
 * -----------------------------------------------------------------------
 *     1    |    1    |    0    |    1    |    0    |    0		--> I2C
 * -----------------------------------------------------------------------
 *     0    |    0    |    0    |    0    |    0    |    0		--> SPI
 * -----------------------------------------------------------------------
 *     0    |    1    |    1    |    0    |    0    |    0		--> HSU
 * -----------------------------------------------------------------------
 *     -    |    -    |    -    |    -    |    -    |    -		--> USB
 * -----------------------------------------------------------------------
 *     1    |    1    |    1    |    1    |    0    |    0		--> MASS STORAGE
 ***********************************************************************************/

void set_pinoutput ()
{
       SET_RST_PIN;
       Chip_GPIO_SetPinDIR((LPC_GPIO_T *)LPC_GPIO2,2, RST_PIN,1);//configure output port
       Chip_GPIO_SetPinDIR((LPC_GPIO_T *)LPC_GPIO0,0, DWLD_REQ_PIN,1);
       Chip_GPIO_SetPinDIR((LPC_GPIO_T *)LPC_GPIO0,0, HIF_SW1,1);
       Chip_GPIO_SetPinDIR((LPC_GPIO_T *)LPC_GPIO0,0, HIF_SW2,1);
       Chip_GPIO_SetPinDIR((LPC_GPIO_T *)LPC_GPIO0,0, HIF_SW3,1);
       Chip_GPIO_SetPinDIR((LPC_GPIO_T *)LPC_GPIO0,0, HIF_SW4,1);
       Chip_GPIO_SetPinDIR((LPC_GPIO_T *)LPC_GPIO1,1, HIF_SW5,1);
       Chip_GPIO_SetPinDIR((LPC_GPIO_T *)LPC_GPIO1,1, HIF_SW6,1);

}

void Switch_Massstorage ()
{
       SW1_SET;SW2_SET;SW3_SET;SW4_SET;SW5_RST;SW6_RST;
       SET_DWLD_PIN; delay(100);
       CLEAR_RST_PIN; delay(100);
       SET_RST_PIN;
       delay(100);
       CLEAR_DWLD_PIN;
       delay(100);
}

void Switch_I2CMode()
{
	set_pinoutput();
	/*For Eval Board*/
	/*SW1_RST;SW2_RST;SW3_SET;SW4_RST;SW5_RST;SW6_RST;*/

	/*For Performace board*/
	SW1_SET;SW2_RST;SW3_RST;SW4_RST;

    CLEAR_RST_PIN;
    	delay(100);
    SET_RST_PIN;
		delay(100);
}

void Switch_SPIMode()
{
	SW1_RST;SW2_RST;SW3_RST;SW4_RST;SW5_RST;SW6_RST;
}

void Switch_HSUMode()     //switch from I2C to HSU
{
	SW1_RST; SW2_SET; SW3_SET; SW4_RST; SW5_SET; SW6_SET;
}
