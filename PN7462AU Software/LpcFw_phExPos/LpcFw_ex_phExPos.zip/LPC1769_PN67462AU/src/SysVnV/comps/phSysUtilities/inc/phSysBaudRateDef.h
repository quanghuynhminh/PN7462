/*
 * phSysDef.h

 *
 *  Created on: Jul 07, 2014
 *      Author: zz6036
 */

#ifndef PHSYS_DEF_H_
#define PHSYS_DEF_H_

/*******************************************************
 * Common Enumerator used for Thruput Test only
 ******************************************************/

typedef enum			/*Common for I2C and SPI */
{
	BAUD_RATE_100K		= 100000,
	BAUD_RATE_400K		= 400000,
	BAUD_RATE_1000K		= 1000000,
	BAUD_RATE_1510K     = 1510000,
	BAUD_RATE_2000K     = 2000000,
	BAUD_RATE_2090K		= 2090000,
	BAUD_RATE_2470K		= 2470000,
	BAUD_RATE_3000K     = 3000000,
	BAUD_RATE_3010K		= 3010000,
	BAUD_RATE_4000K     = 4000000,
	BAUD_RATE_4052K		= 4052000,
	BAUD_RATE_5420K		= 5420000,
	BAUD_RATE_6780K		= 6780000,
	BAUD_RATE_7000K		= 7000000,
	BAUD_RATE_8000K		= 8000000

} eSysLpcBaudRate_t;

typedef enum			/* Baud Rate for HSU */
{
	BAUD_RATE_9600   = 9600,
	BAUD_RATE_19200  = 19200,
	BAUD_RATE_38400  = 38400,
	BAUD_RATE_57600  = 57600,
	BAUD_RATE_115200  = 115200,
	BAUD_RATE_230400 = 230400,
	BAUD_RATE_460800  = 460800,
	BAUD_RATE_921600  = 921600,
	BAUD_RATE_1288000  = 1288000,
	BAUD_RATE_2400000 = 2400000,
	BAUD_RATE_3500000  = 3500000,
	BAUD_RATE_3750000 = 3750000,
	BAUD_RATE_4000000 = 4000000,
	BAUD_RATE_5000000  = 5000000,
	BAUD_RATE_BR_SEMIAUTO  = 1000000,
	BAUD_RATE_BR_AUTO = 115200

} eSysLpcBaudRateHSU_t;

#endif		//PHSYS_DEF_H_
/*******************************************************************************************
 * END OF FILE
 *******************************************************************************************/
