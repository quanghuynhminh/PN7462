/** \file
 * main.h
 * $Author: zz6036 $
 * $Revision: 001 $
 * $Date: 2014-06-27 (Fri, 27 Jul 2014) $
 *
 * History:
 *
 */

#include "phSysLpcTimer.h"
#include "clock_17xx_40xx.h"

LPC_TIM_TypeDef *ptrTimer1 = (LPC_TIM_TypeDef *)LPC_TIM1;

void InitTimer1(void)
{
	ptrTimer1->TCR = 0x02;
	ptrTimer1->PR = 0xFF;
}

void StartTimer1(void)
{
    ptrTimer1->TCR = 0x01;
}

void StopTimer1(void)
{
    ptrTimer1->TCR = 0x00;
}

uint32_t GetTimer1Count(void)
{
    return(ptrTimer1->TC);
}

/**********************************************************/
//                            Timer frequency determination function
/**********************************************************/
uint32_t GetPeripheralClockRate()
{
	return (Chip_Clock_GetPeripheralClockRate(SYSCTL_PCLK_TIMER1));
}
//uint32_t lpc1769Timer1Freq = Chip_Clock_GetPeripheralClockRate(SYSCTL_PCLK_TIMER1);


/*************************************************************************************************************
 * 		EOF - End Of File
 ************************************************************************************************************/
