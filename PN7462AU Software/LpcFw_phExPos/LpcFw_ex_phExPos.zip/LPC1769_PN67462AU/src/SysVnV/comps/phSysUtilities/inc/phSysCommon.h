#ifndef PH_SYS_COMMON_H_
#define PH_SYS_COMMON_H_

#include "gpio_17xx_40xx.h"
#include "DUT.h"
#include "delay.h"

/**********************************************************************************/
// 					Configuration for the Evalution board                         //
/**********************************************************************************
 * 	HIF_SW1	| HIF_SW2 | HIF_SW3 | HIF_SW4 | HIF_SW5 | HIF_SW6	--> MODE
 * -----------------------------------------------------------------------
 *     1    |    1    |    0    |    1    |    0    |    0		--> I2C
 * -----------------------------------------------------------------------
 *     0    |    0    |    0    |    0    |    0    |    0		--> SPI
 * -----------------------------------------------------------------------
 *     0    |    1    |    1    |    0    |    0    |    0		--> HSU
 * -----------------------------------------------------------------------
 *     -    |    -    |    -    |    -    |    -    |    -		--> USB
 * -----------------------------------------------------------------------
 *     1    |    1    |    1    |    1    |    0    |    0		--> MASS STORAGE
 ***********************************************************************************/
#define HIF_SW1		26	// PO.26
#define HIF_SW2		25	// PO.25
#define HIF_SW3		24	// PO.24
#define HIF_SW4		23	// PO.23
#define HIF_SW5		30	// P1.30	//for Eval boad, only
#define HIF_SW6		31	// P1.31	//for Eval boad, only


#define SW1_SET              (LPC_GPIO0->FIOSET |= (1 << HIF_SW1))
#define SW1_RST	             (LPC_GPIO0->FIOCLR |= (1 << HIF_SW1))

#define SW2_SET              (LPC_GPIO0->FIOSET |= (1 << HIF_SW2))
#define SW2_RST            	 (LPC_GPIO0->FIOCLR |= (1 << HIF_SW2))

#define SW3_SET               (LPC_GPIO0->FIOSET |= (1 << HIF_SW3))
#define SW3_RST               (LPC_GPIO0->FIOCLR |= (1 << HIF_SW3))

#define SW4_SET               (LPC_GPIO0->FIOSET |= (1 << HIF_SW4))
#define SW4_RST               (LPC_GPIO0->FIOCLR |= (1 << HIF_SW4))

#define SW5_SET               (LPC_GPIO1->FIOSET |= (1 << HIF_SW5))
#define SW5_RST               (LPC_GPIO1->FIOCLR |= (1 << HIF_SW5))

#define SW6_SET               (LPC_GPIO1->FIOSET |= (1 << HIF_SW6))
#define SW6_RST               (LPC_GPIO1->FIOCLR |= (1 << HIF_SW6))


void delay_nop(volatile unsigned int Count);
void set_pinoutput (void);
void Switch_Massstorage (void);
void Switch_I2CMode (void);
void Switch_HSUMode (void);
void Switch_SPIMode(void);

#endif
