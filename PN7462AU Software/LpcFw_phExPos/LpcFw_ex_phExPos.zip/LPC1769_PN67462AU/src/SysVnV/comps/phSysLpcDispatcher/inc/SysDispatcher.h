/*
 * DUT.h
 *
 *  Created on: Jun 10, 2014
 *      Author: zz6036
 */

#ifndef SYSDISPATCHER_H_
#define SYSDISPATCHER_H_

#include "DUT.h"
#include "dut_status.h"
#include "SysCommonDef.h"


#define NO_OF_TEST_GROUP		(0X01)		//(0X0A)

#define SYS_COMMAND_CODE		(0X6B)

#define SIZE_OF_CMDCODE			(0X01)
#define SIZE_OF_INTERFACE		(0X01)
#define SIZE_OF_WLENGTH			(0X02)
#define SIZE_OF_STATUS_BYTE		(0X02)

//uint8_t gSizeOf_Payload;

#define SIZE_OF_CMDFRAME		(SIZE_OF_CMDCODE + SIZE_OF_INTERFACE + SIZE_OF_WLENGTH)
#define SIZE_OF_RSPFRAME		(SIZE_OF_CMDCODE + SIZE_OF_INTERFACE + SIZE_OF_STATUS_BYTE + SIZE_OF_WLENGTH)

typedef enum
{
	SYS_STATUS_SUCCESS									= 0X000,	/* Value return in case of success */
	ERR_TC_GROUP_NOT_FOUND								= 0xFF00,	/* Value return in case of Test-Group not found */
	ERR_TC_NOT_FOUND									= 0xFF01,	/* Value return in case of Test Case not found */
	ERR_HOST_NOT_CONFIG									= 0xFF12,	/* Value return in case of host not configure before communication */
	ERR_INVALID_PARAMETER								= 0XFF13

} eSysStatus_t;

typedef void (*pTestCaseType)(DUT_CmdFrame_t *);
typedef pTestCaseType *pTestGroupType;

/**************************************************************
 * 		External Functions
 *************************************************************/
//extern void SysDispatcher(DUT_CmdFrame_t *pInFrame, uint16_t wbuf_len);
extern void SysDispatcher(DUT_CmdFrame_t *pInFrame);

/**************************************************************
 * 		LOCAL Functions
 *************************************************************/
eSysStatus_t ExecuteLPCTest(DUT_CmdFrame_t *pInFrame);
Status SysDUT_I2Cx_M_Receive(LPC_I2C_TypeDef *I2Cx, uint8_t *buff, uint16_t len, uint8_t slaveAddr);

void SysTransparentExchange_I2C(DUT_CmdFrame_t *tranxchg_t);
void SysTransparentExchange_SPI(DUT_CmdFrame_t *tranxchg_t);
void SysTransparentExchange_HSU(DUT_CmdFrame_t *tranxchg_t);


#endif		//SYSDISPATCHER_H_
/*************************************************************************************************************
 * 		EOF - End Of File
 ************************************************************************************************************/
