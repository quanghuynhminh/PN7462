/*
 * DUT.h
 *
 *  Created on: Jun 10, 2014
 *      Author: zz6036
 */

#include "DUT_I2C.h"
#include "delay.h"
#include "dutCmd.h"
#include "lpc_types.h"
#include "SysDispatcher.h"


extern void SysLpcTestsInit(void);

// Array to hold all test group categories
pTestGroupType aSysLpcTestGroup[SYS_MAX_NO_TEST_GROUPS];
////uint8_t aSysMaxTestsperGroup[SYS_MAX_NO_TEST_GROUPS];

// through put tests functions array
pTestCaseType aSysThruputTests[SYS_MAX_THROUPUT_TESTS];

// P2P performance tests array
pTestCaseType aSysPerfP2PTests[SYS_MAX_PERFORMANCE_P2P_TESTS];

//void SysDispatcher(DUT_CmdFrame_t *pInFrame, uint16_t wbuf_len)
void SysDispatcher(DUT_CmdFrame_t *pInFrame)
{
	dutStatus_t status;
	//g_wbuf_len2 = wbuf_len;

	//if(SYS_COMMAND_CODE == pInFrame->bCmdCode)		//validate SystemVnV command code
	{
		if(pInFrame->pbData[0] & 0x80)		//Lpc append the parameter into the command frame
		{
			SysLpcTestsInit();
			status = ExecuteLPCTest(pInFrame);
		}
		else								//Lpc forward command frame to pn640
		{
			if(gCurr_Master == I2C0)
			{
				SysTransparentExchange_I2C(pInFrame);
			}
			else if(gCurr_Master == SSP0)
			{
				SysTransparentExchange_SPI(pInFrame);
			}
			else if(gCurr_Master == UART1)
			{
				SysTransparentExchange_HSU(pInFrame);
			}
			else						//I2C/SPI/HSU port is not configured.
			{
				LPC_Response_to_PC(pInFrame, ERR_HOST_NOT_CONFIG);
			}
		}
	}	//system command code
}

eSysStatus_t ExecuteLPCTest(DUT_CmdFrame_t *pInFrame)
{
	eSysStatus_t status = SYS_STATUS_SUCCESS;
    uint8_t bTstGrpNo, bTstId;
    pTestCaseType testcase;

    bTstGrpNo = ((pInFrame->pbData[0] >> 3) & 0x0F);

    //check for valid test group
    if ((bTstGrpNo > SYS_MAX_NO_TEST_GROUPS) || (aSysLpcTestGroup[bTstGrpNo] == NULL))
    {
    	status = ERR_TC_GROUP_NOT_FOUND;
    	return status;
    }
    bTstId = pInFrame->pbData[1]; // Is data1 is LSB??
    testcase = (aSysLpcTestGroup[bTstGrpNo])[bTstId];

    //check for valid test case
    if ((bTstId > SYS_MAX_THROUPUT_TESTS) || (aSysThruputTests[bTstId] == NULL))
    {
    	status = ERR_TC_NOT_FOUND;
		return status;
    }

    //Execute the test
    testcase(pInFrame);

    return status;
}

/**************************************************************
 * 		Pass the Command Packet to PN640, via I2C
 *************************************************************/
void SysTransparentExchange_I2C(DUT_CmdFrame_t *tranxchg_t)
{
	Status ret;
	DUT_RespFrame_t *resp_t = (DUT_RespFrame_t *)&Response_Buffer;

	/*TODO*//*Uses only I2C0 For the transreceive*/
	ret = DUT_I2Cx_M_Send(LPC_I2C0, &(tranxchg_t[0]),(SIZE_OF_CMDFRAME + tranxchg_t->wLength), gslave_addr);
	if(!ret)
	{
		LPC_Response_to_PC(tranxchg_t,DUT_STATUS_HW_IS_OFF);	//Need to decide the Error Response to send when transmit fails
		return;
	}

	ret = delay_1(g_wTimeOut);	//Wait for x-milliseconds for the data Ready line to go high
	if(ret)
	{
		//ret = SysDUT_I2Cx_M_Receive(LPC_I2C0, &(resp_t), (SIZE_OF_RSPFRAME +resp_t->wLength), gslave_addr);		//g_mode ????????
		ret = SysDUT_I2Cx_M_Receive(LPC_I2C0, &(resp_t[0]), (SIZE_OF_RSPFRAME +resp_t->wLength), gslave_addr);

		DUT_Response_to_PC(Response_Buffer, (SIZE_OF_RSPFRAME+resp_t->wLength));
	}
	else
	{
		LPC_Response_to_PC(tranxchg_t, PH_ERR_IO_TIMEOUT);
	}

}

/**************************************************************
 * 		Pass the Command Packet to PN640, via SPI
 *************************************************************/
void SysTransparentExchange_SPI(DUT_CmdFrame_t *tranxchg_t)
{
	//TODO:

}

/**************************************************************
 * 		Pass the Command Packet to PN640, via HSU
 *************************************************************/
void SysTransparentExchange_HSU(DUT_CmdFrame_t *tranxchg_t)
{
	//TODO:
}

/*API to receive data from the I2C0 configured to be the master*/
Status SysDUT_I2Cx_M_Receive(LPC_I2C_TypeDef *I2Cx, uint8_t *buff, uint16_t len, uint8_t slaveAddr)
{
	Status passfail;

	I2C_M_SETUP_Type Receive_data;
	Receive_data.sl_addr7bit = slaveAddr;
	Receive_data.rx_data=buff;
	Receive_data.tx_length = 0;
	Receive_data.tx_data = NULL;
	Receive_data.retransmissions_max =5;

	/*NATIVE mode where the length is given by the I2C RX command*/
	Receive_data.rx_length = len;
	if(I2C_MasterTransferData(I2Cx, &Receive_data,I2C_TRANSFER_POLLING))
	{
		passfail = SUCCESS;
	}
	else
	{
		passfail = ERROR;
	}
	return passfail;
}

/*************************************************************************************************************
 * 		EOF - End Of File
 ************************************************************************************************************/


