

#ifndef SYS_COMMON_DEF_H_
#define SYS_COMMON_DEF_H_

/*******************************************************
 * Test Groups List
 ******************************************************/
typedef enum
{
	SYS_INTEROP_RD_TESTS_GROUP = 0,
	SYS_INTEROP_P2P_TESTS_GROUP,
	SYS_INTEROP_CE_TESTS_GROUP,
	SYS_PERF_P2P_TESTS_GROUP,
	SYS_PERF_RD_TESTS_GROUP,
	SYS_STABILITY_TESTS_GROUP,
	SYS_MULTI_IF_TESTS_GROUP,
	SYS_CT_IF_TESTS_GROUP,
	SYS_USECASE_TESTS_GROUP,
	SYS_THRUPUT_TESTS_GROUP,
	SYS_SINGLE_TEST_GROUP,
	SYS_MIS_TESTS_GROUP,
	SYS_MAX_NO_TEST_GROUPS
} eSysTestCategory_t;

/*******************************************************
 * Thruput Test List
 ******************************************************/
typedef enum
{
	SYS_THRUPUT_TEST_I2CM = 0,
	SYS_THRUPUT_TEST_SPIM,
	SYS_THRUPUT_TEST_I2C_HOST,
	SYS_THRUPUT_TEST_SPI_HOST,
	SYS_THRUPUT_TEST_UART_HOST,
	SYS_MAX_THROUPUT_TESTS
} eSysThruputTests_t;

/*******************************************************
 * P2P Performance Tests List
 ******************************************************/
// P2P performance tests list , it is sample but not complete list.
typedef enum
{
	SYS_PERF_P2P_TEST_01 = 0,   // May be we can give more logical names for test ids, something like this: SYS_PERF_P2P_I2C_P_INITIATOR
	SYS_PERF_P2P_TEST_02,
	SYS_PERF_P2P_TEST_03,
	SYS_PERF_P2P_TEST_04,
	SYS_PERF_P2P_TEST_05,
	SYS_PERF_P2P_TEST_06,
	SYS_MAX_PERFORMANCE_P2P_TESTS
} eSysPerfP2PTests_t;

typedef enum
{
	SYS_ERR_TC_GROUP_NOT_FOUND = 0x8001,   // May be we can give more logical names for test ids, something like this: SYS_PERF_P2P_I2C_P_INITIATOR
	SYS_ERR_TC_NOT_FOUND = 0x8002,
	SYS_ERR_INPUT_PARAMS = 0x8003

} eSysErroCodes_t;


typedef enum
{
       RF_BAUD_RATE_TAG = 0x0,
       DATA_TAG,
       IF_BAUD_RATE_TAG,
       PACKET_SIZE_TAG,
       REPEAT_CNT_TAG,
       CUSTOM_TAG,
       SPI_POL_PHASE_TAG
}SysPayLoad_Tag;


#endif	/* SYS_COMMON_DEF_H_ */
