/*
 * phSysPOSApp.h
 *
 *  Created on: May 19, 2015
 *      Author: nxp82942
 */

#ifndef PHSYSPOSAPP_H_
#define PHSYSPOSAPP_H_

#include "DUT.h"
#include "dut_status.h"
#include "phSysLpcTimer.h"
#include "SysCommonDef.h"
#include "dutCmd.h"
#include "DUT_I2C.h"
#include "DUT_SPI.h"
#include "gpio_17xx_40xx.h"
#include "lpc17xx_ssp.h"
#include "delay.h"
#include <stdio.h>
#include <string.h>
#include "usbvcom.h"
#include "phSysCommon.h"
#include "phSysBaudRateDef.h"
#include <stdlib.h>

/*******************************************************************************************
 *FUNCTIONS
 *******************************************************************************************/
void SysPosAppMain();
void SysSSPx_Configuration();
void Write_Data(uint8_t *data_s, uint16_t len_s);
void Read_Data(uint8_t *data_r, uint16_t len_r);
Bool Iterrupt_availaible(void);
void WaitForGPIOIdle();
void WaitForGPIOBusy();
void SendCmd(const char *cmd,uint8_t cmd_size,char *cmd_name);
void SendApduCmd(const char *cmd,uint8_t cmd_size,char *cmd_name);
void PosApp(void);
uint8_t CheckSuccessCode();
void print_on_console();
void DeActivate_Card();
void print_trans_incomp(void);
void print_rsp_err();
void Init_Var(void);
void print_command(const char *cmd,uint8_t cmd_size,char *cmd_name);
void print_response(void);
#endif /* PHSYSPOSAPP_H_ */
/*******************************************************************************************
 * END OF FILE
 *******************************************************************************************/



