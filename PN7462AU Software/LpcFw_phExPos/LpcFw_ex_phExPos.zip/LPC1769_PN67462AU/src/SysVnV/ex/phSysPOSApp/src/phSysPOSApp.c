/*
 * phSysPOSApp.c
 *
 *  Created on: May 19, 2015
 *      Author: nxp82942
 */

#include "phSysPOSApp.h"
#include "USBVcom.h"

uint32_t RID;
char time[30];
uint8_t count;
uint8_t CL_card;
uint8_t CT_card;
char cmd_str[10];
char rsp_str[10];
uint8_t JCOP_crd;
uint8_t Mastercard;
uint32_t dwTimeSec;
uint8_t bClkPolPhase;
uint32_t dwSysTimerCount;
static uint32_t dwBaudRate;
uint8_t gTxBuff[262];
uint8_t gRxBuff[262];
uint8_t aConfig_cmd_buffer[20];
static uint16_t ReceivePacketSize;
static uint16_t LengthPacketSize = 0x05;
volatile uint32_t dwSysT1Count, dwSysT2Count;

#define PH_EXPOS_COMMON_EVENT_BYTE                     0x00U

#define E_STS_NO_EVENT                                 0x00U
#define E_TYPEA_BANKING_CARD_INSERTION_EVENT           0x01U
#define E_TYPEB_BANKING_CARD_INSERTION_EVENT           0x02U
#define E_CT_BANKING_CARD_INSERTION_EVENT              0x03U
#define E_TYPEA_NONBANKING_CARD_INSERTION_EVENT        0x04U
#define E_TYPEB_CARD_INSERTION_EVENT                   0x05U
#define E_CARD_REMOVAL_EVENT                           0x06U

#define PH_EXPOS_COMMON_VISA_CARD                      0XA00003
#define PH_EXPOS_COMMON_MASTER_CARD                    0XA00004


char cmnd[] = "[C]  ";
char rsp[] =  "[R]  ";
char sw[] = "[SW]  ";
char err[] = "Error....\r\n";
char new_line[] = "\r\n        ";
char ms[] = " milli seconds \r\n";
char Err_rsp[] = "ERROR IN RESPONSE \r\n";
char No_file[] = "FILE NOT FOUND....\r\n\r\n";
char CT_crd[] ="CT CARD DETECTED. \r\n\r\n";
char crd_removed[] = "CARD REMOVED \r\n\r\n";
char No_record[] = "RECORD NOT FOUND...\r\n\r\n";
char insert_crd[] = "INSERT THE CARD....\r\n\r\n";
char remove_crd[] = "REMOVE THE CARD....\r\n\r\n";
char no_crd[] = "NO CARD IS PRESENT.....\r\n\r\n";
char wrng_crd[] = "WRONG CARD INSERTED...\r\n\r\n";
char Ttime[] ="Total Pay pass transaction Time = ";
char CL_trans_incmp[] = "CL Transaction ERROR!.... \r\n\r\n";
char CT_trans_incmp[] = "CT Transaction ERROR!.... \r\n\r\n";
char typeA_CL_crd[] = "CL CARD DETECTED..... TYPE A CARD.....\r\n\r\n";
char typeB_CL_crd[] = "CL CARD DETECTED..... TYPE B CARD.....\r\n\r\n";
char remove_CT_crd[] = "TRANSACTION COMPLETE...\r\n REMOVE CT CARD \r\n\r\n";
char remove_CL_crd[] = "TRANSACTION COMPLETE...\r\n REMOVE CL CARD \r\n\r\n";
char non_bnkcrdA[] = "CL CARD DETECTED.......NON BANKING TYPE A CARD......\r\n\r\n";
char non_bnkcrdB[] = "CL CARD DETECTED.......NON BANKING TYPE B CARD......\r\n\r\n";
char no_ppse[] = "Could not use PPSE to select the application\r\n";
char list_appl[] = "Attempting to select the application using the list of applications method\r\n\r\n";
char master_crd[] = "Application name (AID): A0 00 00 00 04 10 10\r\nApplication label: MASTERCARD\r\n\r\n";
char visa_crd[] = "Application name (AID): A0 00 00 00 03 10 10\r\nApplication label: VISA DEBIT/CREDIT\r\n\r\n";
char maestro_crd[] = "Application name (AID): A0 00 00 00 04 30 60\r\nApplication label: MAESTRO DEBIT\r\n\r\n";
char wel_pos[] = "\r\n***************WELCOME TO POS APPLICATION***************\r\n\r\n";
char dots[] = "******************************************************************\r\n\r\n";


/************************ Control Commands *****************************************/
char GetCfg[] = "Get configuration";
const char aGetCfgCmd[] =
{
         0x00, //This byte is as per SPI standard
         0x05, 0x00, 0x00, 0x00, //These 4 bytes indicate the length of the pay load
         0xFF, 0xF8, 0x00, 0x00, 0x00
};

char GetStatus[] = "Get Status";
const char aGetStatusCmd[] =
{
         0x00,
         0x05, 0x00, 0x00, 0x00,
         0xFF, 0xF8, 0x02, 0x00, 0x00
};

char GetAtr[] = "Get ATR";
const char aGetAtrCmd[] =
{
         0x00,
         0x05, 0x00, 0x00, 0x00,
         0xFF, 0xF8, 0x03, 0x00, 0x00
};

char DeActCard[] = "Deactivate Card";
const char aDeActCardCmd[] =
{
         0x00,
         0x05, 0x00, 0x00, 0x00,
         0xFF, 0xF8, 0x04, 0x00, 0x00
};

char EnPol[] = "Enable Polling";
const char aEnPolCmd[] =
{
         0x00,
         0x05, 0x00, 0x00, 0x00,
         0xFF, 0xF8, 0x07, 0x01, 0x00
};

char GetUID[] = "Get UID";
const char aGetUIDCmd[] =
{
         0x00,
         0x05, 0x00, 0x00, 0x00,
         0xFF, 0xF8, 0x0C, 0x00, 0x00
};
/*************************************************************************************/
/********************* APDU commands ************************************************/
char SelPPSE[] = "SELECT the PPSE directory";
const char aSelPPSECmd[] =
{
         0x00,
         0x14, 0x00, 0x00, 0x00,
         0x00, 0xA4, 0x04, 0x00, 0x0E, 0x32, 0x50, 0x41, 0x59, 0x2E,
         0x53, 0x59, 0x53, 0x2E, 0x44, 0x44, 0x46, 0x30, 0x31, 0x00
};

char SelApplmaster[] = "Select MasterCard application";
const char aSelApplmaster[] =
{
         0x00,
         0x0D, 0x00, 0x00, 0x00,
         0x00, 0xA4, 0x04, 0x00, 0x07, 0xA0, 0x00, 0x00, 0x00,
         0x04, 0x10, 0x10, 0x00
};
char SelApplvisa[] = "Select Visa Application";
const char aSelApplvisa[] =
{
        0x00,
        0x0D, 0x00, 0x00, 0x00,
        0x00, 0xA4, 0x04, 0x00, 0x07, 0xA0, 0x00, 0x00, 0x00,
        0x03, 0x10, 0x10, 0x00
};
char SelApplmaestro[] = "Select Maestro Application";
const char aSelApplmaestro[] =
{
        0x00,
        0x0D, 0x00, 0x00, 0x00,
        0x00, 0xA4, 0x04, 0x00, 0x07, 0xA0, 0x00, 0x00, 0x00,
        0x04, 0x30, 0x60, 0x00
};

char GetProcOpt[] = "Get the Application File Locator (AFL)\r\nSend GET PROCESSING OPTIONS command";
const char aGetProcOptCmd[] =
{
        0x00,
        0x08, 0x00, 0x00, 0x00,
        0x80, 0xA8, 0x00, 0x00, 0x02, 0x83, 0x00, 0x00

};
/**********************************************************************************************/
/************************ CL Related commands to read the records *****************************/
char ReadRec1SFI2[] = "READ CL RECORD command (SFI 2 Record 1)";
const char aReadRec1SFI2Cmd[] =
{
        0x00,
        0x05, 0x00, 0x00, 0x00,
        0x00, 0xB2, 0x01, 0x14, 0x00
};

char ReadRec1SFI3[] = "READ CL RECORD command (SFI 3 Record 1)";
const char aReadRec1SFI3Cmd[] =
{
        0x00,
        0x05, 0x00, 0x00, 0x00,
        0x00, 0xB2, 0x01, 0x1C, 0x00
};

char ReadRec1SFI4[] = "READ CL RECORD command (SFI 4 Record 1)";
const char aReadRec1SFI4Cmd[] =
{
        0x00,
        0x05, 0x00, 0x00, 0x00,
        0x00, 0xB2, 0x01, 0x24, 0x00
};

char ReadRec2SFI4[] = "READ CL RECORD command (SFI 4 Record 2)";
const char aReadRec2SFI4Cmd[] =
{
        0x00,
        0x05, 0x00, 0x00, 0x00,
        0x00, 0xB2, 0x02, 0x24, 0x00
};
/************************************************************************************************/
/************************ CT Related commands to read the records *******************************/

char ReadRecCT2SFI2[] = "READ CT RECORD command (SFI 2 Record 2)";
const char aReadRecCT2SFI2Cmd[] =
{
    0x00,
    0x05, 0x00, 0x00, 0x00,
    0x00,0xB2,0x02,0x14,0x00
};

char ReadRecCT2SFI3[] = "READ CT RECORD command (SFI 2 Record 3)";
const char aReadRecCT2SFI3Cmd[] =
{
    0x00,
    0x05, 0x00, 0x00, 0x00,
    0x00,0xB2,0x03,0x14,0x00
};

char ReadRecCT3SFI1[] = "READ CT RECORD command (SFI 3 Record 1)";
const char aReadRecCT3SFI1Cmd[] =
{
    0x00,
    0x05, 0x00, 0x00, 0x00,
    0x00,0xB2,0x01,0x1C,0x00
};

char ReadRecCT4SFI1[] = "READ CT RECORD command (SFI 4 Record 1)";
const char aReadRecCT4SFI1Cmd[] =
{
    0x00,
    0x05, 0x00, 0x00, 0x00,
    0x00,0xB2,0x01,0x24,0x00
};

char ReadRecCT5SFI1[] = " READ CT RECORD command (SFI 5 Record 1)";
const char aReadRecCT5SFI1Cmd[] =
{
    0x00,
    0x05, 0x00, 0x00, 0x00,
    0x00,0xB2,0x01,0x2C,0x00
};

char ReadRecCT5SFI2[] = " READ CT RECORD command (SFI 5 Record 2)";
const char aReadRecCT5SFI2Cmd[] =
{
    0x00,
    0x05, 0x00, 0x00, 0x00,
    0x00,0xB2,0x02,0x2C,0x00
};

/************************************************************************************************/
char GenAc[] = "GENERATE AC command";
const char aGenAcCmd[] =
{
    0x00,
    0x31, 0x00, 0x00, 0x00,
    0x80, 0xAE, 0x50, 0x00, 0x2B, 0x00, 0x00, 0x00, 0x00, 0x02,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x56, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x09, 0x78, 0x14, 0x08, 0x13, 0x00,
    0x45, 0x11, 0x15, 0x61, 0x23, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x3F, 0x00, 0x00, 0x00
};

/************************************************************************************************/

void SysPosAppMain()
{

    /*Restart the PN7462AU when debug mode is not used*/
    #ifdef NDEBUG
    CLEAR_RST_PIN;
    delay(0x10);
    SET_RST_PIN;
    delay(0x100);
    #endif

    /*Make SPI as Host Interface*/
    Switch_SPIMode();

    /*Configure SPI. LPC acts as SPI host*/
    SysSSPx_Configuration();

    /*GPIO pin is used for synchronization between command and response through SPI*/
    Chip_GPIO_SetPortDIRInput(LPC_GPIO_0,0,4);

    /*start the POS application*/
    PosApp();
}

/***************************************************************************************************************************************************
 * 		POS Application
 **************************************************************************************************************************************************/
void PosApp()
{
    while(1)
    {
        /*Print POS application welcome message*/
        VCOM_putstring(wel_pos);

        /*Get Configuration Command*/
        SendCmd(aGetCfgCmd,sizeof(aGetCfgCmd),GetCfg);

        /*Enable Polling Command*/
        SendCmd(aEnPolCmd,sizeof(aEnPolCmd),EnPol);

        /*Print a message to indicate the user to insert the card*/
        VCOM_putstring(insert_crd);

        /*Wait for Card insertion Interrupt from PN7462AU*/
        while(!Iterrupt_availaible());

        /*Initialize the timer and get the timer count before transaction starts*/
    	StopTimer1();
    	InitTimer1();
    	StartTimer1();
    	dwSysT1Count = GetTimer1Count();

        /*Initialize the variables related to the transaction*/
        Init_Var();

        /*Get Status Command*/
        SendApduCmd(aGetStatusCmd,sizeof(aGetStatusCmd),GetStatus);

        /*First byte in the response to Get Status Command contains information about the type of the card detected*/
        switch(gRxBuff[PH_EXPOS_COMMON_EVENT_BYTE])
        {
            /*Contact less Type A banking card*/
            case E_TYPEA_BANKING_CARD_INSERTION_EVENT:
            {
                CL_card = true;
                VCOM_putstring(typeA_CL_crd);
                break;
            }
            /*Contact less Type B banking card*/
            case E_TYPEB_BANKING_CARD_INSERTION_EVENT:
            {
                VCOM_putstring(typeB_CL_crd);
                SendCmd(aGetUIDCmd,sizeof(aGetUIDCmd),GetUID);
                DeActivate_Card();
                continue;
            }
            /*CT card*/
            case E_CT_BANKING_CARD_INSERTION_EVENT:
            {
                CT_card = true;
                VCOM_putstring(CT_crd);
                break;
            }
            /*Non banking card*/
            case E_TYPEA_NONBANKING_CARD_INSERTION_EVENT:
            {
                VCOM_putstring(non_bnkcrdA);
                SendCmd(aGetUIDCmd,sizeof(aGetUIDCmd),GetUID);
                SendCmd(aGetStatusCmd,sizeof(aGetStatusCmd),GetStatus);
                /*If card is still present, wait till it is removed*/
                if (!(gRxBuff[PH_EXPOS_COMMON_EVENT_BYTE] == E_CARD_REMOVAL_EVENT))
                {
                    VCOM_putstring(remove_crd);
                    while(!Iterrupt_availaible());

                    SendCmd(aGetStatusCmd,sizeof(aGetStatusCmd),GetStatus);
                    if (gRxBuff[PH_EXPOS_COMMON_EVENT_BYTE] == E_CARD_REMOVAL_EVENT)
                    {
                        VCOM_putstring(crd_removed);
                    }
                }
                VCOM_putstring(dots);
                continue;
            }
            /*TypeB card*/
            case E_TYPEB_CARD_INSERTION_EVENT:
            {
                VCOM_putstring(non_bnkcrdB);
                SendCmd(aGetUIDCmd,sizeof(aGetUIDCmd),GetUID);
                SendCmd(aGetStatusCmd,sizeof(aGetStatusCmd),GetStatus);
                /*If card is still present, wait till it is removed*/
                if (!(gRxBuff[PH_EXPOS_COMMON_EVENT_BYTE] == E_CARD_REMOVAL_EVENT))
                {
                    VCOM_putstring(remove_crd);
                    while(!Iterrupt_availaible());

                    SendCmd(aGetStatusCmd,sizeof(aGetStatusCmd),GetStatus);
                    if (gRxBuff[PH_EXPOS_COMMON_EVENT_BYTE] == E_CARD_REMOVAL_EVENT)
                    {
                        VCOM_putstring(crd_removed);
                    }
                }
                VCOM_putstring(dots);
                continue;
            }
            /*Card Removal event*/
            case E_CARD_REMOVAL_EVENT:
            {
                VCOM_putstring(no_crd);
                continue;
            }
            /*It is not expected to reach here*/
            default:
            	VCOM_putstring(no_crd);
                continue;
        }

    /*If the card inserted is contact less card, send appropriate commands*/
    if (CL_card)
    {
        /*Get UID Command*/
        SendApduCmd(aGetUIDCmd,sizeof(aGetUIDCmd),GetUID);

        /*Get ATR command*/
		SendApduCmd(aGetAtrCmd,sizeof(aGetAtrCmd),GetAtr);

		/*Check whether the inserted card is a JCOP card (Test Card) or not*/
		for(count=0; count<ReceivePacketSize; count++)
		{
			if (gRxBuff[count] == 0x4A)
			{
				if ((gRxBuff[count+1] == 0x43) && (gRxBuff[count+2] == 0x4F) && (gRxBuff[count+3] == 0x50))
				JCOP_crd = 1;
			}
		}

        /*Select PPSE Command*/
        SendApduCmd(aSelPPSECmd,sizeof(aSelPPSECmd),SelPPSE);

        /*If Select PPSE commands get a success response then, get the RID of the the application in the card
         * and print the type of the application in the card*/
        /*"9000" is the success code*/
		if((gRxBuff[ReceivePacketSize-1] == 0x00) || (gRxBuff[ReceivePacketSize-2] == 0x90))
		{

            for(count=0; count<ReceivePacketSize; count++)
            {
                if (gRxBuff[count] == 0xA0)
                {
                    RID = (((gRxBuff[count])<<16) | ((gRxBuff[count+3])<<8)  | (gRxBuff[count+4]));
                }
            }

            /*Display the type of the EMV card*/
            switch(RID)
            {
                /*VISA card*/
                case (PH_EXPOS_COMMON_VISA_CARD):
                {
                    VCOM_putstring(visa_crd);
                    break;
                }
                /*Master card*/
                case (PH_EXPOS_COMMON_MASTER_CARD):
                {
                    VCOM_putstring(master_crd);
                    Mastercard = 1;
                    break;
                }
                default:
                {
                    VCOM_putstring(wrng_crd);
                    DeActivate_Card();
                    continue;
                }
            }

		}
		else
			/*If Select PPSE command fails then, try to select the application using the list of applications method*/
		{
			VCOM_putstring(no_ppse);
			VCOM_putstring(list_appl);
			/*select Master Card application if present*/
	        SendApduCmd(aSelApplmaster,sizeof(aSelApplmaster),SelApplmaster);
	    	if(0x01 == CheckSuccessCode())
			{
                VCOM_putstring(master_crd);
                Mastercard = 1;
			}

	    	/*select Visa application if present*/
	        SendApduCmd(aSelApplvisa,sizeof(aSelApplvisa),SelApplvisa);
	    	if(0x01 == CheckSuccessCode())
			{
                VCOM_putstring(visa_crd);
			}

	    	/*select Maestro application if present*/
	        SendApduCmd(aSelApplmaestro,sizeof(aSelApplmaestro),SelApplmaestro);
	    	if(0x01 == CheckSuccessCode())
			{
                VCOM_putstring(maestro_crd);
			}

		}


        /*If the card inserted is non JCOP Banking card or if it does not have the Master Card application,
         * then discontinue the transactions and go back to polling Command*/
        if (!(JCOP_crd && Mastercard))
        {
            VCOM_putstring(wrng_crd);
			DeActivate_Card();
            continue;
        }

        /*Select Application Command*/
        SendApduCmd(aSelApplmaster,sizeof(aSelApplmaster),SelApplmaster);

        /*Get Processing options Command*/
        SendApduCmd(aGetProcOptCmd,sizeof(aGetProcOptCmd),GetProcOpt);

        /*Read Record Commands*/
        SendApduCmd(aReadRec1SFI2Cmd,sizeof(aReadRec1SFI2Cmd),ReadRec1SFI2);

        SendApduCmd(aReadRec1SFI3Cmd,sizeof(aReadRec1SFI3Cmd),ReadRec1SFI3);

        SendApduCmd(aReadRec1SFI4Cmd,sizeof(aReadRec1SFI4Cmd),ReadRec1SFI4);

        SendApduCmd(aReadRec2SFI4Cmd,sizeof(aReadRec2SFI4Cmd),ReadRec2SFI4);

        /*Generate AC command*/
        SendApduCmd(aGenAcCmd,sizeof(aGenAcCmd),GenAc);

        /*Deactivate card Command*/
        SendApduCmd(aDeActCardCmd,sizeof(aDeActCardCmd),DeActCard);

        /*Display a message to indicate the user to remove the card*/
        VCOM_putstring(remove_CL_crd);
    }

    /*If the card inserted is contact card, send appropriate commands*/
    else if (CT_card)
    {
        /*Get ATR command*/
        SendApduCmd(aGetAtrCmd,sizeof(aGetAtrCmd),GetAtr);

        /*Check whether the inserted card is a JCOP card (Test Card) or not*/
        for(count=0; count<ReceivePacketSize; count++)
        {
            if (gRxBuff[count] == 0x4A)
            {
                if ((gRxBuff[count+1] == 0x43) && (gRxBuff[count+2] == 0x4F) && (gRxBuff[count+3] == 0x50))
                JCOP_crd = 1;
            }
        }

        /*Select PPSE Command*/
        SendApduCmd(aSelPPSECmd,sizeof(aSelPPSECmd),SelPPSE);

        /*If Select PPSE commands get a success response then, get the RID of the the application in the card
         * and print the type of the application in the card*/
        /*"9000" is the success code*/
		if((gRxBuff[ReceivePacketSize-1] == 0x00) || (gRxBuff[ReceivePacketSize-2] == 0x90))
		{

            for(count=0; count<ReceivePacketSize; count++)
            {
                if (gRxBuff[count] == 0xA0)
                {
                    RID = (((gRxBuff[count])<<16) | ((gRxBuff[count+3])<<8)  | (gRxBuff[count+4]));
                }
            }

            /*Display the type of the EMV card*/
            switch(RID)
            {
                case (PH_EXPOS_COMMON_VISA_CARD):
                {
                    VCOM_putstring(visa_crd);
                    break;
                }
                case (PH_EXPOS_COMMON_MASTER_CARD):
                {
                    VCOM_putstring(master_crd);
                    Mastercard = 1;
                    break;
                }
                default:
                {
                    VCOM_putstring(wrng_crd);
    			    DeActivate_Card();
                    continue;
                }
            }

		}
		else
			/*If Select PPSE command fails then, try to select the application using the list of applications method*/
		{
			VCOM_putstring(no_ppse);
			VCOM_putstring(list_appl);
			/*Select master card application if present*/
	        SendApduCmd(aSelApplmaster,sizeof(aSelApplmaster),SelApplmaster);
	    	if(0x01 == CheckSuccessCode())
			{
                VCOM_putstring(master_crd);
                Mastercard = 1;
			}

	    	/*select VISA application if present*/
	        SendApduCmd(aSelApplvisa,sizeof(aSelApplvisa),SelApplvisa);
	    	if(0x01 == CheckSuccessCode())
			{
                VCOM_putstring(visa_crd);
			}

	    	/*select Maestro application if present*/
	        SendApduCmd(aSelApplmaestro,sizeof(aSelApplmaestro),SelApplmaestro);
	    	if(0x01 == CheckSuccessCode())
			{
                VCOM_putstring(maestro_crd);
			}

		}


        /*If the card inserted is non JCOP Banking card or if it does not have the Master Card application,
         * then discontinue the transactions and go back to polling Command*/
        if (!(JCOP_crd && Mastercard))
        {
            VCOM_putstring(wrng_crd);
			DeActivate_Card();
            continue;
        }


        /*Select Application Command*/
       SendApduCmd(aSelApplmaster,sizeof(aSelApplmaster),SelApplmaster);

        /*Get Processing options Command*/
        SendApduCmd(aGetProcOptCmd,sizeof(aGetProcOptCmd),GetProcOpt);

        /*Read Record Commands*/
        SendApduCmd(aReadRecCT2SFI2Cmd,sizeof(aReadRecCT2SFI2Cmd),ReadRecCT2SFI2);

        SendApduCmd(aReadRecCT2SFI3Cmd,sizeof(aReadRecCT2SFI3Cmd),ReadRecCT2SFI3);

        SendApduCmd(aReadRecCT3SFI1Cmd,sizeof(aReadRecCT3SFI1Cmd),ReadRecCT3SFI1);

        SendApduCmd(aReadRecCT4SFI1Cmd,sizeof(aReadRecCT4SFI1Cmd),ReadRecCT4SFI1);

        SendApduCmd(aReadRecCT5SFI1Cmd,sizeof(aReadRecCT5SFI1Cmd),ReadRecCT5SFI1);

        SendApduCmd(aReadRecCT5SFI2Cmd,sizeof(aReadRecCT5SFI2Cmd),ReadRecCT5SFI2);

        /*Generate AC command*/
        SendApduCmd(aGenAcCmd,sizeof(aGenAcCmd),GenAc);

        /*Deactivate card Command*/
        SendApduCmd(aDeActCardCmd,sizeof(aDeActCardCmd),DeActCard); //Deactivate Card

        /*Display a message to indicate the user to remove the card*/
        VCOM_putstring(remove_CT_crd);
    }

    else
    {
        /*It is not expected to reach here*/
        continue;
    }

	/*Calculate the time taken between sending command and receiving response. Stop the timer*/
	dwSysT2Count = GetTimer1Count();
	dwSysTimerCount = (dwSysT2Count - dwSysT1Count);
	/*Time in microseconds*/
	dwTimeSec = (dwSysTimerCount * 10240)/1000000;
	StopTimer1();

    VCOM_putstring(Ttime);
    itoa(dwTimeSec,time,10);
    VCOM_putstring(time);
    VCOM_putstring(ms);
    VCOM_putchar('\r');
    VCOM_putchar('\n');

    /*Wait for card removal interrupt for PN7462AU*/
    while(!Iterrupt_availaible());

    SendCmd(aGetStatusCmd,sizeof(aGetStatusCmd),GetStatus);
    if (gRxBuff[PH_EXPOS_COMMON_EVENT_BYTE] == E_CARD_REMOVAL_EVENT)
    {
        VCOM_putstring(crd_removed);
    }
    VCOM_putstring(dots);

    }
}


/*
 *Function Name     : SysSSPx_Configuration
 *Description       : Configure SPI of LPC as master
 */
void SysSSPx_Configuration()
{
	DUT_CmdFrame_t *pSPImasterConfigFrame = (DUT_CmdFrame_t *)aConfig_cmd_buffer;
	dwBaudRate   = BAUD_RATE_7000K;
	bClkPolPhase = 0x00;

	pSPImasterConfigFrame->bCmdCode = LPC1769_COMP_CODE;						// SPI config. command
	pSPImasterConfigFrame->interface = 0x40;									// try to configure "1st" SPI Port(i.e. SSP0).
	pSPImasterConfigFrame->wLength = 0x0A;										// length of payload need to be store(LSB-1st, MSB-2nd).
	pSPImasterConfigFrame->pbData[0] = 0x01;									// it(SSP0) act as a Master=0x01
	pSPImasterConfigFrame->pbData[1] = (bClkPolPhase & 0x01);					// CPOL(bit-0 in PN7462AU)
	pSPImasterConfigFrame->pbData[2] = ((bClkPolPhase & 0x02) >> 1);			// CPHA(bit-1 in PN7462AU)
	*((uint32_t*)(&pSPImasterConfigFrame->pbData[3])) = dwBaudRate;				// baud rate
	pSPImasterConfigFrame->pbData[7] = 0x42;									// Handling mode: Polling mode, SPI Mode: Native
	*((uint16_t*)(&pSPImasterConfigFrame->pbData[8])) = 0xFFFF;					// Time out

	DUT_CmdFrame_t *SPI_Cfg_t = pSPImasterConfigFrame;

	dutMasterSlave_t SPI_M_S = SPI_Cfg_t->pbData[0];
	uint8_t CPOL = (SPI_Cfg_t->pbData[1]);
	uint8_t CPHA = (SPI_Cfg_t->pbData[2]);
	uint32_t clockrate = *((uint32_t*)(&SPI_Cfg_t->pbData[3]));
	if((((SPI_Cfg_t->interface >> 3) & 0x03) == SSP0) && SPI_M_S == MASTER)
	{
		/*Configure SSP0 as master*/
		gCurr_Master = SSP0;
		gCurr_Master |= 0x10;
		g_wTimeOut = SPI_Cfg_t->pbData[9];/*Time out is here because we need it in transreceive*/
		g_wTimeOut <<= 8;
		g_wTimeOut |= SPI_Cfg_t->pbData[8];
		g_wait_DATAIRQ = ((SPI_Cfg_t->pbData[7] >> 6) & 0x03);
		g_mode = SPI_Cfg_t->pbData[7] &0x03;
		SSP0_Init(CPOL,CPHA,clockrate);
	}
}

/*
 *Function Name     : Init_Var
 *Description       : Initialize the variables used during transaction
 */
void Init_Var(void)
{
	RID = 0;
	CL_card = false;
	CT_card = false;
	JCOP_crd = false;
	Mastercard = false;
}
/*
 *Function Name     : Write_Data
 *Description       : Sending Commands through SPI
 */
void Write_Data(uint8_t *data_s, uint16_t len_s)
{
	SSP_DATA_SETUP_Type SSPx_M_Send;
	SSPx_M_Send.tx_data	= (uint8_t *)data_s;
	SSPx_M_Send.length	= len_s;
	SSPx_M_Send.rx_data	= NULL;
    SSP_ReadWrite(LPC_SSP0,&SSPx_M_Send,SSP_TRANSFER_POLLING);
}

/*
 *Function Name     : Read_Data
 *Description       : Receiving response through SPI
 */
void Read_Data(uint8_t *data_r, uint16_t len_r)
{
	SSP_DATA_SETUP_Type SSPx_M_Receive;
	SSPx_M_Receive.rx_data	= (uint8_t *)data_r;
	SSPx_M_Receive.length 	= len_r;
	SSPx_M_Receive.tx_data	= NULL;
	SSP_ReadWrite(LPC_SSP0,&SSPx_M_Receive,SSP_TRANSFER_POLLING);
}

/*
 *Function Name     : WaitForGPIOIdle
 *Description       : Wait till state of the GPIO pin becomes low
 */
void WaitForGPIOIdle()
{
	while(Chip_GPIO_GetPinState(LPC_GPIO_0,0,4));
}

/*
 *Function Name     : WaitForGPIOBusy
 *Description       : Wait till state of the GPIO pin becomes high
 */
void WaitForGPIOBusy()
{
	delay(0x01); //delay(0x01) -> 360 us->1.382KHz
    //while(!Chip_GPIO_GetPinState(LPC_GPIO_0,0,4));
}

/*
 *Function Name     : Iterrupt_availaible
 *Description       : Wait for the interrupt from PN7462AU
 */
Bool Iterrupt_availaible(void)
{
	/*Return IRQ pin status. */
	if(GET_IRQ_CMD_PIN)
		return true;
	else
		return false;
}

/*
 *Function Name     : CheckSuccessCode
 *Description       : Check for the success code "90 00" in the response
 */
uint8_t CheckSuccessCode()
{
	if((gRxBuff[ReceivePacketSize-1] != 0x0) || (gRxBuff[ReceivePacketSize-2] != 0x90))
   	{
 	   return 0x00;
   	}
	return 0x01;
}

/*
 *Function Name     : print_command
 *Description       : Print the command sent from host(LPC) to PN7462AU
 */
void print_command(const char *cmd,uint8_t cmd_size,char *cmd_name)
{

	uint8_t i;
	VCOM_putstring(cmd_name);
	VCOM_putchar('\r');
	VCOM_putchar('\n');
	VCOM_putstring(cmnd);
    /*Print all command bytes
     * Command bytes start from 5th byte*/
	for(i=5;i<cmd_size;i++)
	{
		if(i%20 == 0)
		{
			VCOM_putstring(new_line);
		}

		/*Make necessary formatting to print it on PC console*/
        itoa(gTxBuff[i],cmd_str,16);
        if(cmd_str[0] >= 97)
        {
        	cmd_str[0] = cmd_str[0] -32;
        }
        if(cmd_str[1] >= 97)
        {
        	cmd_str[1] = cmd_str[1] -32;
        }
        VCOM_putstring(cmd_str);
        VCOM_putchar(' ');
        VCOM_putchar(' ');
	}

	VCOM_putchar('\r');
	VCOM_putchar('\n');
#ifdef CONSOLE_PRINT
	/*Print the messages on the Debug Console*/
    printf("%s\n",cmd_name);
    printf("[C]  ");

    for(i=5;i<cmd_size;i++)
	{
		if(i%20 == 0)
		{
			printf("\n\t");
		}
        printf("%X  ",gTxBuff[i]);
	}
    printf("\n");
#endif
}

/*
 *Function Name     : print_response
 *Description       : Print the response received by host(LPC) from PN7462AU
 */
void print_response(void)
{
	uint8_t i;
	{
		VCOM_putstring(rsp);
		for(i=0;i<(ReceivePacketSize-2);i++)
		{
			if(i !=0 && i%20 == 0)
			{
				VCOM_putstring(new_line);
			}

			/*Make necessary formatting to print it on PC console*/
			itoa(gRxBuff[i],rsp_str,16);
	        if(rsp_str[0] >= 97)
	        {
	        	rsp_str[0] = rsp_str[0] -32;
	        }
	        if(rsp_str[1] >= 97)
	        {
	        	rsp_str[1] = rsp_str[1] -32;
	        }
			VCOM_putstring(rsp_str);
			VCOM_putchar(' ');
			VCOM_putchar(' ');
		}
		VCOM_putchar('\r');
		VCOM_putchar('\n');
		VCOM_putstring(sw);
		for(i=(ReceivePacketSize-2);i<ReceivePacketSize;i++)
		{
			itoa(gRxBuff[i],rsp_str,16);
	        if(rsp_str[0] >= 97)
	        {
	        	rsp_str[0] = rsp_str[0] -32;
	        }
	        if(rsp_str[1] >= 97)
	        {
	        	rsp_str[1] = rsp_str[1] -32;
	        }
			VCOM_putstring(rsp_str);
			VCOM_putchar(' ');
			VCOM_putchar(' ');
		}
		VCOM_putchar('\r');
		VCOM_putchar('\n');
		VCOM_putchar('\r');
		VCOM_putchar('\n');
#ifdef CONSOLE_PRINT
	/*Print the messages on the Debug Console*/
    printf("[R]  ");

	for(i=0;i<(ReceivePacketSize-2);i++)
	{
		if(i !=0 && i%20 == 0)
		{
			printf("\n\t");
		}
        printf("%X  ",gRxBuff[i]);
	}
    printf("\n[SW]  ");
	for(i=(ReceivePacketSize-2);i<ReceivePacketSize;i++)
	{
        printf("%X  ",gRxBuff[i]);
	}
    printf("\n\n");
#endif
	}
}

/*
 *Function Name     : print_trans_incomp
 *Description       : Print the error message if the transaction is incomplete
 */
void print_trans_incomp(void)
{
	if (CL_card)
	{
		/*Check whether failure code indicates, "file is not found"*/
		if((gRxBuff[ReceivePacketSize-1] == 0x82) || (gRxBuff[ReceivePacketSize-2] == 0x6A))
		{
			VCOM_putstring(No_file);
		}
		/*Check whether failure code indicates, "record is not found"*/
		else if((gRxBuff[ReceivePacketSize-1] == 0x83) || (gRxBuff[ReceivePacketSize-2] == 0x6A))
		{
			VCOM_putstring(No_record);
		}
		/*In case of any other failure code, indicate the incompletion of Transaction and deactivate the card\
		 * Go to the beginning of the application*/
		else
		{
			VCOM_putstring(CL_trans_incmp);
			DeActivate_Card();
			PosApp();
		}

	}
	else if (CT_card)
	{
		/*Check whether failure code indicates, "file is not found"*/
		if((gRxBuff[ReceivePacketSize-1] == 0x82) || (gRxBuff[ReceivePacketSize-2] == 0x6A))
		{
			VCOM_putstring(No_file);
		}
		/*Check whether failure code indicates, "record is not found"*/
		else if((gRxBuff[ReceivePacketSize-1] == 0x83) || (gRxBuff[ReceivePacketSize-2] == 0x6A))
		{
			VCOM_putstring(No_record);
		}
		/*In case of any other failure code, indicate the incompletion of Transaction and deactivate the card
		 * Go to the beginning of the application*/
		else
		{
			VCOM_putstring(CT_trans_incmp);
			DeActivate_Card();
			PosApp();
		}
	}
	else
	{
		VCOM_putstring(err);
		VCOM_putstring(dots);
		PosApp();
	}

}

/*
 *Function Name     : DeActivate_Card
 *Description       : Deactivate the card
 */
void DeActivate_Card()
{
	SendCmd(aDeActCardCmd,sizeof(aDeActCardCmd),DeActCard);

	SendCmd(aGetStatusCmd,sizeof(aGetStatusCmd),GetStatus);
	/*If card is still present, wait till it is removed*/
	if ((gRxBuff[PH_EXPOS_COMMON_EVENT_BYTE] == E_CARD_REMOVAL_EVENT))
	{
        VCOM_putstring(crd_removed);
	}
	else
	{
		VCOM_putstring(remove_crd);
		while(!Iterrupt_availaible());
	    SendCmd(aGetStatusCmd,sizeof(aGetStatusCmd),GetStatus);
	    if (gRxBuff[PH_EXPOS_COMMON_EVENT_BYTE] == E_CARD_REMOVAL_EVENT)
	    {
	        VCOM_putstring(crd_removed);
	    }
	}
	VCOM_putstring(dots);
}

/*
 *Function Name     : SendCmd
 *Description       : Command will be sent and it will be displayed along with the response received
 */
void SendCmd(const char *cmd,uint8_t cmd_size,char *cmd_name)
{
	//delay(0x01);
	/*Copy the command to TxBuffer*/
	memcpy((void*)&gTxBuff,(const void*)cmd,cmd_size);

	print_command(cmd,cmd_size,cmd_name);


	/*Wait till the PN7462AU is ready to receive the command from the host(LPC)*/
	WaitForGPIOIdle();

	/**************** Host sends the command to PN7462AU ****************/
	/*CS line low - before the Transfer started*/
	Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,0);
	/*Send the command copied into the TxBuffer*/
	Write_Data(&gTxBuff[0],cmd_size);
	/*CS line high - Transfer completed*/
	Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,1);

	/*Wait till all command bytes are received by PN7462AU through SPI*/
	WaitForGPIOBusy();

	/*Wait till the PN7462AU is ready to send the response to the host(LPC)*/
	WaitForGPIOIdle();

	/**************** Host receives the response from PN7462AU ****************/
	/*CS line low - before the Transfer started*/
	Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,0);
	/*Read the length of the response to be received*/
	Read_Data(&gRxBuff[0],LengthPacketSize);
	ReceivePacketSize = ((gRxBuff[1]) | (gRxBuff[2]<<8) );
	/*Read the response*/
	Read_Data(&gRxBuff[0],ReceivePacketSize);
	/*CS line high - Transfer completed*/
	Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,1);

	print_response();


	/*Check for the success code "90 00" in the response*/
	if(0x00 == CheckSuccessCode())
	{
		VCOM_putstring(Err_rsp);
		/*In case of any error, go back to the polling*/
		PosApp();
	}
}

/*
 *Function Name     : SendApduCmd
 *Description       : Command will be sent and response will be received. Both command and response will be printed or stored in the buffer to print it at once at the end.
 */
void SendApduCmd(const char *cmd,uint8_t cmd_size,char *cmd_name)
{
	/*Copy the command to TxBuffer*/
	memcpy((void*)&gTxBuff,(const void*)cmd,cmd_size);

    print_command(cmd,cmd_size,cmd_name);
	/*Wait till the PN7462AU is ready to receive the command from the host(LPC)*/
	WaitForGPIOIdle();

	/**************** Host sends the command to PN7462AU ****************/
	/*CS line low - before the Transfer started*/
	Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,0);
	Write_Data(&gTxBuff[0],cmd_size);
	/*CS line high - Transfer completed*/
	Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,1);

	/*Wait till all command bytes are received by PN7462AU through SPI*/
	WaitForGPIOBusy();

	/*Wait till the PN7462AU is ready to send the response to the host(LPC)*/
	WaitForGPIOIdle();

	/**************** Host receives the response from PN7462AU ****************/
	/*CS line low - before the Transfer started*/
	Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,0);
	/*Read the length of the response to be received*/
	Read_Data(&gRxBuff[0],LengthPacketSize);
	ReceivePacketSize = ((gRxBuff[1]) | (gRxBuff[2]<<8) );
	/*Read the response*/
	Read_Data(&gRxBuff[0],ReceivePacketSize);
	/*CS line high - Transfer completed*/
	Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,1);

	print_response();

	/*Check for the success code "90 00" in the response*/
	if(0x00 == CheckSuccessCode())
	{
		print_trans_incomp();
	}

}
/*******************************************************************************************
 * END OF FILE
 *******************************************************************************************/
