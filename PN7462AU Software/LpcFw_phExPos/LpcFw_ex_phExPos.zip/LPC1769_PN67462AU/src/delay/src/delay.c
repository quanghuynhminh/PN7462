/*
 *                  Copyright (c), NXP Semiconductors
 *
 *                     (C)NXP Semiconductors
 *       All rights are reserved. Reproduction in whole or in part is
 *      prohibited without the written consent of the copyright owner.
 *  NXP reserves the right to make changes without notice at any time.
 * NXP makes no warranty, expressed, implied or statutory, including but
 * not limited to any implied warranty of merchantability or fitness for any
 *particular purpose, or that the use will not infringe any third party patent,
 * copyright or trademark. NXP must not be liable for any loss or damage
 *                          arising from its use.
 */

/** \file
 * delay.c
 * $Author: nxp47613 $
 * $Revision: 001 $
 * $Date: 2013-07-26 10:28:17 +0530 (Fri, 26 Jul 2013) $
 *
 * History:
 *
 */

#include "stdint.h"
#include "delay.h"
#include "LPC17xx.h"
#include "DUT.h"
/*
 *Function Name     : delay_1
 *Description       :Provides a delay on 1ms
 *
 *Input Parameters  :delay in ms
 *Output Parameters :
 *
 *Note:             :
 */
int delay_1(uint32_t count)
{
	LPC_TIM0->TCR = 0x02;                /* reset timer */
	LPC_TIM0->PR  = 0x00;                /* set prescaler to zero */
	LPC_TIM0->MR0 = count * (9000000 / 1000-1);
	LPC_TIM0->IR  = 0xff;                /* reset all interrrupts */
	LPC_TIM0->MCR = 0x04;                /* stop timer on match */
	LPC_TIM0->TCR = 0x01;                /* start timer */

	/* wait until delay time has elapsed */
	//while (LPC_TIM0->TCR & 0x01);

	while (LPC_TIM0->TCR & 0x01)
	{
		if(GET_IRQ_CMD_PIN)
		{
			LPC_TIM0->TCR = 0x02;
			return 1;
		}
	}
	return 0;
}

/*
 *Function Name     : delay
 *Description       :Provides a delay on 1ms
 *
 *Input Parameters  :delay in ms
 *Output Parameters :
 *
 *Note:             :
 */
void delay(uint32_t count)
{
	if(count == 0)
	{
		return;
	}

	LPC_TIM0->TCR = 0x02;                /* reset timer */
	LPC_TIM0->PR  = 0x00;                /* set prescaler to zero */
	LPC_TIM0->MR0 = (count * (9000000 / 1000-1))/2;
	LPC_TIM0->IR  = 0xff;                /* reset all interrrupts */
	LPC_TIM0->MCR = 0x04;                /* stop timer on match */
	LPC_TIM0->TCR = 0x01;                /* start timer */

	/* wait until delay time has elapsed */
	while (LPC_TIM0->TCR & 0x01);

}
