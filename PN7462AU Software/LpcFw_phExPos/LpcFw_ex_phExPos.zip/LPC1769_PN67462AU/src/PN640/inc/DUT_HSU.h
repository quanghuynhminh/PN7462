/*
 * DUT_HSU.h
 *
 *  Created on: May 1, 2014
 *      Author: NXP74831
 */

#ifndef DUT_HSU_H_
#define DUT_HSU_H_

#include "LPC17xx.h"
#include "DUT.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_uart.h"
#include "dut_status.h"
#include "lpc17xx_libcfg_default.h"

#define UART_RING_BUFSIZE 1024

#define rx	SlaveRxBuffer
#define tx	SlaveTxBuffer
/**
 * @brief	API interface IDs
 *
 */
typedef enum{
	UART0 = 0x00,
	UART1,
	UART2,
	UART3,
}UART_ID_T;

/** @brief UART Ring buffer structure */
typedef struct
{
    //__IO uint32_t tx_head;                /*!< UART Tx ring buffer head index */
    //__IO uint32_t tx_tail;                /*!< UART Tx ring buffer tail index */
    __IO uint32_t rx_head;                /*!< UART Rx ring buffer head index */
    __IO uint32_t rx_tail;                /*!< UART Rx ring buffer tail index */
    //__IO uint8_t  tx[UART_RING_BUFSIZE];  /*!< UART Tx data ring buffer */
    __IO uint8_t  rx[UART_RING_BUFSIZE];  /*!< UART Rx data ring buffer */
} UART_RING_BUFFER_T;

// UART Ring buffer
UART_RING_BUFFER_T rb;
/*Function prototypes*/
void DUT_HSU_Operation(DUT_CmdFrame_t *);

//void UART0_Config(DUT_CmdFrame_t *);

void UART1_Config(DUT_CmdFrame_t *);

int HSU_Send(LPC_UART_TypeDef *, DUT_CmdFrame_t *);

void HSU_Receive(LPC_UART_TypeDef *, DUT_CmdFrame_t *);

int fmtm_HSU_Send(LPC_UART_TypeDef *, DUT_CmdFrame_t *);
#endif /* DUT_HSU_H_ */
