/*
 * dut_status.h
 *
 *  Created on: Jan 2, 2014
 *      Author: nxp69678
 */

#ifndef DUT_STATUS_H_
#define DUT_STATUS_H_


/*********************************************************************************************************************/
/*   GLOBAL DEFINES                                                                                                  */
/*********************************************************************************************************************/
/** \name Status error check macros
 * @{
 */
/**
 * Macro which checks a given status against #PH_STATUS_SUCCESS. If the status is not equal to #PH_STATUS_SUCCESS then
 * the current function is left with the given status code as return value.
 */
#define DUT_STATUS_CHECK_SUCCESS(status)         do {if ((status) != DUT_STATUS_SUCCESS) {return (status);}} while (0)
/**
 * Macro which executes a function and checks the return value against #PH_STATUS_SUCCESS. If the calling function does not
 * return #PH_STATUS_SUCCESS then the caller is also left with the callee's status code as return value.
 */
#define DUT_STATUS_CHECK_SUCCESS_FCT(status,fct) do {(status) = (fct); DUT_STATUS_CHECK_SUCCESS(status);} while (0)



typedef enum{

      DUT_STATUS_SUCCESS                          = 0x0000, /**< Value to be returned in case of success. */
      /* GENERIC *******************/
      DUT_STATUS_UNKNOWN_ERROR                    = 0x00FF, /**< Value to be returned when the error cannot be determined */
      DUT_STATUS_MEMORY_ERROR                     = 0x0001, /**< Value to be returned in case of a memory error. */
      DUT_STATUS_INTERNAL_ERROR                   = 0x0002, /**< Value to be returned in case of an internal error or
                                                              an error which is not specified in more detail. */
      DUT_STATUS_TIMEOUT_ERROR                    = 0x0003, /**< Value to be returned in case of a timeout. */
      DUT_STATUS_TEST_FAILED                      = 0x0004, /**< A test case failed. */
      DUT_STATUS_CRC_ERROR                        = 0x0005, /**< CRC check failed. */
      DUT_STATUS_VERIFICATION_ERROR               = 0x0006, /**< Verification failed. */
      DUT_STATUS_NOT_FOUND_ERROR                  = 0x0007, /**< Requested resource not found. */
      DUT_STATUS_BUSY                             = 0x0008, /**< Device or resource busy. */
      DUT_STATUS_PARAMETER_ERROR                  = 0x0009, /**< Unsupported parameter passed in. */
      DUT_STATUS_HW_IS_OFF                        = 0x000A, /**< Hardware currently does not support the feature (see PCR) */
      DUT_STATUS_UNKNOWN_CMD                      = 0x000B, /**< This command frame is not supported */
      DUT_STATUS_ABORTED_CMD                      = 0x000C, /**< Command not executed due to breaking with a non matching command
                                                              id a multi phase command */
      DUT_STATUS_I2C_NOT_CONFIG                   = 0x001E, /**< None of the HIF in LPC is configured */
      DUT_STATUS_GPIO_NOT_CONFIG                  = 0x001F, /**< None of the HIF in LPC is configured */
      DUT_STATUS_SPI_NOT_CONFIG                   = 0x0010, /**< None of the HIF in LPC is configured */
      DUT_STATUS_HSU_NOT_CONFIG                   = 0x0010, /**< None of the HIF in LPC is configured */

      PH_ERR_IO_TIMEOUT                           = 0x0001U, /**< No reply received, e.g. Pn640 does not respond within the Time. */
      PH_ERR_FRAMING_ERROR                        = 0x0005U, /**< Invalid frame format. */
      PH_ERR_PROTOCOL_ERROR                       = 0x0006U, /**< Received response violates protocol. */
      PH_ERR_LENGTH_ERROR                         = 0x000CU, /**< A length error occurred. */
      PH_ERR_INTERNAL_ERROR                       = 0x007FU, /**< An internal error occurred. */
      PH_ERR_INVALID_PARAMETER                    = 0x0021U, /**< Invalid parameter supplied. */
      PH_ERR_PARAMETER_OVERFLOW                   = 0x0022U, /**< Reading/Writing a parameter would produce an overflow. */
      PH_ERR_UNSUPPORTED_PARAMETER                = 0x0023U, /**< Parameter not supported. */
      PH_ERR_UNSUPPORTED_COMMAND                  = 0x0024U, /**< Command not supported. */
      PH_ERR_USE_CONDITION                        = 0x0025U, /**< Condition of use not satisfied. */
      PH_ERR_DATA_UNAVAILABLE_OVER_HSU			  = 0x0026U, /**< No data received over the HSU */
      PH_ERR_DATA_UNAVAILABLE			  		  = 0x0026U, /**< No data received over the HSU */
      PH_ERR_CTS_UNAVAILABLE					  = 0x0027U, /**< CTS is not set the HSU */
      PH_ERR_TX_NAK_ERROR						  = 0x000EU, /**< The counterpart sanely rejected the TX from HOST. */
      PH_ERR_RX_NAK_ERROR             			  = 0x000FU, /**< The counterpart sanely rejected the RX from HOST. */
      /*****************************/

} dutStatus_t;


#endif /* STATUS_H_ */
