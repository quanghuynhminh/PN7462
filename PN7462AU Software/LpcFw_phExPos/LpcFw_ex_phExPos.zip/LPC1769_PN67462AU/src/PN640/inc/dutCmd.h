/*
 * dutCmd.h
 *
 *  Created on: Jan 2, 2014
 *      Author: nxp69678
 */

#ifndef DUTCMD_H_
#define DUTCMD_H_

#include "dut_status.h"
#include "DUT.h"
#include "DUT_I2C.h"
#include "gpio_17xx_40xx.h"
#include "delay.h"
#include "DUT_HSU.h"
#include "DUT_SPI.h"

#define CONFIG_CMD_LENGTH                  13    /*Configuration Frame command length is 13 bytes*/
#define CONFIG_CMD                         ((uint8_t)0xA0) /*Configuration Frame 1st byte contains 0xA0*/
#define CONFIG_CMD_PAYLOAD_LENGTH          9      /*configuration command payload length is fixed and is 9 bytes*/

/* I2C mode of operations*/
#define I2C_STD_MODE_FREQ 				100000  /*Standard-mode (Sm) 100 kbit/s. */
#define I2C_FAST_MODE_FREQ	 			400000  /*Fast-mode (Fm) 400 kbit/s. */
#define I2C_FAST_MODE_PLUS_FREQ	 		1000000 /*1 MHz Fast Mode Plus. */
#define I2C_HIGH_SPEED_MODE_FREQ	 	3400000 /*High-speed mode (Hs-mode) 3.4Mbit/s      */

/*I2C modes of operation*/
typedef enum
{
	I2C_STANDARD_MODE = 0x0,
	I2C_FAST_MODE,
	I2C_FAST_MODE_PLUS,
	I2C_HIGH_SPEED_MODE
}dutI2CS_Modes_t;

/*frame contents*/
typedef enum
{
	FRAME_TYPE_POS = 0x0,   /*1 byte */
	COMMAND_POS,			/*1 byte */
	LENGTH_POS,				/*2 bytes */
	PAYLOAD_POS = 0x4,
	DATA_RATE_POS = 0x4,
	MODE_POS = 0x8,
	SLAVE_ADDRESS_POS,
	TIME_OUT_POS = 0xB
}dutCmdFrameContents_t;


/*DUT interfaces*/
typedef enum
{
	DUT_GPIO = 0x00,
    DUT_I2C ,
    DUT_SPI,
    DUT_HSU,
}dutInterfaces_t;

/*DUT Operations for I2C, SPI and HSU*/
typedef enum
{
	DUT_CONFIG = 0x00,
	DUT_Tx,
	DUT_Rx ,
    DUT_TxRx,
}dutoperations_t;

/*GPIO Set or Get value*/
typedef enum
{
	GPIO_Get_Value = 0x01,
	GPIO_Set_Value,
	GPIO_Toggle,
}GPIO;

/*Ports available*/
typedef enum
{
	Port0=0x000,
	Port1,
	Port2,
	Port3,
	Port4,
}GPIO_Port_t;


/*Types of Pulse*/
typedef enum
{
	Short_Pulse = 0x00,
	Short_Inverted_Pulse,
	Long_Pulse,
	Long_Inverted_Pulse,

}GPIO_Pulse_t;

/*DUT Master or Slave*/
typedef enum
{
	SLAVE = 0x00,
	MASTER,
}dutMasterSlave_t;

/*Communication command type*/
typedef enum
{
	LOOP_BACK
}dutCommCmdTypes_t;


dutStatus_t dutparseConfigurationComand(DUT_CmdFrame_t *);

void Transparent_exchange_I2C(DUT_CmdFrame_t *);
void LPC_GPIO_Operations(DUT_CmdFrame_t *);
void GPIO_SetPinDIR(LPC_GPIO_T *, uint8_t, uint8_t , bool, bool);
void GPIO_Config(DUT_CmdFrame_t *);
dutStatus_t GPIO_Get_Val(DUT_CmdFrame_t *);
void GPIO_Short_Pulse(uint8_t , uint8_t , uint16_t , BOOL_8 , BOOL_8, BOOL_8  );
void GPIO_Long_Pulse(uint8_t , uint8_t , uint16_t , BOOL_8 , BOOL_8, BOOL_8    );



void GPIO_Toggle_pin(DUT_CmdFrame_t *);
void DUT_Response_to_PC(uint8_t *, uint16_t);
void LPC_Response_to_PC(DUT_CmdFrame_t *, uint16_t );
#endif /* DUTCMD_H_ */
