/*
 * DUT_I2C.h
 *
 *  Created on:Mar 27, 2014
 *      Author: nxp74831
 */

#ifndef DUT_I2C_H_
#define DUT_I2C_H_

#include "LPC17xx.h"
#include "DUT.h"
#include "lpc17xx_i2c.h"
#include "lpc17xx_pinsel.h"
#include "dut_status.h"



#define KHZ 1000	/*Frequency in KHZ*/
//#define SLAVE_ADDR 0x0A//(0x28UL) /**<Slave address to which data is to be sent in I2C*/


/*Global variables used for master, slave and Slave addr used*/
uint8_t gCurr_Master;
uint8_t gCurr_Slave;
uint8_t gslave_addr;
uint16_t g_wTimeOut;
uint8_t g_wait_DATAIRQ;
commModes_t g_mode;
commModes_t g_mode_s;


/*Structure to setup the slave interface which is in Interrupt mode*/
volatile I2C_S_SETUP_Type I2C_SlaveCfg;


void LPC_I2C_Init(LPC_I2C_TypeDef *, uint8_t , uint8_t, uint8_t , uint8_t, uint32_t);
void DUT_I2Cx_Init(DUT_CmdFrame_t *);

/*Master Data transfer*/
Status DUT_I2Cx_M_Receive(LPC_I2C_TypeDef *, uint8_t *buff, uint16_t len, uint8_t slaveAddr, commModes_t mode);
Status DUT_I2Cx_M_Send(LPC_I2C_TypeDef *, const uint8_t *buff, uint16_t len, uint8_t slaveAddr);
Status LPC_I2C_M_Tx(LPC_I2C_TypeDef *, DUT_CmdFrame_t *);
void LPC_I2C_M_Rx(LPC_I2C_TypeDef *, DUT_CmdFrame_t *);

/*Slave data transfer*/
Status LPC_I2Cx_S_Config(LPC_I2C_TypeDef *);

void fmtm_i2c(LPC_I2C_TypeDef * , DUT_CmdFrame_t *, uint8_t );


void I2C_Loopback(void);
dutStatus_t DUT_I2Cx_operation(DUT_CmdFrame_t *);

#endif
