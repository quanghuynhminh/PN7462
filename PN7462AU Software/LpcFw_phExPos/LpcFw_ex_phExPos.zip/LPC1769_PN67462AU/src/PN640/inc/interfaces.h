/*
 * interfaces.h
 *
 *  Created on: Jan 3, 2014
 *      Author: nxp69678
 */

#ifndef INTERFACES_H_
#define INTERFACES_H_

#include "lpc_types.h"
#include "dutCmd.h"


typedef enum
{
GPIO_0,
GPIO_1,
GPIO_2,
GPIO_3,
GPIO_4,
GPIO_5,
GPIO_6,
GPIO_7,
Download_Pin,
Reset_Pin,
IRQ_Line
}GPIO_Pins_t;

typedef enum
{
	INPUT,
	OUTPUT,
}GPIO_Modes_t;

/*******************************************************
 * I2C Master
 ******************************************************/
typedef struct
{
	uint8_t				bId;
	FunctionalState 	eState;
	uint32_t 			dwDataRate;
	commModes_t 		bMode;
	dutCommCmdTypes_t	sCmdType;
	uint8_t 			bSlaveAddress;
	uint16_t 			wTimeoutms;
	uint8_t				*bTxBuffer;
	uint16_t			wTxLength;
	uint8_t				*bRxBuffer;
	uint16_t			wRxLength;
}i2cMaster_t;

/*******************************************************
 * I2C Slave
 ******************************************************/
typedef struct
{
	uint8_t				bId;
	FunctionalState		eState;
	uint32_t 			dwDataRate;
	commModes_t 		bMode;
	dutCommCmdTypes_t	sCmdType;
	uint8_t 			bMyAddress;
	uint16_t 			wTimeoutms;
	uint8_t				*bTxBuffer;
	uint16_t			wTxLength;
	uint8_t				*bRxBuffer;
	uint16_t			wRxLength;
}i2cSlave_t;

/*******************************************************
 * SPI Master
 ******************************************************/
typedef struct
{
	uint8_t				bId;
	FunctionalState 	eState;
	uint16_t 			wTimeoutms;
	uint8_t				*bTxBuffer;
	uint16_t			wTxLength;
	uint8_t				*bRxBuffer;
	uint16_t			wRxLength;
}spiMaster_t;

/*******************************************************
 * SPI Slave
 ******************************************************/
typedef struct
{
	uint8_t				bId;
	FunctionalState 	eState;
	uint16_t 			wTimeoutms;
	uint8_t				*bTxBuffer;
	uint16_t			wTxLength;
	uint8_t				*bRxBuffer;
	uint16_t			wRxLength;
}spiSlave_t;

/******************************************************
 * Active LPC1769 Interfaces for testing DUT
 ******************************************************/
typedef struct
{
	i2cMaster_t 	*psI2C0Master;		/*Configure LPC1769 I2C0 as Master to test I2C slave of DUT*/
	i2cSlave_t 		*psI2C1Slave;		/*Configure LPC1769 I2C1 as Slave to test I2C Master of DUT*/
	spiMaster_t 	*psSSP1Master;		/*Configure LPC1769 SSP1 as Master to test SPI slave of DUT*/
	spiSlave_t 		*psSSP0Slave;		/*Configure LPC1769 SSP0 as Slave to test SSP Master of DUT*/
}LPCInterfaces_t;

#endif /* INTERFACES_H_ */
