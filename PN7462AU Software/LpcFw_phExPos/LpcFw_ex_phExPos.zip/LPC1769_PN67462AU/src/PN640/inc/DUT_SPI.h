/*
 * DUT_SPI.h
 *
 *  Created on: Apr 28, 2014
 *      Author: NXP74831
 */

#ifndef DUT_SPI_H_
#define DUT_SPI_H_

#include "LPC17xx.h"
#include "DUT.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_ssp.h"
#include "dut_status.h"

/*Defines for the pin numbers*/
/*SSP0 master interface for PN640*/
#define SSP_PORT	0
/*SSP0 master of LPC1769 interface for PN640*/
#define SSP_MISO0	17
#define SSP_MOSI0	18
#define SSP_SCLK0	15
#define SSP_SSEL0	16

/*SSP1 slave of LPC1769 interface for PN640*/
#define SSP_MISO1	9
#define SSP_MOSI1	8
#define SSP_SCLK1	7
#define SSP_SSEL1	6

/*Global variables used for master, slave and Slave addr used*/
uint8_t gCurr_Master;
uint8_t gCurr_Slave;
uint8_t gslave_addr;
uint16_t g_wTimeOut;
uint8_t g_wait_DATAIRQ;
commModes_t g_mode;
commModes_t g_mode_s;

volatile SSP_DATA_SETUP_Type SSP_slave_cfg_t;
/**
 * @brief	API interface IDs
 *
 */
typedef enum{
	SSP0 = 0x00,
	SSP1,
}SSP_ID_T;


/*Function Prototypes*/
void SSP0_Init(uint8_t SSP_CPOL, uint8_t SSP_CPHA, uint32_t clockrate);
void SSP1_Init(uint8_t SSP_CPOL, uint8_t SSP_CPHA, uint32_t clockrate);
void SSPx_Config(DUT_CmdFrame_t*);
void DUT_SSPx_Operation(DUT_CmdFrame_t *);

Status SSPx_Send(LPC_SSP_TypeDef *, DUT_CmdFrame_t *);

void SPPx_Receive(LPC_SSP_TypeDef *, DUT_CmdFrame_t *);

void SPI_Slave_Config(LPC_SSP_TypeDef *);

Status fmtm_SPI_Send(LPC_SSP_TypeDef * , DUT_CmdFrame_t * );

void fmtm_SPI_Receive(LPC_SSP_TypeDef * , DUT_CmdFrame_t *);

#endif
