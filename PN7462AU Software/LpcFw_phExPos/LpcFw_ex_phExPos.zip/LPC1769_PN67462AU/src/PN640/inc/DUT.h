/*
 * DUT.h
 *
 *  Created on: Apr 4, 2014
 *      Author: nxp74831
 */

#ifndef PN640_H_
#define PN640_H_

#include "LPC17xx.h"
#include "lpc_types.h"
#include "lpc17xx_i2c.h"

#define PN640_LPC_FW_MAJ         (2)
#define PN640_LPC_FW_MIN         (0)
#define PN640_LPC_FW_DEV         (16)

/* Version information, Descending
 * 	0002.00.16  ==> 1)Changed the clock setting for the SPI master. Made the prescalar value to 2.[PT_SC1637]
 * 					2)Reduced the complexity of the SPI Slave(i.e SSP1) Interrupt handler to ensure that all data is
 * 						received without any buffer overflow.[PT_SC1606] , [PT_SC1609]
 * 					3) changed the Optimization level to -O1
 *  0002.00.15  ==> 1) Added the functionality for the HSU full duplex in HSU TxRx case.The condition is to hold the RTS pin High before calling the
 *  					HSU TxRx from C# test bench.The HSU TxRx will pull the RTS Line low in this case.
 *  0002.00.14  ==> 1) Made a fix in return status of the TRx function of I2C.
 *  0002.00.13  ==> 1) Changed the lower level I2C drivers to issue a general call everytime after start.
 *	0002.00.12  ==> 1)Made the Maximum size of the SPI Rx and Tx to 1028 bytes. 1024(bytes) paylod+ 4(bytes)payloadlen.
 *						 Implemented as a fix for the PR PT_SC1530.
 *					2) Added a API to generate the PN640 Softreset sequence in the file lpc17xx_i2c.c. Also added new Case TX_SOFT_RESET in DUT.c.
 *					3) Made changes to the ERROR codes. Changed GENERIC_INTERNAL_ERROR to PH_ERR_TX_NAK_ERROR and PH_ERR_RX_NAK_ERROR.
 * 	0002.00.11  ==>	1)Increased the clock of the SSP1 to 100Mhz since the user manual in LPC expects the slave frequency needs to
 * 						be 12 times the frequency of transmission from master.
 * 	0002.00.10  ==>	1) Added a feature to get the DEVICE ID from PN640 by generating the appropriate signals over the I2C.
 * 					2) Also added the support for the soft reset of Pn640.
 *
 * 	0002.00.09	==> 1) Made changes in the delay function to ensure that the delay is not infinite when the count parameter is Zero.
 *  0002.00.08	==> 1) Fixes [PT_SC1500]
 *                     Changed the HDLL Mode receive for the SPI. First byte that is sent is 0xFF for receive which is a
 *  				direction indicator for SPI and then the data is received.(File changed DUT_SPI.c).
 *  				2)Changed the method to set the UART1 BaudRate registers for higher data rates.(File changed DUT_HSU.c,
 *  				 lpc17xx_uart.h and lpc17xx_uart.c )
 *
 *  0002.00.07	==> 1)Removed the I2C data rate value check.
 *  0002.00.06	==> 1)Removed the Delay during reset as it is handled by the C# testbench
 *
 *  0002.00.05	==> 1) Increased the clock speed provided to SSP peripheral.
 *					2) Added check to the I2C Baudrates since the supported baud rates is 100Khz and 400Khz
 *
 *	0002.00.04	==> 1) Made a change in the response for the FMTM NON_BLOCKING call.
 *					2) Added native mode to I2C2 slave Transmit
 *					3) Changed the interrupt handler of SPI slave
 *					4) Added native mode to SPI1 slave Transmit
 *	0002.00.03	==> 1)Fixed the SPI Slave select issue in which the SSEL now toggles after the entire data is transmitted
 *					2)Added response to reset.
 *					3)LPC I2C TxRx changed the way the data is transmitted and received.
 *					4) Added a global variable for the slave to store the receiving mode.
 *	0002.00.02	==> Fixed the bug in the I2C receive when mode is "Other"
 *	0002.00.01	==>	Changed the version number in comments due to wrong version number specified in previous version.
 *	0002.00.00	==> 1)Implementation to get the Device ID and SoftReset for Pn640
 *					2)FMTM support is provided in the framework to transfer frames with starting byte other that 0x30
 *					3)Made changes in lower driver of I2C to remove disabling of interrupt after each transaction.
 *					4)HSU made changes related to Initialization of pins in LPC1769.
 *					5)Deleted unsed files SPIMmain and SPISmain.c
 *
 *  0001.01.05  ==> I2C Slave supporting the HDLL and NATIVE mode.
 *  0001.01.04  ==> Made CTS(P0-17) and RTS(P2-7) as ACTIVE LOW Pins.
 *	0001.01.03	==> Changed the UART used to UART1 from UART0.Support for CTS(P0-17) and RTS(P2-7) also available
 *	0001.01.02  ==> Configured the SSPx pin mode as Open drain and Pins state to TRISTATE .
 *
 *	0001.01.01  ==> Added the error condition when none of the Hif is configured.
 *					Added support for SPI. Made changes in the GPIO.
 *
 *  0001.01.00  ==> Major Fix: Made changes to the way the USBVCOM fills up the txfifo. During the filling of Tx fifo
 *  				the USB interrupts are disabled to avoid the Host reading data in different sized chunks from the Device.
 *  				changes are made in the file USBVCOM.c
 *  				Implementation: Added partial implementation of SPI slave
 *
 *  0001.00.06  ==> Implemented the HSU TxRx.
 *	 	 	 	 	 Added a timeout value during HSU Rx.
 *  0001.00.01  ==> Initial release
 *
 */

#define PN640_LPC_VERSION_STRING "$Id: DUT.h 5796 2014-07-21 11:04:47Z NXP74831 $"

/* PN640 specific pin assignments */
#define DWLD_REQ_PIN	 21     // P0.21 DWL Request pin
#define RST_PIN          5      // P2.5 Reset pin
#define DATA_IRQ_CMD_PIN 11     //P2.11 RX_CMD Pin (IRQ Pin on FPGA Board)


#define USB_CONNECT_PIN  9      //P2.9
#define USB_D_P          29     //P0.29 USB_D+
#define USB_D_N          30     //P0.30 USB_D-

/********************************************
 * PN640 Interfaces settings
 *******************************************/
#define DUT_HIF_SPIS_MAX_DATA_RATE ((uint32_t)7000000)


/********************************************
 * Port 0 Configurations
 *******************************************/
#define SET_DWLD_PIN_OUTPUT        (LPC_GPIO0->FIODIR |= (1 << DWLD_REQ_PIN))
#define SET_DWLD_PIN               (LPC_GPIO0->FIOSET |= (1 << DWLD_REQ_PIN))
#define CLEAR_DWLD_PIN             (LPC_GPIO0->FIOCLR |= (1 << DWLD_REQ_PIN))

#define SET_GPI0_10_PIN_OUTPUT     (LPC_GPIO0->FIODIR |= (1 << 10))
#define SET_GPI0_10_PIN            (LPC_GPIO0->FIOSET |= (1 << 10))
#define CLEAR_GPI0_10_PIN          (LPC_GPIO0->FIOCLR |= (1 << 10))

#define SET_GPI0_11_PIN_OUTPUT     (LPC_GPIO0->FIODIR |= (1 << 11))
#define SET_GPI0_11_PIN            (LPC_GPIO0->FIOSET |= (1 << 11))
#define CLEAR_GPI0_11_PIN          (LPC_GPIO0->FIOCLR |= (1 << 11))

#define SET_GPI0_23_PIN_OUTPUT     (LPC_GPIO0->FIODIR |= (1 << GPI0_23))
#define SET_GPI0_23_PIN            (LPC_GPIO0->FIOSET |= (1 << GPI0_23))
#define CLEAR_GPI0_23_PIN          (LPC_GPIO0->FIOCLR |= (1 << GPI0_23))

#define SET_USB_D_P_PIN_INPUT      (LPC_GPIO0->FIODIR &= ~(1 << USB_D_P))
#define SET_USB_D_N_PIN_INPUT      (LPC_GPIO0->FIODIR &= ~(1 << USB_D_N))

/********************************************
 * Port 1 Configurations
 *******************************************/
#define SET_TXPWR_OUTPUT           (LPC_GPIO1->FIODIR |= (1 << 31))
#define SET_TXPWR_PIN              (LPC_GPIO1->FIOSET |= (1 << 31))
#define CLEAR_TXPWR_PIN            (LPC_GPIO1->FIOCLR |= (1 << 31))

#define ADR0_PIN                   16
#define SET_ADR0_PIN_OUTPUT        (LPC_GPIO0->FIODIR |= (1 << ADR0_PIN))
#define SET_ADR0_PIN               (LPC_GPIO0->FIOSET |= (1 << ADR0_PIN))
#define CLEAR_ADR0_PIN             (LPC_GPIO0->FIOCLR |= (1 << ADR0_PIN))

#define ADR1_PIN                   18
#define SET_ADR1_PIN_OUTPUT        (LPC_GPIO0->FIODIR |= (1 << ADR1_PIN))
#define SET_ADR1_PIN               (LPC_GPIO0->FIOSET |= (1 << ADR1_PIN))
#define CLEAR_ADR1_PIN             (LPC_GPIO0->FIOCLR |= (1 << ADR1_PIN))

/********************************************
 * Port 2 Configurations
 *******************************************/

#define SET_RST_PIN_OUTPUT         (LPC_GPIO2->FIODIR |= (1 << RST_PIN))
#define SET_RST_PIN                (LPC_GPIO2->FIOSET |= (1 << RST_PIN))
#define CLEAR_RST_PIN              (LPC_GPIO2->FIOCLR |= (1 << RST_PIN))

#define SET_IRQ_CMD_PIN_OUTPUT     (LPC_GPIO2->FIODIR |= (1 << DATA_IRQ_CMD_PIN))
#define SET_IRQ_CMD_PIN            (LPC_GPIO2->FIOSET |= (1 << DATA_IRQ_CMD_PIN))
#define CLEAR_IRQ_CMD_PIN          (LPC_GPIO2->FIOCLR |= (1 << DATA_IRQ_CMD_PIN))

#define GET_IRQ_CMD_PIN            (LPC_GPIO2->FIOPIN & (1 << DATA_IRQ_CMD_PIN))
#define SET_IRQ_CMD_PIN_INPUT      (LPC_GPIO2->FIODIR &= ~(1 << DATA_IRQ_CMD_PIN))
#define SET_LOW_CMD_PIN            (LPC_PINCON->PINMODE4 |= (3<<22))

#define SET_USB_CONNECT_PIN_OUTPUT (LPC_GPIO2->FIODIR    |= (1 << USB_CONNECT_PIN))
#define SET_USB_CONNECT_PIN		   (LPC_GPIO2->FIOSET    |= (1 << USB_CONNECT_PIN))
#define CLEAR_USB_CONNECT_PIN	   (LPC_GPIO2->FIOCLR    |= (1 << USB_CONNECT_PIN))

/*Control Commands Codes*/
#define LPC1769_COMP_CODE	0x30	/**<Indicates that the data is for LPC1769*/

#define LPC_1769_CMD		0x31	/**<Indicates that command is for LPC1769*/
#define FMTM_CMD			0x33	/**<Indicates that the command is FMTM command*/


/*Buffer to store the data when command code is for LPC1769. Added to ensure that the subsequent
 * command does over VCOM does not overwrite the SERIAL FIFO
*/
#define BUFSIZE	1048
uint8_t Incoming_Buffer[BUFSIZE]; /**<Used to store the data when LPC1769 is processing */
uint8_t Response_Buffer[BUFSIZE]; /**<Used to send response to PC */


/*Variable used in the slave modules*/
uint8_t SlaveTxBuffer[BUFSIZE];
uint8_t SlaveRxBuffer[BUFSIZE];



/**Host interface details structure*/
typedef struct{
	uint8_t bOperation;
	uint8_t bChannel;
	uint8_t bInterface;
	uint8_t bCmdRes;
}DUT_HifInterface_t;


/**Incoming frame*/
typedef struct{
	uint8_t bCmdCode;
	uint8_t interface;
	uint16_t wLength;
	uint8_t pbData[0];
}DUT_CmdFrame_t;

/**Response frame*/
typedef struct{
	uint8_t bCmdCode;
	uint8_t interface;
	uint16_t wStatus;
	uint16_t wLength;
	uint8_t pbData[0];
}DUT_RespFrame_t;

/*******************************************************
 * Communication Modes
 ******************************************************/
typedef enum
{

	HDLL_W_CRC,
	HDLL_WO_CRC,
	NATIVE,
	NCI,
	Other,
}commModes_t;


typedef enum
{
	DEVICE_ID = 0x00,
	SOFT_RESET,
	TX_SOFT_RESET,
}PN640_cmd;



/*Global varaible to maintain the current master and slave configured and last slave address used*/
extern uint8_t gCurr_Master;
extern uint8_t gCurr_Slave;
extern uint8_t gslave_addr;
extern uint8_t g_wait_DATAIRQ; /*FIXME: Check if required. Still not implemented*/
extern uint16_t g_wTimeOut;
extern commModes_t g_mode;
extern commModes_t g_mode_s;

extern void Clear_USB_Pin(void);
extern void DUT_GPIO_Config(void);
/*extern void DUT_PN640_Init(void);
extern void DUT_CLEAR_RESET(void);
extern void DUT_SET_RESET(void);
extern void DUT_RESET(void);
extern void DUT_Assert_Dwl(void);
extern void DUT_Deassert_Dwl(void);*/
extern Bool DUT_GetRxPin(void);
extern void Config_USB_Pins(void);

void LPC_FW_INIT(void);

extern void PN640_Send(void);
void Get_LPC_Version(DUT_CmdFrame_t* );
extern void Payload_Incomplete(void);
void PN460_CMD(DUT_CmdFrame_t *);
void FMTM(DUT_CmdFrame_t *);

#endif /* PN640_H_ */
