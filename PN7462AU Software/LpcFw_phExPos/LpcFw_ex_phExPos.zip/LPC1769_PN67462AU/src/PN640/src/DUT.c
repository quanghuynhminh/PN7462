/*
 * DUT.c
 *
 *  Created on: Apr 4, 2014
 *      Author: nxp74831
 */

#include "delay.h"
#include "DUT.h"
#include "LPC17xx.h"
#include "serial_fifo.h"
#include "USBVcom.h"
#include "DUT_I2C.h"
#include "DUT_SPI.h"
#include "dutCmd.h"
#include "lpc17xx_i2c.h"
#include "wdt.h"
#include "string.h"
#include "LPCVCOM_Ver.h"

#ifdef PHFL_SYSVNV
#include "phSysCommon.h"
#endif


#ifndef __SD_PROJECT__
#include "SysDispatcher.h"					//SysVnv
#endif

static const char version_compile_time[] = __DATE__ " " __TIME__;
static const char version_svn[] = PN640_LPC_VERSION_STRING;


void DUT_GPIO_Config(void)//uint8_t value, uint8_t pinx)
{
	/*configure Rx pin as i/p port */
	SET_IRQ_CMD_PIN_INPUT;
	SET_LOW_CMD_PIN;
}
#if 0
void DUT_PN640_Init(void)
{
	/*perform PN640 reset*/
	DUT_RESET();
	CLEAR_DWLD_PIN;
}

/*Clear the reset pin P2.5*/
void DUT_CLEAR_RESET(void)
{
	/*TODO check perform reset*/
	CLEAR_RST_PIN;

}

void DUT_RESET(void)
{
	SET_RST_PIN;
	delay(800);
	//delay_1(10);
}

void DUT_SET_RESET(void)
{
	SET_RST_PIN;
}

/*Set the download pin P0.21*/
void DUT_Assert_Dwl(void)
{
	/* Assert Download request pin */
	SET_DWLD_PIN;
}

/*Clear the download pin P0.21*/
void DUT_Deassert_Dwl(void)
{
	/* Deassert Download request pin */
	CLEAR_DWLD_PIN;
}
#endif
/* Get status of the Data IRQ pin*/
Bool DUT_GetRxPin(void)
{
	/*Return Data Ready IRQ pin status. */
	if(GET_IRQ_CMD_PIN)
		return true;
	else
		return false;
}


void Config_USB_Pins(void)
{
	/*Configure USB_Connect pin*/
	LPC_PINCON->PINSEL4 &= ~(0x03<<18);
	LPC_PINCON->PINSEL4 |=  (0x01<<18);

	/*Configure USB_D+ pin*/
	LPC_PINCON->PINSEL1 &= ~(0x03<<26);
	LPC_PINCON->PINSEL1 |= (0x01<<26);

	/*Configure USB_D- pin*/
	LPC_PINCON->PINSEL1 &= ~(0x03<<28);
	LPC_PINCON->PINSEL1 |= (0x01<<28);

}

void Clear_USB_ConnectPin(void)
{
	SET_USB_CONNECT_PIN_OUTPUT	;

	CLEAR_USB_CONNECT_PIN	;
}

void Set_USB_PinsInput(void)
{
	SET_USB_D_P_PIN_INPUT;
	SET_USB_D_N_PIN_INPUT;
}

void LPC_FW_INIT(void)
{
	gCurr_Master = ~0;
	gCurr_Slave	 = ~0;
}

/*
 * Function Name     : PN640_Send
 * Description       : Parses the first incoming byte of data.
 * Input Parameters  : void
 * Output Parameters :
 * NOTE				 : Need to look into the second case. Held up with the timeout byte to be used.
 */
void PN640_Send(void)
{
	uint16_t wbuf_len;
	//uint8_t ret;
	wbuf_len=VCOM_GetString((char *)Incoming_Buffer);
	DUT_CmdFrame_t *pInFrame = (DUT_CmdFrame_t *)&Incoming_Buffer;

	switch(pInFrame->bCmdCode)
	{
		case LPC1769_COMP_CODE:
			dutparseConfigurationComand(pInFrame);
			break;

		case LPC_1769_CMD:
			if(pInFrame->interface  == 0x01)
			{
				Get_LPC_Version(pInFrame);
			}
			else if(pInFrame->interface  == 0x02)
			{
				LPC_Response_to_PC(pInFrame,DUT_STATUS_SUCCESS);
				//delay(1000);
				WDTForceSysRst();
			}
			else if(pInFrame->interface  == 0x03)
			{
				PN460_CMD(pInFrame);
			}
#ifdef PHFL_SYSVNV
		else if(pInFrame->interface  == 0x04)///switching mass storage mode
					{
						Switch_Massstorage();
					}
					else if(pInFrame->interface  == 0x05)///switching I2C mode
					{
						Switch_I2CMode();
					}
					else if(pInFrame->interface  == 0x06)	//Reset the Lpc
					{
						delay(500);
						WDTForceSysRst();
					}

			break;
		case 0xAA:
		    SysDriverTestSPIHIF_Lpc(pInFrame);
		    break;
#endif

		default:
				FMTM(pInFrame);
			break;
	}
}

/*
 * Function Name     : Get_LPC_Version
 * Description       : Provides the SVN Version and the date and time string to PC.
 * Input Parameters  : Structure pointer to the incoming frame format
 * Output Parameters :
 * NOTE				 :added the 16bit major number
 */
void Get_LPC_Version(DUT_CmdFrame_t* cmd_t)
{
	uint16_t svnlen = sizeof(LpcVCOM_VER_FILEDESCRIPTION);
	Response_Buffer[0]= cmd_t->bCmdCode;
	Response_Buffer[1]=cmd_t->interface|0x80;
	Response_Buffer[2]=0x00;
	Response_Buffer[3]=0x00;
	*((uint16_t*)(&Response_Buffer[4]))= (svnlen);
	memcpy(&(Response_Buffer[6]),LpcVCOM_VER_FILEDESCRIPTION,svnlen);
	DUT_Response_to_PC(Response_Buffer,(svnlen+6));
}

/*
 * Function Name     : Payload_Incomplete
 * Description       : Returns a ERROR condition to the PC if complete payload is not received.
 * Input Parameters  :
 * Output Parameters :
 * NOTE				 :
 */
void Payload_Incomplete(void)
{
	VCOM_GetString((char *)Incoming_Buffer);

	DUT_CmdFrame_t *pInFrame = (DUT_CmdFrame_t *)&Incoming_Buffer;

	LPC_Response_to_PC(pInFrame,PH_ERR_LENGTH_ERROR);/*Payload and Length mismatch*/
}

void PN460_CMD(DUT_CmdFrame_t *PN640_CMD_t)
{
	PN640_cmd PN640_cmd_task = PN640_CMD_t->pbData[0];
	uint8_t abDev_ID[3];
	uint16_t bDevID_len = 3;
	Response_Buffer[0] = PN640_CMD_t->bCmdCode;
	Response_Buffer[1] = PN640_CMD_t->interface | 0x80;
	switch(PN640_cmd_task)
	{
		case DEVICE_ID:
			 if (((PN640_CMD_t->interface >> 3 & 0x03) == I2C0) && (gCurr_Master == I2C0))
			 {
				 if(Get_Device_ID_PN640(LPC_I2C0,PN640_CMD_t->pbData[1],abDev_ID,bDevID_len))
				 {
					 *((uint16_t *)(&Response_Buffer[2])) = 0x0000;
					 *((uint16_t *)(&Response_Buffer[4])) = bDevID_len;
					 memcpy(&Response_Buffer[6],&abDev_ID,bDevID_len);
					 DUT_Response_to_PC(Response_Buffer,bDevID_len+6);
				 }
				 else
					 LPC_Response_to_PC(PN640_CMD_t,PH_ERR_TX_NAK_ERROR);
			 }
			 else
					LPC_Response_to_PC(PN640_CMD_t,DUT_STATUS_I2C_NOT_CONFIG);
			break;
		case SOFT_RESET:
			if(((PN640_CMD_t->interface >> 3 & 0x03) == I2C0) && (gCurr_Master == I2C0))
			{
				/*Issue a general call for reset followed by 0x06 value*/
				 if(Soft_Reset_PN640(LPC_I2C0,PN640_CMD_t->pbData[1]))
					LPC_Response_to_PC(PN640_CMD_t,DUT_STATUS_SUCCESS);
				 else
					LPC_Response_to_PC(PN640_CMD_t,PH_ERR_TX_NAK_ERROR);
			}
			else
				LPC_Response_to_PC(PN640_CMD_t,DUT_STATUS_I2C_NOT_CONFIG);
			break;
		case TX_SOFT_RESET:
			if(((PN640_CMD_t->interface >> 3 & 0x03) == I2C0) && (gCurr_Master == I2C0))
			{
				/*Issue a repeated start with a reset sequence during transfer.*/
				if(I2C_Tx_with_Soft_Reset_PN640(LPC_I2C0))
					LPC_Response_to_PC(PN640_CMD_t,DUT_STATUS_SUCCESS);
				else
					LPC_Response_to_PC(PN640_CMD_t,PH_ERR_TX_NAK_ERROR);

			}
			break;
	}
}

void FMTM(DUT_CmdFrame_t *fmtmcmd_t)
{
	uint8_t block_nonblock_call,ret;//0-Blocking; 1-Non-Blocking call
	block_nonblock_call = (fmtmcmd_t->interface >> 6);
	Status retval;
	switch(gCurr_Master)
	{
	case I2C0:
		/**Master I2C0 connected to PN640*/
		fmtm_i2c(LPC_I2C0,fmtmcmd_t,block_nonblock_call);
		break;
	case I2C1:
		/**Master I2C1 connected to connected to IO Expander*/
		fmtm_i2c(LPC_I2C1,fmtmcmd_t,block_nonblock_call);
		break;
	case I2C2:
		/**Slave I2C2 connected to PN640*/
		/*TODO*/

		break;
	case (SSP0|0x10):/*Or-ing mask value to get the current master interface configured*/
		/*TODO*/
		if(block_nonblock_call)
		{
			retval = fmtm_SPI_Send(LPC_SSP0,fmtmcmd_t);
			if(retval == SUCCESS)
				LPC_Response_to_PC(fmtmcmd_t,DUT_STATUS_SUCCESS);
			else
				LPC_Response_to_PC(fmtmcmd_t,PH_ERR_INTERNAL_ERROR);
		}
		else
		{/*Blocking call for TxRx*/
			retval = fmtm_SPI_Send(LPC_SSP0,fmtmcmd_t);
			if(retval == SUCCESS)
				fmtm_SPI_Receive(LPC_SSP0,fmtmcmd_t);
		}
		break;
	case (SSP1|0x10):
		/*Slave can only transmit and receive it cannot perform the TxRx*/
			if(block_nonblock_call)
			{
				SSP_slave_cfg_t.length = fmtmcmd_t->wLength;
				SSP_slave_cfg_t.tx_data = (uint8_t*)(fmtmcmd_t);
				SSP_slave_cfg_t.tx_cnt	=	0;

				SSP_ReadWrite(LPC_SSP1,&SSP_slave_cfg_t,SSP_TRANSFER_INTERRUPT);

				LPC_Response_to_PC(fmtmcmd_t,DUT_STATUS_SUCCESS);
			}
		break;
	case (UART1|0x20):
		if(block_nonblock_call)
		{
			ret = fmtm_HSU_Send((LPC_UART_TypeDef *)LPC_UART1,fmtmcmd_t);
			switch(ret)
			{
				case 1:
					LPC_Response_to_PC(fmtmcmd_t,DUT_STATUS_SUCCESS);
					break;
				case 2:
					LPC_Response_to_PC(fmtmcmd_t,PH_ERR_CTS_UNAVAILABLE);
					break;
				default:
					LPC_Response_to_PC(fmtmcmd_t,PH_ERR_INTERNAL_ERROR);
					break;
			}
		}
		else/*Blcoking CALL i.e TxRx*/
		{
			ret = fmtm_HSU_Send((LPC_UART_TypeDef *)LPC_UART1, fmtmcmd_t);
			if(ret)
				HSU_Receive((LPC_UART_TypeDef *)LPC_UART1,fmtmcmd_t);
		}
		break;
	default:
		LPC_Response_to_PC(fmtmcmd_t,PH_ERR_PROTOCOL_ERROR);
		break;
	}
}
