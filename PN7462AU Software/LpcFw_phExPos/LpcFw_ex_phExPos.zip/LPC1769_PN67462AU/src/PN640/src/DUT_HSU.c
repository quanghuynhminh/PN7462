/*
 * DUT_HSU.c
 *
 *  Created on: May 1, 2014
 *      Author: NXP74831
 */

#include "DUT_HSU.h"
#include "delay.h"
#include "dutCmd.h"
#include "string.h"

/* Buf mask */
#define __BUF_MASK (UART_RING_BUFSIZE-1)
/* Check buf is full or not */
#define __BUF_IS_FULL(head, tail) ((tail&__BUF_MASK)==((head+1)&__BUF_MASK))
/* Check buf will be full in next receiving or not */
#define __BUF_WILL_FULL(head, tail) ((tail&__BUF_MASK)==((head+2)&__BUF_MASK))
/* Check buf is empty */
#define __BUF_IS_EMPTY(head, tail) ((head&__BUF_MASK)==(tail&__BUF_MASK))
/* Reset buf */
#define __BUF_RESET(bufidx)	(bufidx=0)
#define __BUF_INCR(bufidx)	(bufidx=(bufidx+1)&__BUF_MASK)

#define RTS_MASK	(1<<7)
#define UART1_RTS_OUTPUT	LPC_GPIO2->FIODIR |= RTS_MASK
#define UART1_RTS_SET		LPC_GPIO2->FIOSET |= RTS_MASK
#define UART1_RTS_CLEAR		LPC_GPIO2->FIOCLR |= RTS_MASK

#define CTS_MASK	(1<<17)
#define UART1_CTS_INPUT			(LPC_GPIO0->FIODIR &= ~(CTS_MASK))
#define UART1_CTS_SET_LOW		(LPC_PINCON->PINMODE1 |= (3<<2))
#define UART1_GET_CTS_VAL	    (LPC_GPIO0->FIOPIN & (CTS_MASK))
/************************** PRIVATE TYPES *************************/


// RTS State
__IO int32_t RTS_State;

// Current Tx Interrupt enable state
__IO FlagStatus TxIntStat;


/************************** PRIVATE FUNCTIONS *************************/
/* Interrupt service routines */
void UART_IntErr(uint8_t bLSErrType);
void UART_IntTransmit(void);
//void UART_IntReceive(void); //Required for UART0 Interrupt handler
void UART1_IntReceive(void);
Status GET_CTS_STATUS(void);
/*----------------- INTERRUPT SERVICE ROUTINES --------------------------*/
#if 0
/*********************************************************************//**
 * @brief		UART0 interrupt handler sub-routine
 * @param[in]	None
 * @return 		None
 **********************************************************************/
void UART0_IRQHandler(void)
{
	uint32_t intsrc, tmp, tmp1;

	/* Determine the interrupt source */
	intsrc = UART_GetIntId(LPC_UART0);
	tmp = intsrc & UART_IIR_INTID_MASK;

	// Receive Line Status
	if (tmp == UART_IIR_INTID_RLS){
		// Check line status
		tmp1 = UART_GetLineStatus(LPC_UART0);
		// Mask out the Receive Ready and Transmit Holding empty status
		tmp1 &= (UART_LSR_OE | UART_LSR_PE | UART_LSR_FE \
				| UART_LSR_BI | UART_LSR_RXFE);
		// If any error exist
		if (tmp1) {
				UART_IntErr(tmp1);
		}
	}

	// Receive Data Available or Character time-out
	if ((tmp == UART_IIR_INTID_RDA) || (tmp == UART_IIR_INTID_CTI)){
			UART_IntReceive();
	}
}
#endif

/*********************************************************************//**
 * @brief		UART1 interrupt handler sub-routine
 * @param[in]	None
 * @return 		None
 **********************************************************************/
void UART1_IRQHandler(void)
{
	//uint8_t modemsts;
	uint32_t intsrc, tmp, tmp1;

	/* Determine the interrupt source */
	intsrc = UART_GetIntId((LPC_UART_TypeDef *)LPC_UART1);
	tmp = intsrc & UART_IIR_INTID_MASK;

	/*
	 * In case of using UART1 with full modem,
	 * interrupt ID = 0 that means modem status interrupt has been detected
	 */
	// Receive Line Status
	if (tmp == UART_IIR_INTID_RLS){
		// Check line status
		tmp1 = UART_GetLineStatus((LPC_UART_TypeDef *)LPC_UART1);
		// Mask out the Receive Ready and Transmit Holding empty status
		tmp1 &= (UART_LSR_OE | UART_LSR_PE | UART_LSR_FE \
				| UART_LSR_BI | UART_LSR_RXFE);
		// If any error exist
		if (tmp1) {
			UART_IntErr(tmp1);
		}
	}

	// Receive Data Available or Character time-out
	if ((tmp == UART_IIR_INTID_RDA) || (tmp == UART_IIR_INTID_CTI)){
		UART1_IntReceive();
	}

#if 0
	// Transmit Holding Empty
	if (tmp == UART_IIR_INTID_THRE){
		UART1_IntTransmit();
	}
#endif
}

/********************************************************************//**
 * @brief 		UART1 receive function (ring buffer used)
 * @param[in]	None
 * @return 		None
 *********************************************************************/
void UART1_IntReceive(void)
{
	uint8_t tmpc;
	uint32_t rLen;

	while (1){
		// Call UART read function in UART driver
		rLen = UART_Receive((LPC_UART_TypeDef *)LPC_UART1, &tmpc, 1, NONE_BLOCKING);
		// If data received
		if (rLen){

			/* If buffer will be full and RTS is driven manually,
			 * RTS pin should be forced into INACTIVE state
			 */
#if (AUTO_RTS_CTS_USE == 0)
			if (__BUF_WILL_FULL(rb.rx_head, rb.rx_tail))
			{
				if (RTS_State == ACTIVE)
				{
					// Disable request to send through RTS line
					UART_FullModemForcePinState(LPC_UART1, UART1_MODEM_PIN_RTS, \
							INACTIVE);
					RTS_State = INACTIVE;
				}
			}
#endif

			/* Check if buffer is more space
			 * If no more space, remaining character will be trimmed out
			 */
			if (!__BUF_IS_FULL(rb.rx_head,rb.rx_tail)){
				rb.rx[rb.rx_head] = tmpc;
				__BUF_INCR(rb.rx_head);
			}
		}
		// no more data
		else {
			break;
		}
	}
}


#if 0
/********************************************************************//**
 * @brief 		UART0 Interrupt receive function (ring buffer used)
 * @param[in]	None
 * @return 		None
 *********************************************************************/
void UART_IntReceive(void)
{
	uint8_t tmpc;
	uint32_t rLen;

	while(1){
		// Call UART read function in UART driver
		rLen = UART_Receive((LPC_UART_TypeDef *)LPC_UART0, &tmpc, 1, NONE_BLOCKING);
		// If data received
		if (rLen){
			/* Check if buffer is more space
			 * If no more space, buffer is overwritten
			 */
			if (!__BUF_IS_FULL(rb.rx_head,rb.rx_tail)){
				rb.rx[rb.rx_head] = tmpc;
				__BUF_INCR(rb.rx_head);
			}
			else
				rb.rx_head = 0;
		}
		// no more data
		else {
			break;
		}
	}
}
#endif

/*********************************************************************//**
 * @brief		UART Line Status Error
 * @param[in]	bLSErrType	UART Line Status Error Type
 * @return		None
 **********************************************************************/
void UART_IntErr(uint8_t bLSErrType)
{
	uint8_t test;
	// Loop forever
	while (1){
		LPC_GPIO0->FIOSET |= (1 << 22);
		delay(2000);
		LPC_GPIO0->FIOCLR |= (1 << 22);
		delay(1000);
		// For testing purpose
	}
	test = bLSErrType;


}

/* @brief		UART Line Status Error
 * @param[in]	bLSErrType	UART Line Status Error Type
 * @return		None
 **********************************************************************/
Status GET_CTS_STATUS(void)
{
	if(UART1_GET_CTS_VAL)
		return ERROR;
	else
		return SUCCESS;
}


/*******************************Public Functions********************************/
void DUT_HSU_Operation(DUT_CmdFrame_t *HSU_oper_t)
{
	dutoperations_t HSU_operations= (dutoperations_t)( (HSU_oper_t->interface) & 0x07 );
	int ret;

	switch(HSU_operations)
	{
		case DUT_CONFIG:
			//UART0_Config(HSU_oper_t);
			UART1_Config(HSU_oper_t);
			gCurr_Master = UART1;
			gCurr_Master |= 0x20;
			LPC_Response_to_PC(HSU_oper_t, DUT_STATUS_SUCCESS);
			break;
		case DUT_Tx:
			if((HSU_oper_t->interface >> 3 &0x03) == UART1 && ((gCurr_Master&0x0F) == UART1))
			{
					ret = HSU_Send((LPC_UART_TypeDef *)LPC_UART1, HSU_oper_t);

					switch(ret)
					{
						case 1:
							LPC_Response_to_PC(HSU_oper_t,DUT_STATUS_SUCCESS);
							break;
						case 2:
							LPC_Response_to_PC(HSU_oper_t,PH_ERR_CTS_UNAVAILABLE);
							break;
						default:
							LPC_Response_to_PC(HSU_oper_t,PH_ERR_INTERNAL_ERROR);
							break;
					}
			}
			else
				LPC_Response_to_PC(HSU_oper_t,DUT_STATUS_HSU_NOT_CONFIG);
			break;
		case DUT_Rx:
			if((HSU_oper_t->interface >> 3 &0x03) == UART1 && ((gCurr_Master&0x0F) == UART1))
			{
				HSU_Receive((LPC_UART_TypeDef *)LPC_UART1,HSU_oper_t);
			}
			else
				LPC_Response_to_PC(HSU_oper_t,DUT_STATUS_HSU_NOT_CONFIG);
			break;
		case DUT_TxRx:
			__BUF_RESET(rb.rx_head);
			__BUF_RESET(rb.rx_tail);
			UART1_RTS_CLEAR;
			HSU_Send((LPC_UART_TypeDef *)LPC_UART1,HSU_oper_t);
			HSU_Receive((LPC_UART_TypeDef *)LPC_UART1,HSU_oper_t);
			break;
	}
}


void UART1_Config(DUT_CmdFrame_t *HSU_cfg_t)
{
	uint32_t baudrate;
	UART_CFG_Type UART_CFG;
	UART_FIFO_CFG_Type UARTFIFOConfigStruct;
	uint8_t parity,Databits,Stopbits,idx;

	baudrate	= *(uint32_t*)(&HSU_cfg_t->pbData[0]);
	parity		= (HSU_cfg_t->pbData[4] >> 3) & 0x07;
	Databits	= (HSU_cfg_t->pbData[4] >> 6) & 0x03;
	Stopbits	= (HSU_cfg_t->pbData[4]) & 0x07;
	g_mode		= (HSU_cfg_t->pbData[5]);
	UART_CFG.Baud_rate	= baudrate;
	UART_CFG.Parity		= parity;
	UART_CFG.Databits	= Databits;
	UART_CFG.Stopbits	= Stopbits;

	PINSEL_CFG_Type PinCfg;
	PinCfg.Funcnum = 1;
	PinCfg.OpenDrain = PINSEL_PINMODE_OPENDRAIN;
	PinCfg.Pinmode = PINSEL_PINMODE_TRISTATE;
	PinCfg.Portnum = 0;
	for (idx = 15; idx <= 16; idx++)
	{
		PinCfg.Pinnum = idx;
		PINSEL_ConfigPin(&PinCfg);
	}

	// Initialize UART0 peripheral with given to corresponding parameter
	UART_Init((LPC_UART_TypeDef *)LPC_UART1,&UART_CFG);

	// Initialize FIFO for UART1 peripheral
	UART_FIFOConfigStructInit(&UARTFIFOConfigStruct);
	UART_FIFOConfig((LPC_UART_TypeDef *)LPC_UART1, &UARTFIFOConfigStruct);


	// Enable CTS1 signal transition interrupt
	//UART_IntConfig((LPC_UART_TypeDef *)LPC_UART1, UART1_INTCFG_CTS, ENABLE);
	//// Force RTS pin state to ACTIVE
	//UART_FullModemForcePinState(LPC_UART1, UART1_MODEM_PIN_RTS, ACTIVE);
	/* Enable UART Rx interrupt */
	UART_IntConfig((LPC_UART_TypeDef *)LPC_UART1, UART_INTCFG_RBR, ENABLE);
	/* Enable UART line status interrupt */
	UART_IntConfig((LPC_UART_TypeDef *)LPC_UART1, UART_INTCFG_RLS, ENABLE);


	// Reset ring buf head and tail idx
	__BUF_RESET(rb.rx_head);
	__BUF_RESET(rb.rx_tail);


	UART_TxCmd((LPC_UART_TypeDef *)LPC_UART1,ENABLE);
    /* preemption = 1, sub-priority = 1 */
	NVIC_SetPriority(UART1_IRQn, ((0x01<<3)|0x01));
	NVIC_EnableIRQ(UART1_IRQn);

	/*Since the RTS pin used is P2(7), we need to configure this pin to be OUTPUT*/
	UART1_RTS_OUTPUT;
	UART1_RTS_CLEAR;

	/*Since CTS P0-17 is used as input we need to initialize */
	UART1_CTS_INPUT;
	//UART1_CTS_SET_LOW;

}


int HSU_Send(LPC_UART_TypeDef *UARTx, DUT_CmdFrame_t *HSU_Tx_t)
{
	uint16_t txlen,ret;
	txlen = *(uint16_t*)(&HSU_Tx_t->wLength);
	while (UART_CheckBusy(UARTx) == SET);
	/*Checking for CTS before transmitting*/
	if(GET_CTS_STATUS())
	{
		ret = UART_Send(UARTx,&(HSU_Tx_t->pbData[0]),txlen,BLOCKING);
		if(ret != txlen)
			return 0;//ERROR
		else
			return 1;//SUCCESS
	}
	else
		return 2;//CTS UNAVAILABLE
}


void HSU_Receive(LPC_UART_TypeDef *UARTx, DUT_CmdFrame_t *HSU_Rx_t)
{
	uint16_t wlen;
	delay(200);/*Temporary timeout of 200ms waiting for the HSU Rx to complete*/
	while(!(UARTx->IIR & 0x01));
	NVIC_DisableIRQ(UART1_IRQn);
	UART1_RTS_SET;/*To disable accepting of data when LPC is responding to PC*/
	DUT_RespFrame_t  *resp_t = (DUT_RespFrame_t *)Response_Buffer;
	resp_t->bCmdCode = HSU_Rx_t->bCmdCode;
	resp_t->interface = HSU_Rx_t->interface | 0x80;
	resp_t->wStatus = DUT_STATUS_SUCCESS;

	if(g_mode == HDLL_W_CRC)
	{
		/*Obtain the length in HDLL frame format.*/
		if(rb.rx_head != rb.rx_tail)
		{
			wlen = rb.SlaveRxBuffer[rb.rx_tail];
			wlen <<= 8;
			wlen |= rb.SlaveRxBuffer[rb.rx_tail+1];
			resp_t->wLength = wlen+4;
			memcpy(&(resp_t->pbData[0]),&(rb.SlaveRxBuffer[rb.rx_tail]),wlen+4);
			DUT_Response_to_PC(Response_Buffer,resp_t->wLength+6);
		}
		else
		{
			resp_t->wStatus = PH_ERR_DATA_UNAVAILABLE_OVER_HSU;
			resp_t->wLength = 0;
			DUT_Response_to_PC(Response_Buffer,resp_t->wLength+6);
		}

	}
	else if(g_mode == HDLL_WO_CRC)
	{
		if(rb.rx_head != rb.rx_tail)
		{
			wlen = rb.SlaveRxBuffer[rb.rx_tail];
			wlen <<= 8;
			wlen |= rb.SlaveRxBuffer[rb.rx_tail+1];
			resp_t->wLength = wlen+2;
			memcpy(&(resp_t->pbData[0]),&(rb.SlaveRxBuffer[rb.rx_tail]),wlen+2);
			DUT_Response_to_PC(Response_Buffer,resp_t->wLength+6);
		}
	else
		{
			resp_t->wStatus = PH_ERR_DATA_UNAVAILABLE_OVER_HSU;
			resp_t->wLength = 0;
			DUT_Response_to_PC(Response_Buffer,resp_t->wLength+6);
		}
	}
	else if(g_mode == NATIVE)
	{
		if(rb.rx_head != rb.rx_tail)
		{
			wlen = *(uint16_t*)(&HSU_Rx_t->pbData[0]);;
			resp_t->wLength = *(uint16_t*)(&HSU_Rx_t->pbData[0]);
			memcpy(&(resp_t->pbData[0]),&(rb.SlaveRxBuffer[rb.rx_tail]),wlen);
			DUT_Response_to_PC(Response_Buffer,resp_t->wLength+6);
		}
		else
		{
			resp_t->wStatus = PH_ERR_DATA_UNAVAILABLE_OVER_HSU;
			resp_t->wLength = 0;
			DUT_Response_to_PC(Response_Buffer,resp_t->wLength+6);
		}
	}
	else if(g_mode == Other)
	{
		if(rb.rx_head != rb.rx_tail)
		{
			wlen = rb.SlaveRxBuffer[rb.rx_tail+5];
			wlen <<= 8;
			wlen |= rb.SlaveRxBuffer[rb.rx_tail+4];
			DUT_Response_to_PC(&(rb.SlaveRxBuffer[rb.rx_tail]),wlen+6);
		}
		else
		{
			resp_t->wStatus = PH_ERR_DATA_UNAVAILABLE_OVER_HSU;
			resp_t->wLength = 0;
			DUT_Response_to_PC(Response_Buffer,resp_t->wLength+6);
		}
	}
	else
		LPC_Response_to_PC(HSU_Rx_t,PH_ERR_UNSUPPORTED_PARAMETER);

	__BUF_RESET(rb.rx_head);
	__BUF_RESET(rb.rx_tail);
	NVIC_EnableIRQ(UART1_IRQn);
	UART1_RTS_CLEAR;
}

/**Function for HSU transmit whne the command code is other than 0x30*/
int fmtm_HSU_Send(LPC_UART_TypeDef * UARTx, DUT_CmdFrame_t *HSU_fmtm_Tx_t)
{
	uint16_t retval;
	while (UART_CheckBusy(UARTx) == SET);
	/*Checking for CTS before transmitting*/
	if(GET_CTS_STATUS())
	{
		retval = UART_Send(UARTx,(uint8_t*)HSU_fmtm_Tx_t,HSU_fmtm_Tx_t->wLength+4,BLOCKING);

		if(retval != ((HSU_fmtm_Tx_t->wLength)+4))
			return 0;//ERROR
		else
			return 1;//SUCCESS
	}
	else
		return 2;//CTS UNAVAILABLE
}
