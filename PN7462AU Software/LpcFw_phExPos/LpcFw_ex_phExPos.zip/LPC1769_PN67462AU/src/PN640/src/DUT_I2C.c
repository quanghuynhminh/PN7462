/*
 * DUT_I2C.c
 *
 *  Created on: Mar 27, 2014
 *      Author: nxp74831
 */

#include "DUT_I2C.h"
#include "delay.h"
#include "dutCmd.h"
#include <string.h>

/*Interrupt handler for the I2C2 peripheral*/
void I2C2_IRQHandler(void)
{
	I2C_SlaveHandler(LPC_I2C2);
}

/*
 *Function Name     : DUT_I2Cx_operation
 *Description       : Switch for different I2C operations
 *
 *Input Parameters  :Pointer to structure DUT_CmdFrame_t
 *Output Parameters : STATUS
 *
 *Note:             :
 */
dutStatus_t DUT_I2Cx_operation(DUT_CmdFrame_t *I2C_oper_t)
{
    Status ret;
    dutoperations_t I2C_operations = (dutoperations_t) ((I2C_oper_t->interface) & 0x07);
    switch (I2C_operations)
    /*Decide the operation to be performed*/
    {
    case DUT_CONFIG:
        DUT_I2Cx_Init(I2C_oper_t);
        LPC_Response_to_PC(I2C_oper_t, DUT_STATUS_SUCCESS);
        break;

    case DUT_Tx:
        /*TODO*/
        if (((I2C_oper_t->interface >> 3 & 0x03) == I2C0) && (gCurr_Master == I2C0))
        {
            LPC_I2C_M_Tx(LPC_I2C0, I2C_oper_t);

        }
        else if (((I2C_oper_t->interface >> 3 & 0x03) == I2C1) && (gCurr_Master == I2C1))
        {
            LPC_I2C_M_Tx(LPC_I2C1, I2C_oper_t);
        }
        else if (((I2C_oper_t->interface >> 3 & 0x03) == I2C2) && (gCurr_Slave == I2C2))
        {
        	if(g_mode_s == HDLL_WO_CRC)
        	{
				/*We go with HDLL mode of transmission*/
				I2C_SlaveCfg.tx_count = 0;
				SlaveTxBuffer[0] = (I2C_oper_t->wLength-6) & 0xFF;
				SlaveTxBuffer[1] = ((I2C_oper_t->wLength-6) >> 8) & 0xFF;
				memcpy(&(SlaveTxBuffer[2]), &(I2C_oper_t->pbData[6]), I2C_oper_t->wLength-6);
				LPC_Response_to_PC(I2C_oper_t, DUT_STATUS_SUCCESS);
        	}
        	else if(g_mode_s == NATIVE)
        	{
        		I2C_SlaveCfg.tx_count = 0;
        		memcpy(SlaveTxBuffer, &(I2C_oper_t->pbData[6]), I2C_oper_t->wLength-6);
        		LPC_Response_to_PC(I2C_oper_t, DUT_STATUS_SUCCESS);
        	}
        }
        else
            LPC_Response_to_PC(I2C_oper_t, DUT_STATUS_I2C_NOT_CONFIG);
        break;

    case DUT_Rx:
        /*TODO. Still needs implementation for the slave*/
        if (((I2C_oper_t->interface >> 3 & 0x03) == I2C0) && (gCurr_Master == I2C0))
        {
            LPC_I2C_M_Rx(LPC_I2C0, I2C_oper_t);
        }
        else if (((I2C_oper_t->interface >> 3 & 0x03) == I2C1) && (gCurr_Master == I2C1))
        {
            LPC_I2C_M_Rx(LPC_I2C1, I2C_oper_t);
        }
        else if (((I2C_oper_t->interface >> 3 & 0x03) == I2C2) && (gCurr_Slave == I2C2))
        {
            if (I2C_SlaveCfg.rx_count > 0)
            {
                uint16_t wlength;
                wlength = I2C_oper_t->pbData[5];
                wlength = wlength << 8;
                wlength |= I2C_oper_t->pbData[4];

                if(g_mode_s == NATIVE) /* If Number of bytes to receive is non-zero, Then it is in NATIVE mode. */
                {
                    Response_Buffer[0] = I2C_oper_t->bCmdCode;
                    Response_Buffer[1] = I2C_oper_t->interface | 0x80;
                    Response_Buffer[2] = DUT_STATUS_SUCCESS;
                    Response_Buffer[3] = DUT_STATUS_SUCCESS;
                    Response_Buffer[4] = (uint8_t) (wlength);
                    Response_Buffer[5] = (uint8_t) (wlength >> 8);
                    memcpy((&Response_Buffer[6]), (SlaveRxBuffer), wlength);

                    DUT_Response_to_PC(Response_Buffer, (wlength + 6));
                    I2C_SlaveCfg.rx_count = 0;
                }
                else if(g_mode_s == HDLL_WO_CRC)/* Else HDLL mode. */
                {
                    wlength = (SlaveRxBuffer[0]);
                    wlength <<= 8;
                    wlength |= (SlaveRxBuffer[1]);
                    wlength += 2; /* 2 bytes Length */

                    Response_Buffer[0] = I2C_oper_t->bCmdCode;
                    Response_Buffer[1] = I2C_oper_t->interface | 0x80;
                    Response_Buffer[2] = DUT_STATUS_SUCCESS;
                    Response_Buffer[3] = DUT_STATUS_SUCCESS;
                    Response_Buffer[4] = (uint8_t) (wlength);
                    Response_Buffer[5] = (uint8_t) (wlength >> 8);
                    memcpy((&Response_Buffer[6]), (SlaveRxBuffer), wlength);

                    DUT_Response_to_PC(Response_Buffer, wlength + 6);
                    I2C_SlaveCfg.rx_count = 0;
                }
                else if(g_mode_s == HDLL_W_CRC)/* Else HDLL mode. */
				{
					wlength = (SlaveRxBuffer[0]);
					wlength <<= 8;
					wlength |= (SlaveRxBuffer[1]);
					wlength += 4; /* 2 bytes CRC and 2 bytes Length */

					Response_Buffer[0] = I2C_oper_t->bCmdCode;
					Response_Buffer[1] = I2C_oper_t->interface | 0x80;
					Response_Buffer[2] = DUT_STATUS_SUCCESS;
					Response_Buffer[3] = DUT_STATUS_SUCCESS;
					Response_Buffer[4] = (uint8_t) (wlength);
					Response_Buffer[5] = (uint8_t) (wlength >> 8);
					memcpy((&Response_Buffer[6]), (SlaveRxBuffer), wlength);

					DUT_Response_to_PC(Response_Buffer, wlength + 6);
					I2C_SlaveCfg.rx_count = 0;
				}
                else if(g_mode_s == Other)
                {/*when the I2C is the slave mode is for  transfers other than command code 0x30*/
                	wlength = (SlaveRxBuffer[5]);
					wlength <<= 8;
					wlength |= (SlaveRxBuffer[4]);
					DUT_Response_to_PC(Response_Buffer, wlength + 6);
					I2C_SlaveCfg.rx_count = 0;
                }
            }
            else
                LPC_Response_to_PC(I2C_oper_t, PH_ERR_PROTOCOL_ERROR);

        }
        else
            LPC_Response_to_PC(I2C_oper_t, DUT_STATUS_I2C_NOT_CONFIG);
        break;

    case DUT_TxRx:
        /*Transreceive for I2C0 and I2C1*/
        if (((I2C_oper_t->interface >> 3 & 0x03) == I2C0) && (gCurr_Master == I2C0))
        {
            ret = DUT_I2Cx_M_Send(LPC_I2C0, &(I2C_oper_t->pbData[6]),I2C_oper_t->wLength-6,gslave_addr);
            if (ret)
                LPC_I2C_M_Rx(LPC_I2C0, I2C_oper_t);
            else
               LPC_Response_to_PC(I2C_oper_t,PH_ERR_TX_NAK_ERROR);
        }
        else if (((I2C_oper_t->interface >> 3 & 0x03) == I2C1) && (gCurr_Master == I2C1))
        {
            ret = DUT_I2Cx_M_Send(LPC_I2C0, &(I2C_oper_t->pbData[6]),I2C_oper_t->wLength-6,gslave_addr);
            if (ret)
                LPC_I2C_M_Rx(LPC_I2C1, I2C_oper_t);
            else
            	 LPC_Response_to_PC(I2C_oper_t,PH_ERR_TX_NAK_ERROR);
        }
        else
            LPC_Response_to_PC(I2C_oper_t, DUT_STATUS_I2C_NOT_CONFIG);
        break;
    }
    return DUT_STATUS_SUCCESS;
}

void DUT_I2Cx_Init(DUT_CmdFrame_t *I2C_init_t)
{
	I2C_ID_T I2C_NUM =((I2C_init_t->interface >> 3) & 0x03);
	dutMasterSlave_t I2C_M_S = I2C_init_t->pbData[0];
	uint32_t datarate = *((uint32_t*)(&I2C_init_t->pbData[3]));
	switch(I2C_NUM)
	{
		case I2C0: /*Configuring the I2C peripheral 0*/
			if(I2C_M_S == MASTER)
			{
				gCurr_Master = I2C0;
				gslave_addr = (I2C_init_t->pbData[1]);
				g_mode = I2C_init_t->pbData[7] &0x3F;
				g_wTimeOut = I2C_init_t->pbData[9];
				g_wTimeOut <<= 8;
				g_wTimeOut |= I2C_init_t->pbData[8];
				g_wait_DATAIRQ = ((I2C_init_t->pbData[7] >> 6) & 0x03);
				LPC_I2C_Init(LPC_I2C0,1,Port0,27,28,datarate);
			}
			else
				LPC_Response_to_PC(I2C_init_t,PH_ERR_INVALID_PARAMETER);
		break;

		case I2C1:/*Configuring the I2C peripheral 0*/
			if(I2C_M_S == MASTER )
			{
				gCurr_Master = I2C1;
				gslave_addr = (I2C_init_t->pbData[1]);
				g_mode = I2C_init_t->pbData[7] &0x3F;
				g_wTimeOut = I2C_init_t->pbData[9];
				g_wTimeOut <<= 8;
				g_wTimeOut |= I2C_init_t->pbData[8];
				g_wait_DATAIRQ = ((I2C_init_t->pbData[7] >> 6) & 0x03);
				LPC_I2C_Init(LPC_I2C1,3,Port0,0,1,datarate);
			}
			else
				LPC_Response_to_PC(I2C_init_t,PH_ERR_INVALID_PARAMETER);
		break;

		case I2C2:/*Configure I2C2 as slave for PN640 evaluation*/
			if(I2C_M_S == SLAVE)
			{
				gCurr_Slave=I2C2;
				g_mode_s = I2C_init_t->pbData[7] &0x3F;
				LPC_I2C_Init(LPC_I2C2,2,Port0,10,11,datarate);
				I2C_OWNSLAVEADDR_CFG_Type I2C2_Slavecfg;
				I2C2_Slavecfg.GeneralCallState = ENABLE;
				I2C2_Slavecfg.SlaveAddrChannel = 0;
				I2C2_Slavecfg.SlaveAddrMaskValue = 0;
				I2C2_Slavecfg.SlaveAddr_7bit = I2C_init_t->pbData[1];

				/*Configure the slave address and other parameters*/
				I2C_SetOwnSlaveAddr(LPC_I2C2, &I2C2_Slavecfg);

				LPC_I2Cx_S_Config(LPC_I2C2);
			}
			else
				LPC_Response_to_PC(I2C_init_t,PH_ERR_INVALID_PARAMETER);
		break;

		default:
			LPC_Response_to_PC(I2C_init_t,PH_ERR_INVALID_PARAMETER);
		break;

	}
}

/*
 *Function Name     : LPC_I2C_Init
 *Description       :Used for I2C Peripheral Initialization
 *
 *Input Parameters  :I2C channel
 *Input 			: Function number of the pins
 *Input 			:Port Number of the PINS
 *Input 			: SDA pin number
 *Input 			: SCL pin Num
 *Input 			: Clockrate
 *Output Parameters :
 *
 *Note:             :
 */
void LPC_I2C_Init(LPC_I2C_TypeDef *I2Cx, uint8_t fnum, uint8_t portnum, uint8_t SDA_pinnum, uint8_t SCL_pinnum, uint32_t clockrate)
{
	PINSEL_CFG_Type PinCfg;

	PinCfg.OpenDrain = PINSEL_PINMODE_OPENDRAIN;
	PinCfg.Pinmode = PINSEL_PINMODE_TRISTATE;
	PinCfg.Funcnum = fnum;
	PinCfg.Portnum = portnum;

	PinCfg.Pinnum = SDA_pinnum;/*SDA0 Pin of I2C0 port0 pin 27*/
	PINSEL_ConfigPin(&PinCfg);

	PinCfg.Pinnum = SCL_pinnum;/*SCL0 Pin of I2C0 port0 pin 28*/
	PINSEL_ConfigPin(&PinCfg);

	I2C_Init(I2Cx, clockrate);

	/*To enable I2Cx*/
	I2C_Cmd(I2Cx, ENABLE);
}

/*API to transmit data from the I2Cx configured to be the master
 *
 * return SUCCESS=1 or ERROR=0
 * */
Status DUT_I2Cx_M_Send(LPC_I2C_TypeDef *I2Cx, const uint8_t *buff, uint16_t len, uint8_t slaveAddr)
{
	/*Send data to DUT*/

	I2C_M_SETUP_Type Send_M_data;
	Send_M_data.sl_addr7bit = slaveAddr;
	Send_M_data.tx_length = len;
	Send_M_data.tx_data = buff;
	Send_M_data.rx_data = NULL;
	Send_M_data.rx_length = 0;
	Send_M_data.retransmissions_max=2;
	return(I2C_MasterTransferData(I2Cx,&Send_M_data,I2C_TRANSFER_POLLING));

	/*Delete after integration*/
	//return(Chip_I2C_MasterSend(I2C0, slaveAddr, buff, len));

}

/*API to receive data from the I2C0 configured to be the master*/
Status DUT_I2Cx_M_Receive(LPC_I2C_TypeDef *I2Cx, uint8_t *buff, uint16_t len, uint8_t slaveAddr, commModes_t mode)
{
	I2C_M_SETUP_Type Receive_data;
	Receive_data.sl_addr7bit = slaveAddr;
	Receive_data.rx_data=buff;
	Receive_data.tx_length = 0;
	Receive_data.tx_data = NULL;
	Receive_data.retransmissions_max =5;

	if(mode == HDLL_W_CRC)
	{
		/* HDDL Mode of receiving where the first 2 Bytes are length of receiving data */
		Receive_data.rx_length = 2;
		if(I2C_MasterTransferData(I2Cx, &Receive_data,I2C_TRANSFER_POLLING))
		{
			Receive_data.rx_length = buff[0];
			Receive_data.rx_length<<= 8;
			Receive_data.rx_length |= buff[1];
			Receive_data.rx_length += 2;
			Receive_data.rx_data = &(buff[2]);

			return(I2C_MasterTransferData(I2Cx, &Receive_data,I2C_TRANSFER_POLLING));
		}
		else
		{
			return ERROR;
		}
	}
	else if(mode == HDLL_WO_CRC)
		{
			/* HDDL Mode of receiving where the first 2 Bytes are length of receiving data */
			Receive_data.rx_length = 2;
			if(I2C_MasterTransferData(I2Cx, &Receive_data,I2C_TRANSFER_POLLING))
			{
				Receive_data.rx_length = buff[0];
				Receive_data.rx_length<<= 8;
				Receive_data.rx_length |= buff[1];
				Receive_data.rx_data = &(buff[2]);

				return(I2C_MasterTransferData(I2Cx, &Receive_data,I2C_TRANSFER_POLLING));
			}
			else
			{
				return ERROR;
			}
		}
	else if(mode == NATIVE)
	{
		/*NATIVE mode where the length is given by the I2C RX command*/
		Receive_data.rx_length = len;
		return(I2C_MasterTransferData(I2Cx, &Receive_data,I2C_TRANSFER_POLLING));
	}
	else if(mode == Other)
	{
		Receive_data.rx_length = 6;
		if(I2C_MasterTransferData(I2Cx, &Receive_data,I2C_TRANSFER_POLLING))
		{
			Receive_data.rx_length = buff[5];
			Receive_data.rx_length<<= 8;
			Receive_data.rx_length |= buff[4];
			//Receive_data.rx_length += 2;//Only if CRC is available
			Receive_data.rx_data = &(buff[6]);

			return(I2C_MasterTransferData(I2Cx, &Receive_data,I2C_TRANSFER_POLLING));
		}
		else
		{
			return ERROR;
		}
	}

	return ERROR;
}

/*API to check for the parameters and transmit the data*/
Status LPC_I2C_M_Tx(LPC_I2C_TypeDef *I2C, DUT_CmdFrame_t *I2C_Tx_t)
{
	Status ret;
	if( (I2C_Tx_t->pbData[0]) == 0xFF &&  (I2C_Tx_t->pbData[1]) == 0xFF )
		ret = DUT_I2Cx_M_Send(I2C, &(I2C_Tx_t->pbData[6]),I2C_Tx_t->wLength-6,gslave_addr);
	else
		ret = DUT_I2Cx_M_Send(I2C, &(I2C_Tx_t->pbData[6]),I2C_Tx_t->wLength-6,I2C_Tx_t->pbData[0]);
	if(ret)
	{
		LPC_Response_to_PC(I2C_Tx_t,DUT_STATUS_SUCCESS);
		return SUCCESS;
	}
	else
	{
		LPC_Response_to_PC(I2C_Tx_t,PH_ERR_TX_NAK_ERROR );
		return ERROR;
	}

}

/*API to check for the parameters and Receive the data*/
void LPC_I2C_M_Rx(LPC_I2C_TypeDef *I2C, DUT_CmdFrame_t *I2C_Rx_t)
{
	Status ret;
	uint16_t wtimeout,rxlen;
	/*Check for the data ready pin to go HIGH*/
	wtimeout = I2C_Rx_t->pbData[3];
	wtimeout <<= 8;
	wtimeout |= I2C_Rx_t->pbData[2];

	if(g_wait_DATAIRQ)
	{
		delay(wtimeout);
		ret = 1;
	}
	else
	{	ret = delay_1(wtimeout);}

	if(ret)
	{
		rxlen = I2C_Rx_t->pbData[5];
		rxlen <<= 8;
		rxlen |= I2C_Rx_t->pbData[4];
		DUT_RespFrame_t *resp_t = (DUT_RespFrame_t *)&Response_Buffer;
		ret = DUT_I2Cx_M_Receive(I2C,&(resp_t->pbData[0]),rxlen,gslave_addr,g_mode);
		if(ret)
		{
			resp_t->bCmdCode = I2C_Rx_t->bCmdCode;
			resp_t->interface = I2C_Rx_t->interface | 0x80;
			resp_t->wStatus = DUT_STATUS_SUCCESS; /*TODO Decide on the error codes*/
			if(g_mode == NATIVE)
			{
				resp_t->wLength =rxlen;
			}
			else if(g_mode == HDLL_W_CRC  )
			{
				resp_t->wLength = resp_t->pbData[0];
				resp_t->wLength <<= 8;
				resp_t->wLength |= resp_t->pbData[1];
				resp_t->wLength += 4;
			}
			else if(g_mode == HDLL_WO_CRC)
			{
				resp_t->wLength = resp_t->pbData[0];
				resp_t->wLength <<= 8;
				resp_t->wLength |= resp_t->pbData[1];
				resp_t->wLength += 2;

			}
			DUT_Response_to_PC(Response_Buffer,(resp_t->wLength+6)); /*Transmit the response back to the PC*/
		}
		else
		{
				LPC_Response_to_PC(I2C_Rx_t,PH_ERR_RX_NAK_ERROR);
		}
	}
	else
	{
		LPC_Response_to_PC(I2C_Rx_t,PH_ERR_IO_TIMEOUT);
	}
}


/*
 *Function Name     : LPC_I2Cx_S_Config
 *Description       :Used for I2C slave configuration for communication
 *
 *Input Parameters  :I2C channel
 *Output Parameters :Status	1. SUCCESS
 *		 					2. ERROR
 *
 *Note:             :The Interrupt of the slave is disabled everytime a transaction completes.
 */
Status LPC_I2Cx_S_Config(LPC_I2C_TypeDef *I2Cx)
{
	I2C_SlaveCfg.tx_length 	= sizeof(SlaveTxBuffer);
	I2C_SlaveCfg.tx_data	= SlaveTxBuffer;

	I2C_SlaveCfg.rx_length	= sizeof(SlaveRxBuffer);
	I2C_SlaveCfg.rx_data	= SlaveRxBuffer;
	I2C_SlaveCfg.rx_count = I2C_SlaveCfg.tx_count = 0;

	return(I2C_SlaveTransferData(I2Cx,&I2C_SlaveCfg,I2C_TRANSFER_INTERRUPT));

}

/*
 * Function Name     : fmtm_i2c
 * Description       : For transfers in FMTM scenario over I2C interface.
 * Input Parameters  :LPC I2C peripheral. can be LPC_I2C0 or LPC_I2C1 or LPC_I2C2
 * Input Parameters  :Structure pointer to the incoming frame format
 * Input Parameters	 :Variable indicating block or non-blocking call
 * Output Parameters : None
 * NOTE				 :
 */
void fmtm_i2c(LPC_I2C_TypeDef * I2Cx, DUT_CmdFrame_t *fmtm_i2c_t, uint8_t blk_nblk)
{
	Status ret;

	if(blk_nblk)
	{
		if(DUT_I2Cx_M_Send(I2Cx,(uint8_t*)fmtm_i2c_t,fmtm_i2c_t->wLength+4,gslave_addr))
		{
			Response_Buffer[0] = fmtm_i2c_t->bCmdCode;
			Response_Buffer[1] = fmtm_i2c_t->interface | 0x80;
			Response_Buffer[2] = 0x00;
			Response_Buffer[3] = 0x00;
			Response_Buffer[4] = 0x02;
			Response_Buffer[5] = 0x00;
			Response_Buffer[6] = 0x00;
			Response_Buffer[7] = 0x00;
			DUT_Response_to_PC(Response_Buffer,8);
		}
		else
			LPC_Response_to_PC(fmtm_i2c_t,PH_ERR_TX_NAK_ERROR);

	}
	else
	{
		ret = DUT_I2Cx_M_Send(I2Cx,(uint8_t*)fmtm_i2c_t,fmtm_i2c_t->wLength+4,gslave_addr);
		if(ret)
		{
			ret = delay_1(g_wTimeOut);
			if(ret)
			{
				DUT_RespFrame_t *resp_t = (DUT_RespFrame_t *)&Response_Buffer;
				if(DUT_I2Cx_M_Receive(I2Cx,Response_Buffer,0,gslave_addr,g_mode))
				{
					//resp_t->bCmdCode = fmtm_i2c_t->bCmdCode;
					//resp_t->interface = fmtm_i2c_t->interface | 0x80;
					//resp_t->wStatus = DUT_STATUS_SUCCESS;
					DUT_Response_to_PC(Response_Buffer,resp_t->wLength+6);
				}
				else
				{
					LPC_Response_to_PC(fmtm_i2c_t,PH_ERR_RX_NAK_ERROR);
				}
			}
			else
				LPC_Response_to_PC(fmtm_i2c_t,PH_ERR_IO_TIMEOUT);
		}
		else
				LPC_Response_to_PC(fmtm_i2c_t,PH_ERR_TX_NAK_ERROR);
	}
}







