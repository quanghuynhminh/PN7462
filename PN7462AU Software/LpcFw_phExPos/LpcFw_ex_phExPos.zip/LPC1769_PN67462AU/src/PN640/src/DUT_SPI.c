/*
 * DUT_SPI.c
 *
 *  Created on: Apr 28, 2014
 *      Author: NXP74831
 */

#include "DUT_SPI.h"
#include "delay.h"
#include "dutCmd.h"
#include "string.h"
#include "gpio_17xx_40xx.h"

void SSP1_IRQHandler()
{
	SSP1_StdIntHandler();

}

/*
 *Function Name     : SSP0_Init
 *Description       : Initialize the SSP0 Peripheral in Motorola SPI mode
 *
 *Input Parameters  :Clock polarity(0 or 1).
 *Input 			:Clock Phase(0 or 1).
 *Input 			:Clock rate(Maximum data bit rate of one eighth of the peripheral clock rate).
 *Output Parameters : STATUS
 *
 *Note:             :
 */
void SSP0_Init(uint8_t SSP_CPOL, uint8_t SSP_CPHA, uint32_t clockrate)
{
	PINSEL_CFG_Type pin_cfg={
		        .Portnum    = SSP_PORT,
		        .Pinmode    = PINSEL_PINMODE_TRISTATE,
		        .OpenDrain  = PINSEL_PINMODE_OPENDRAIN,
		    };

		    SSP_CFG_Type  ssp_cfg ={
		        .CPHA           = SSP_CPHA,
		        .CPOL           = SSP_CPOL,
		        .ClockRate      = clockrate,
		        .Databit        = SSP_DATABIT_8,
		        .Mode           = SSP_MASTER_MODE,
		        .FrameFormat    = SSP_FRAME_SPI
		    };

		    /*SSP PINSEL configuration*/
		    pin_cfg.Funcnum = 2;
		    pin_cfg.Pinnum = SSP_MISO0;
		    PINSEL_ConfigPin(&pin_cfg);

		    pin_cfg.Pinnum = SSP_MOSI0;
		    PINSEL_ConfigPin(&pin_cfg);


		    pin_cfg.Pinnum = SSP_SCLK0;
		    PINSEL_ConfigPin(&pin_cfg);

//Chip select pin is considered as a GPIO to drive it HIGH OR LOW*
		 //   pin_cfg.Pinnum = SSP_SSEL0;
		 //   PINSEL_ConfigPin(&pin_cfg);

		    /*Configuring the Pin0.16 to Output for using as Slave select*/
		    Chip_GPIO_SetPinDIROutput(LPC_GPIO_0, Port0, SSP_SSEL0);
		    Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,1);/*By default set the value to HIGH*/
		    /*initialize SSP*/
		    SSP_Init(LPC_SSP0, &ssp_cfg);
		    SSP_Cmd(LPC_SSP0, ENABLE);
		    return ;

}


/*
 *Function Name     : SSP1_Init
 *Description       : Initialize the SSP1 Peripheral in Motorola SPI mode
 *
 *Input Parameters  :Clock polarity(0 or 1).
 *Input 			:Clock Phase(0 or 1).
 *Input 			:Clock rate(Maximum data bit rate of one eighth of the peripheral clock rate).
 *Output Parameters : STATUS
 *
 *Note:             :
 */
void SSP1_Init(uint8_t SSP_CPOL, uint8_t SSP_CPHA, uint32_t clockrate)
{
	PINSEL_CFG_Type pin_cfg={
		        .Portnum    = SSP_PORT,
		        .Pinmode    = PINSEL_PINMODE_TRISTATE,
		        .OpenDrain  = PINSEL_PINMODE_OPENDRAIN,
		    };

		    SSP_CFG_Type  ssp_cfg ={
		        .CPHA           = SSP_CPHA,
		        .CPOL           = SSP_CPOL,
		        .ClockRate      = clockrate,
		        .Databit        = SSP_DATABIT_8,
		        .Mode           = SSP_SLAVE_MODE,
		        .FrameFormat    = SSP_FRAME_SPI
		    };

		    /*SSP PINSEL configuration*/
		    pin_cfg.Funcnum = 2;
		    pin_cfg.Pinnum = SSP_MISO1;
		    PINSEL_ConfigPin(&pin_cfg);

		    pin_cfg.Pinnum = SSP_MOSI1;
		    PINSEL_ConfigPin(&pin_cfg);

		    pin_cfg.Pinnum = SSP_SCLK1;
		    PINSEL_ConfigPin(&pin_cfg);

		    pin_cfg.Pinnum = SSP_SSEL1;
		    PINSEL_ConfigPin(&pin_cfg);

		    /*initialize SSP*/
		    SSP_Init(LPC_SSP1, &ssp_cfg);
		    SSP_Cmd(LPC_SSP1, ENABLE);
		    return ;
}


/*Function Name     : DUT_SSPx_Operation
 *Description       : Switch between differnet SPI operations
 *
 *Input Parameters  : Pointer to the structure of the Incoming frame
 *Output Parameters : NA
 *
 *Note:             :
 */
void DUT_SSPx_Operation(DUT_CmdFrame_t *SPI_oper_t)
{
	dutoperations_t SPI_operations= (dutoperations_t)( (SPI_oper_t->interface) & 0x07 );
	Status ret;
	switch (SPI_operations) {
		case DUT_CONFIG:
				SSPx_Config(SPI_oper_t);
			break;
		case DUT_Tx:
			if(((SPI_oper_t->interface >> 3 &0x03) == SSP0) && ((gCurr_Master&0x0F) == SSP0))
			{
				if(SSPx_Send(LPC_SSP0, SPI_oper_t))
					LPC_Response_to_PC(SPI_oper_t,DUT_STATUS_SUCCESS);
				else
					LPC_Response_to_PC(SPI_oper_t,PH_ERR_INTERNAL_ERROR);
			}
			else if(((SPI_oper_t->interface >> 3 &0x03) == SSP1) && ((gCurr_Slave&0x0F) == SSP1))
			{
				if(g_mode_s == HDLL_WO_CRC)
				{
					uint16_t wlen;
					wlen = SPI_oper_t->wLength-6;

					SlaveTxBuffer[1]	=	wlen & 0xFF;
					SlaveTxBuffer[0]	= 	(wlen >> 8)&0xFF;
					memcpy(&(SlaveTxBuffer[2]),&(SPI_oper_t->pbData[6]),wlen);

					SSP_slave_cfg_t.length	=	wlen+2;
					SSP_slave_cfg_t.tx_data	=	SlaveTxBuffer;
					SSP_slave_cfg_t.rx_cnt	=	0;
					SSP_slave_cfg_t.tx_cnt	=	0;

					SSP_ReadWrite(LPC_SSP1,&SSP_slave_cfg_t,SSP_TRANSFER_INTERRUPT);
					LPC_SSP1->IMSC |= 0x08;

					LPC_Response_to_PC(SPI_oper_t,DUT_STATUS_SUCCESS);
				}
				else if(g_mode_s == NATIVE)
				{
					uint16_t wlen;
					wlen = SPI_oper_t->wLength-6;


					memcpy(SlaveTxBuffer,&(SPI_oper_t->pbData[6]),wlen);

					SSP_slave_cfg_t.length	=	wlen;
					SSP_slave_cfg_t.tx_data	=	SlaveTxBuffer;
					SSP_slave_cfg_t.rx_cnt	=	0;
					SSP_slave_cfg_t.tx_cnt	=	0;

					SSP_ReadWrite(LPC_SSP1,&SSP_slave_cfg_t,SSP_TRANSFER_INTERRUPT);
					LPC_SSP1->IMSC |= 0x08;

					LPC_Response_to_PC(SPI_oper_t,DUT_STATUS_SUCCESS);
				}

			}
			else
				LPC_Response_to_PC(SPI_oper_t,DUT_STATUS_SPI_NOT_CONFIG);
			break;
		case DUT_Rx:
			if(((SPI_oper_t->interface >> 3 &0x03) == SSP0) && ((gCurr_Master&0x0F) == SSP0))
			{
				Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,0);
				SPPx_Receive(LPC_SSP0,SPI_oper_t);
				Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,1);
			}
			else if(((SPI_oper_t->interface >> 3 &0x03) == SSP1) && ((gCurr_Slave&0x0F) == SSP1))
			{
				if(SSP_slave_cfg_t.rx_cnt != 0)
				{
					uint16_t wlen = SSP_slave_cfg_t.rx_cnt;
					Response_Buffer[0]	=	SPI_oper_t->bCmdCode;
					Response_Buffer[1]	=	SPI_oper_t->interface | 0x80;
					Response_Buffer[2]	=	DUT_STATUS_SUCCESS;
					Response_Buffer[3]	=	DUT_STATUS_SUCCESS;
					Response_Buffer[4]	=	wlen & 0xFF;
					Response_Buffer[5]	=	(wlen >> 8) & 0xFF;
					memcpy((&Response_Buffer[6]),SlaveRxBuffer,wlen);
					DUT_Response_to_PC(Response_Buffer,wlen+6);
					//SSP_slave_cfg_t.rx_data -= SSP_slave_cfg_t.rx_cnt;
					SSP_slave_cfg_t.rx_cnt = 0;
				}
				else
					LPC_Response_to_PC(SPI_oper_t,PH_ERR_DATA_UNAVAILABLE);
			}
			else
				LPC_Response_to_PC(SPI_oper_t,DUT_STATUS_SPI_NOT_CONFIG);
			break;
		case DUT_TxRx:
			if(((SPI_oper_t->interface >> 3 &0x03) == SSP0) && ((gCurr_Master&0x0F) == SSP0))
			{
				ret = SSPx_Send(LPC_SSP0, SPI_oper_t);
				if(ret)
				{
					Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,0);
					SPPx_Receive(LPC_SSP0, SPI_oper_t);
					Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,1);
				}
			}
			else
				LPC_Response_to_PC(SPI_oper_t,DUT_STATUS_SPI_NOT_CONFIG);
			break;
	}
}


/*Function Name     : SSPx_Config
 *Description       : Configure SSPx
 *Input 			: Structure to Incoming frame
 *Output Parameters : NA
 *
 *Note:             :
 */
void SSPx_Config(DUT_CmdFrame_t *SPI_Cfg_t)
{
	dutMasterSlave_t SPI_M_S = SPI_Cfg_t->pbData[0];
	uint8_t CPOL = (SPI_Cfg_t->pbData[1]);
	uint8_t CPHA = (SPI_Cfg_t->pbData[2]);
	uint32_t clockrate = *((uint32_t*)(&SPI_Cfg_t->pbData[3]));
	if((((SPI_Cfg_t->interface >> 3) & 0x03) == SSP0) && SPI_M_S == MASTER)
	{
		/*Configure SSP0 as master*/
		gCurr_Master = SSP0;
		gCurr_Master |= 0x10;
		g_wTimeOut = SPI_Cfg_t->pbData[9];/*Time out is here because we need it in transreceive*/
		g_wTimeOut <<= 8;
		g_wTimeOut |= SPI_Cfg_t->pbData[8];
		g_wait_DATAIRQ = ((SPI_Cfg_t->pbData[7] >> 6) & 0x03);
		g_mode = SPI_Cfg_t->pbData[7] &0x03;
		SSP0_Init(CPOL,CPHA,clockrate);
		LPC_Response_to_PC(SPI_Cfg_t,DUT_STATUS_SUCCESS);
	}
	else if((((SPI_Cfg_t->interface >> 3) & 0x03) == SSP1) && SPI_M_S == SLAVE)
	{
		/*Configure SSP1 as slave*/
		gCurr_Slave = SSP1;
		g_mode_s = SPI_Cfg_t->pbData[7] &0x03;
		gCurr_Slave |= 0x10;
		g_wTimeOut = SPI_Cfg_t->pbData[9];
		g_wTimeOut <<= 8;
		g_wTimeOut |= SPI_Cfg_t->pbData[8];
		g_wait_DATAIRQ = ((SPI_Cfg_t->pbData[7] >> 6) & 0x03);
		SSP1_Init(CPOL,CPHA,clockrate);

		/*Used to enable slave transmit data*/
		SSP_SlaveOutputCmd(LPC_SSP1,ENABLE);
		SPI_Slave_Config(LPC_SSP1);
		NVIC_EnableIRQ(SSP1_IRQn);
		LPC_Response_to_PC(SPI_Cfg_t,DUT_STATUS_SUCCESS);
	}
}


/*Function Name     : SSPx_Send
 *Description       : Transfer data over SSP0
 *
 *Input Parameters  : SSP Peripheral number
 *Input 			: Structure to Incoming frame
 *Output Parameters : Status- SUCCESS or ERROR
 *
 *Note:             :
 */
Status SSPx_Send(LPC_SSP_TypeDef *SSPx, DUT_CmdFrame_t *SSPx_Tx_t)
{
	Status ret;
	/*To ensure that the length is not more that 511 Bytes per transaction*/
	if((SSPx_Tx_t->wLength-6) > 1028)
	{	LPC_Response_to_PC(SSPx_Tx_t,PH_ERR_FRAMING_ERROR);
		return ERROR;
	}

	SSP_DATA_SETUP_Type SSPx_M_Send;
	SSPx_M_Send.tx_data	=	&(SSPx_Tx_t->pbData[6]);
	SSPx_M_Send.length	=	(SSPx_Tx_t->wLength-6);
	SSPx_M_Send.rx_data	=	NULL;

	Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,0);
	ret = SSP_ReadWrite(SSPx,&SSPx_M_Send,SSP_TRANSFER_POLLING);
	//for(i=0;i<255;i++);/*Added to avoid the slave select going high before clock is finished in case of low speds 100khz*/
	Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,1);
	if(ret == (SSPx_Tx_t->wLength-6))
		return SUCCESS;
	else
		return ERROR;
}

/*Function Name     : SSPx_Receive
 *Description       : Receive data over SSPx
 *
 *Input Parameters  : SSP Peripheral number
 *Input 			: Structure to Incoming frame
 *Output Parameters : NA
 *
 *Note:             :
 */
void SPPx_Receive(LPC_SSP_TypeDef *SSPx, DUT_CmdFrame_t *SSP_Rx_t)
{
	SSP_DATA_SETUP_Type SSPx_M_Receive;
	uint16_t rxlen, wtimeout;
	uint8_t ret;
	DUT_RespFrame_t *resp_t = (DUT_RespFrame_t *)&Response_Buffer;

	wtimeout = SSP_Rx_t->pbData[3];
	wtimeout <<= 8;
	wtimeout |= SSP_Rx_t->pbData[2];

	/*Since receive is the task performed the tx data pointer needs to be NULL*/
	SSPx_M_Receive.tx_data	= NULL;

	if(g_wait_DATAIRQ)
	{
		delay(wtimeout);
		ret = 1;
	}
	else
		ret = delay_1(wtimeout);

	if(ret)
	{
		/*Receiving when the mode is HDLL with CRC*/
		if(g_mode == HDLL_W_CRC)
		{
			SSPx_M_Receive.rx_data	= &(resp_t->pbData[0]);
			SSPx_M_Receive.length 	= 3;
			/*Read first two bytes of length in HDLL mode*/
			if(SSP_ReadWrite(LPC_SSP0,&SSPx_M_Receive,SSP_TRANSFER_POLLING))
			{
				/*Convert the length from the LSB first format*/
				rxlen 	= 	resp_t->pbData[1];
				rxlen 	<<= 8;
				rxlen 	|=	resp_t->pbData[2];
				if(rxlen > 1028)
				{
					LPC_Response_to_PC(SSP_Rx_t, PH_ERR_INVALID_PARAMETER );
							return;
				}
				/*Initialize the structure*/
				SSPx_M_Receive.length 	= rxlen+2;
				SSPx_M_Receive.rx_data	= &(resp_t->pbData[3]);
				/*Read the remaining bytes of the data as given in length in first two bytes*/
				if(SSP_ReadWrite(LPC_SSP0,&SSPx_M_Receive,SSP_TRANSFER_POLLING))
				{
					resp_t->bCmdCode = SSP_Rx_t->bCmdCode;
					resp_t->interface = SSP_Rx_t->interface | 0x80;
					resp_t->wStatus = DUT_STATUS_SUCCESS;
					resp_t->wLength = SSPx_M_Receive.length+2;
					DUT_Response_to_PC(Response_Buffer,resp_t->wLength+6);
					return ;
				}
				else
				{
					LPC_Response_to_PC(SSP_Rx_t,PH_ERR_INTERNAL_ERROR);
				}
			}
			else
			{
				LPC_Response_to_PC(SSP_Rx_t,PH_ERR_INTERNAL_ERROR);
			}
		}
		/*Receiving when the mode is HDLL without CRC*/
		else if(g_mode == HDLL_WO_CRC)
		{
			SSPx_M_Receive.rx_data	= &(resp_t->pbData[0]);
			SSPx_M_Receive.length 	= 3;
			/*Read first two bytes of length in HDLL mode*/
			if(SSP_ReadWrite(LPC_SSP0,&SSPx_M_Receive,SSP_TRANSFER_POLLING))
			{
				/*Convert the length from the LSB first format*/
				rxlen 	= 	resp_t->pbData[1];
				rxlen 	<<= 8;
				rxlen 	|=	resp_t->pbData[2];

				if(rxlen > 1028)
				{
					LPC_Response_to_PC(SSP_Rx_t, PH_ERR_INVALID_PARAMETER );
							return;
				}
				SSPx_M_Receive.length 	= rxlen;
				SSPx_M_Receive.rx_data	= &(resp_t->pbData[3]);
				/*Read the remaining bytes of the data as given in length in first two bytes*/
				if(SSP_ReadWrite(LPC_SSP0,&SSPx_M_Receive,SSP_TRANSFER_POLLING))
				{
					resp_t->bCmdCode = SSP_Rx_t->bCmdCode;
					resp_t->interface = SSP_Rx_t->interface | 0x80;
					resp_t->wStatus = DUT_STATUS_SUCCESS;
					resp_t->wLength = SSPx_M_Receive.length+2;
					DUT_Response_to_PC(Response_Buffer,resp_t->wLength+6);
					return ;
				}
				else
				{
					LPC_Response_to_PC(SSP_Rx_t,PH_ERR_INTERNAL_ERROR);
				}
			}
			else
			{
				LPC_Response_to_PC(SSP_Rx_t,PH_ERR_INTERNAL_ERROR);
			}
		}
		/*Receiving when the mode is NATIVE*/
		else if(g_mode == NATIVE)
		{
			/*Convert the length from the LSB first format*/
			rxlen = SSP_Rx_t->pbData[5];
			rxlen <<= 8;
			rxlen |= SSP_Rx_t->pbData[4];

			if(rxlen > 1028)
			{
				LPC_Response_to_PC(SSP_Rx_t, PH_ERR_INVALID_PARAMETER );
						return;
			}
			/*Initialize the structure*/
			SSPx_M_Receive.rx_data	= &(resp_t->pbData[0]);
			SSPx_M_Receive.length 	= rxlen;
			if(SSP_ReadWrite(LPC_SSP0,&SSPx_M_Receive,SSP_TRANSFER_POLLING))
			{
				resp_t->bCmdCode = SSP_Rx_t->bCmdCode;
				resp_t->interface = SSP_Rx_t->interface | 0x80;
				resp_t->wStatus = DUT_STATUS_SUCCESS;
				resp_t->wLength = rxlen;
				DUT_Response_to_PC(Response_Buffer,resp_t->wLength+6);
				return ;
			}
			else
				LPC_Response_to_PC(SSP_Rx_t,PH_ERR_INTERNAL_ERROR);
		}
	}
	else
	{
		LPC_Response_to_PC(SSP_Rx_t,PH_ERR_IO_TIMEOUT);
	}

}

/*Function Name     : SPI_Slave_Config
 *Description       : Configure the SSP slave
 *
 *Input Parameters  : SSP Peripheral number
 *Output Parameters : NA
 *
 *Note:             :
 */
void SPI_Slave_Config(LPC_SSP_TypeDef *SSPx)
{
	SSP_slave_cfg_t.length	= 0;
	SSP_slave_cfg_t.rx_data	= SlaveRxBuffer;
	SSP_slave_cfg_t.tx_data	= NULL;
	SSP_slave_cfg_t.rx_cnt	= 0;
	SSP_slave_cfg_t.tx_cnt	= 0;

	SSP_ReadWrite(LPC_SSP1,&SSP_slave_cfg_t,SSP_TRANSFER_INTERRUPT);
}

/*Function Name     : fmtm_SPI_Send
 *Description       : SSP transmit for fmtm scenario
 *Input Parameters  : SSP Peripheral number
 *Input Parameters	: Pointer to Incoming frame
 *Input Parameters	: Variable indicating block or non-blocking call
 *Output Parameters : NA
 *
 *Note:             :
 */
Status fmtm_SPI_Send(LPC_SSP_TypeDef * SSPx, DUT_CmdFrame_t *fmtm_ssp_t)
{
	Status ret;
	/*To ensure that the length is not more that 511 Bytes per transaction*/
	if((fmtm_ssp_t->wLength) > 1028)
	{
		LPC_Response_to_PC(fmtm_ssp_t,PH_ERR_FRAMING_ERROR);
		return ERROR;
	}

	SSP_DATA_SETUP_Type SSPx_M_Send;
	SSPx_M_Send.tx_data	=	(uint8_t*)(fmtm_ssp_t);
	SSPx_M_Send.length	=	(fmtm_ssp_t->wLength + 4);
	SSPx_M_Send.rx_data	=	NULL;

	Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,0);
	ret = SSP_ReadWrite(SSPx,&SSPx_M_Send,SSP_TRANSFER_POLLING);
	Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,1);
	if(ret == (fmtm_ssp_t->wLength+4))
		return SUCCESS;
	else
		return ERROR;
}

/*Function Name     : fmtm_SPI_Receive
 *Description       : SSP receive for fmtm scenario
 *Input Parameters  : SSP Peripheral number
 *Input Parameters	: Pointer to Incoming frame
 *Input Parameters	: Variable indicating block or non-blocking call
 *Output Parameters : NA
 *
 *Note:             :
 */
void fmtm_SPI_Receive(LPC_SSP_TypeDef * SSPx, DUT_CmdFrame_t *fmtm_ssp_t)
{
	SSP_DATA_SETUP_Type SSPx_M_Receive;
	uint16_t rxlen;
	uint8_t ret;
	DUT_RespFrame_t *resp_t = (DUT_RespFrame_t *)&Response_Buffer;

	/*Since receive is the task performed the tx data pointer needs to be NULL*/
	SSPx_M_Receive.tx_data	= NULL;

	ret = delay_1(g_wTimeOut);

	if(ret)
	{
	/*Receiving when the mode is HDLL with CRC*/
		SSPx_M_Receive.rx_data	= (uint8_t*)resp_t;
		SSPx_M_Receive.length 	= 6;
		Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,0);
		/*Read first two bytes of length in HDLL mode*/
		if(SSP_ReadWrite(SSPx,&SSPx_M_Receive,SSP_TRANSFER_POLLING))
		{
			Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,1);
			/*Convert the length from the LSB first format*/
			rxlen 	= 	resp_t->pbData[5];
			rxlen 	<<= 8;
			rxlen 	|=	resp_t->pbData[4];
			if(rxlen > 1028)
			{
				LPC_Response_to_PC(fmtm_ssp_t, PH_ERR_INVALID_PARAMETER );
						return;
			}

			/*Initialize the structure with new length and new buffer*/
			SSPx_M_Receive.length 	= rxlen;//Since no CRC is available.
			SSPx_M_Receive.rx_data	= &(resp_t->pbData[6]);
			Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,0);
			/*Read the remaining bytes of the data as given in length in first two bytes*/
			if(SSP_ReadWrite(SSPx,&SSPx_M_Receive,SSP_TRANSFER_POLLING))
			{
				Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,1);
				//resp_t->bCmdCode = fmtm_ssp_t->bCmdCode;
				//resp_t->interface = fmtm_ssp_t->interface | 0x80;
				//resp_t->wStatus = DUT_STATUS_SUCCESS;
				//resp_t->wLength = SSPx_M_Receive.length;
				DUT_Response_to_PC(Response_Buffer,resp_t->wLength+6);
			}
			else
			{
				LPC_Response_to_PC(fmtm_ssp_t,PH_ERR_INTERNAL_ERROR);
			}
		}
		else
		{
			LPC_Response_to_PC(fmtm_ssp_t,PH_ERR_INTERNAL_ERROR);
		}
		Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,SSP_SSEL0,1);
	}
	else
		LPC_Response_to_PC(fmtm_ssp_t,PH_ERR_IO_TIMEOUT);
}
