/*
 * dutCmd.c
 *
 *  Created on: Jan 2, 2014
 *      Author: nxp74831
 */

#include "LPC17xx.h"
#include "lpc_types.h"
#include "dutCmd.h"
#include "interfaces.h"
#include "USBVcom.h"
#include "dutCmd.h"

#ifdef PHFL_SYSVNV
	#ifndef	__SD_PROJECT__
		#include "SysDispatcher.h"
	#endif
#endif
/************************************************************************
 * Global Variables
 ***********************************************************************/

/*
 *Function Name     : dutPN640parseConfigurationComand
 *Description       :
 *
 *Input Parameters  :
 *Output Parameters :
 *
 *Note:             :
 */
dutStatus_t dutparseConfigurationComand(DUT_CmdFrame_t *dutcmd)
{
	switch((dutcmd->interface >> 5) & 0x03)
	{
		case DUT_GPIO:
			if(((dutcmd->interface) & 0x07)  == 0x00)
				Transparent_exchange_I2C(dutcmd); /*Function to perform a transparent exchange when 2nd byte is 0x00*/
			else
				LPC_GPIO_Operations(dutcmd);
			break;

		case DUT_I2C:
				DUT_I2Cx_operation(dutcmd);
			break;

		case DUT_SPI:
			/*TODO */
				DUT_SSPx_Operation(dutcmd);
			break;

		case DUT_HSU:
			/*TODO */
				DUT_HSU_Operation(dutcmd);

			break;
	}
	return DUT_STATUS_SUCCESS;
}

/*
 *Function Name     : LPC_GPIO_Operations
 *Description       :Used to SET/GET values of GPIO's
 *
 *Input Parameters  :Pointer to the Command frame structure
 *Output Parameters :
 *
 *Note:             :
 */
void LPC_GPIO_Operations(DUT_CmdFrame_t *gpio_t)
{
	GPIO gpio_operation = (GPIO) ((gpio_t->interface) & 0x07);
	dutStatus_t ret;
	switch(gpio_operation)
	{
		case GPIO_Get_Value:
			/*TODO*/
			ret = GPIO_Get_Val(gpio_t);
			*(dutStatus_t*)(&Response_Buffer[2])= ret;

			/**<Send a response to the PC for the get value command*/
			DUT_Response_to_PC(Response_Buffer,*((uint16_t*)(&Response_Buffer[4]))+6);
			break;

		case GPIO_Set_Value:
			GPIO_Config(gpio_t);
			break;

		case GPIO_Toggle:
			GPIO_Toggle_pin(gpio_t);
			break;
	}
}

/*
 *Function Name     : GPIO_Config
 *Description       :Used for configure the GPIO as input or Output
 *
 *Input Parameters  :pointer to the Command frame structure
 *Output Parameters :
 *
 *Note:             :
 */
void GPIO_Config(DUT_CmdFrame_t *GPIO_cfg_t)
{
	uint16_t bcnt;
	uint16_t blen = GPIO_cfg_t->wLength;
	for(bcnt=0; bcnt<blen; bcnt=bcnt+2)
	{
		GPIO_Port_t portnum = (GPIO_Port_t)((GPIO_cfg_t->pbData[bcnt] >> 5) & 0x07);
		uint8_t bpin= (GPIO_cfg_t->pbData[bcnt] & 0x1F);
		uint8_t bvalue = (GPIO_cfg_t->pbData[bcnt+1] >> 1) & 0x01;
		uint8_t bin_out = (GPIO_cfg_t->pbData[bcnt+1]) & 0x01;
		switch(portnum)
		{
			case Port0:
				GPIO_SetPinDIR(LPC_GPIO_0,Port0,bpin,bin_out,bvalue);
				break;

			case Port1:
				GPIO_SetPinDIR(LPC_GPIO_1,Port1,bpin,bin_out,bvalue);
				break;

			case Port2:
				GPIO_SetPinDIR(LPC_GPIO_2,Port2,bpin,bin_out,bvalue);
				break;

			case Port3:
				GPIO_SetPinDIR(LPC_GPIO_3,Port3,bpin,bin_out,bvalue);
				break;
			case Port4:
				GPIO_SetPinDIR(LPC_GPIO_4,Port4,bpin,bin_out,bvalue);
				break;
		}
	}
	LPC_Response_to_PC(GPIO_cfg_t,DUT_STATUS_SUCCESS);/*Success*/
}

/*
 *Function Name     : GPIO_SetPinDIR
 *Description       :Used to set direction of GPIO
 *
 *Input Parameters  :pointer to the Command frame structure
 *Input 			:Portnumber
 *Input 			:Pin number
 *Input 			: Output(i.e input or Output)
 *Input 			:High or Low value when configured as Output pin
 *Output Parameters :
 *
 *Note:             :
 */
void GPIO_SetPinDIR(LPC_GPIO_T *pGPIO, uint8_t port, uint8_t pin, bool output, bool value)
{
	if (output)
	{
		Chip_GPIO_SetPinDIROutput(pGPIO, port, pin);
		Chip_GPIO_SetPinState(pGPIO,port,pin,value);
	}
	else
	{
		Chip_GPIO_SetPinDIRInput(pGPIO, port, pin);
	}
}

/*
 *Function Name     : GPIO_Get_Val
 *Description       :Used to get value of GPIO
 *
 *Input Parameters  :pointer to the Command frame structure
 *Output Parameters :
 *
 *Note:             :
 */
dutStatus_t GPIO_Get_Val(DUT_CmdFrame_t *get_val_t)
{
	uint16_t wlen = get_val_t->wLength;
	uint16_t bvar = 0;
	DUT_RespFrame_t *resp_t = (DUT_RespFrame_t *)&Response_Buffer;
	resp_t->bCmdCode = get_val_t->bCmdCode;
	resp_t->interface = get_val_t->interface | 0x80;
	for(bvar = 0; bvar < wlen;bvar++)
	{
		GPIO_Port_t portnum = (GPIO_Port_t)((get_val_t->pbData[bvar] >> 5) & 0x07);
		uint8_t bpin= (get_val_t->pbData[bvar] & 0x1F);
		switch(portnum)
		{
		case Port0:
			if(!Chip_GPIO_GetPinDIR(LPC_GPIO_0,portnum,bpin))
			{	resp_t->pbData[bvar]=Chip_GPIO_GetPinState(LPC_GPIO_0,portnum,bpin);
				resp_t->wLength = bvar;
			}
			else
			{
				return PH_ERR_INVALID_PARAMETER;
			}
			break;

		case Port1:
			if(!Chip_GPIO_GetPinDIR(LPC_GPIO_1,portnum,bpin))
			{	resp_t->pbData[bvar]=Chip_GPIO_GetPinState(LPC_GPIO_1,portnum,bpin);
				resp_t->wLength = bvar;
			}
			else
			{
				return PH_ERR_INVALID_PARAMETER;
			}
			break;

		case Port2:
			if(!Chip_GPIO_GetPinDIR(LPC_GPIO_2,portnum,bpin))
			{	resp_t->pbData[bvar]=Chip_GPIO_GetPinState(LPC_GPIO_2,portnum,bpin);
				resp_t->wLength = bvar;
			}
			else
			{
				return PH_ERR_INVALID_PARAMETER;
			}
			break;

		case Port3:
			if(!Chip_GPIO_GetPinDIR(LPC_GPIO_3,portnum,bpin))
			{	resp_t->pbData[bvar]=Chip_GPIO_GetPinState(LPC_GPIO_3,portnum,bpin);
				resp_t->wLength = bvar;
			}
			else
			{
				return PH_ERR_INVALID_PARAMETER;
			}
			break;
		case Port4:
			if(!Chip_GPIO_GetPinDIR(LPC_GPIO_4,portnum,bpin))
			{	resp_t->pbData[bvar]=Chip_GPIO_GetPinState(LPC_GPIO_4,portnum,bpin);
				resp_t->wLength = bvar;
			}
			else
			{
				return PH_ERR_INVALID_PARAMETER;
			}
			break;
		}
	}
	return DUT_STATUS_SUCCESS;
	/*Used to send the response from the LPC to PC*/
	//DUT_Response_to_PC(Response_Buffer,resp_t->wLength+6);
}

/*
 *Function Name     : GPIO_Toggle_pin
 *Description       :Used to toggle the GPIO
 *
 *Input Parameters  :pointer to the Command frame structure
 *Output Parameters :
 *
 *Note:             :
 */
void GPIO_Toggle_pin(DUT_CmdFrame_t *gpio_toggle_t)
{
	GPIO_Port_t portnum = (GPIO_Port_t)((gpio_toggle_t->pbData[0] >> 5) & 0x07);
	uint8_t bpin= (gpio_toggle_t->pbData[0] & 0x1F);
	GPIO_Pulse_t pulse_type = gpio_toggle_t->pbData[1];
	uint16_t wpulse_width = gpio_toggle_t->pbData[3];
	wpulse_width <<= 8;
	wpulse_width |= gpio_toggle_t->pbData[2];

	switch(pulse_type)
	{
		case Short_Pulse:
			GPIO_Short_Pulse(portnum,bpin,wpulse_width,true,false,false);
			break;
		case Short_Inverted_Pulse:
			GPIO_Short_Pulse(portnum,bpin,wpulse_width,false,true,true);
			break;
		case Long_Pulse:
			GPIO_Long_Pulse(portnum,bpin,wpulse_width,true,false,false);
			break;
		case Long_Inverted_Pulse:
			GPIO_Long_Pulse(portnum,bpin,wpulse_width,false,true,true);
			break;
	}
	LPC_Response_to_PC(gpio_toggle_t,DUT_STATUS_SUCCESS);/*Success*/

}


/*
 *Function Name     : GPIO_Short_Pulse
 *Description       :Used for Short pulse of a port pin(LOW-delay-HIGH)
 *
 *Input Parameters  :Port Number
 *Input 			:Pin Number
 *Input 			:Pulse width
 *Input 			:Initial Pin state
 *Input 			:Final Pin state
 *Output Parameters :
 *
 *Note:             :
 */
void GPIO_Short_Pulse(uint8_t portnum, uint8_t pin, uint16_t pulse, BOOL_8 pin_state_1, BOOL_8 pin_state_2,BOOL_8 pin_state_3 )
{
	switch(portnum)
	{
		case Port0:
			Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,pin,pin_state_3);
			Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,pin,pin_state_1);
			delay(pulse);
			Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,pin,pin_state_2);
			break;

		case Port1:
			Chip_GPIO_SetPinState(LPC_GPIO_1,Port1,pin,pin_state_3);
			Chip_GPIO_SetPinState(LPC_GPIO_1,Port1,pin,pin_state_1);
			delay(pulse);
			Chip_GPIO_SetPinState(LPC_GPIO_1,Port1,pin,pin_state_2);
			break;

		case Port2:
			Chip_GPIO_SetPinState(LPC_GPIO_2,Port2,pin,pin_state_3);
			Chip_GPIO_SetPinState(LPC_GPIO_2,Port2,pin,pin_state_1);
			delay(pulse);
			Chip_GPIO_SetPinState(LPC_GPIO_2,Port2,pin,pin_state_2);
			break;

		case Port3:
			Chip_GPIO_SetPinState(LPC_GPIO_3,Port3,pin,pin_state_3);
			Chip_GPIO_SetPinState(LPC_GPIO_3,Port3,pin,pin_state_1);
			delay(pulse);
			Chip_GPIO_SetPinState(LPC_GPIO_3,Port3,pin,pin_state_2);
			break;
		case Port4:
			Chip_GPIO_SetPinState(LPC_GPIO_4,Port4,pin,pin_state_3);
			Chip_GPIO_SetPinState(LPC_GPIO_4,Port4,pin,pin_state_1);
			delay(pulse);
			Chip_GPIO_SetPinState(LPC_GPIO_4,Port4,pin,pin_state_2);
			break;
	}
}


/*
 *Function Name     : GPIO_Long_Pulse
 *Description       :Used for Short pulse of a port pin(LOW-delay-HIGH)
 *
 *Input Parameters  :Port Number
 *Input 			:Pin Number
 *Input 			:Pulse width
 *Input 			:Initial Pin state
 *Input 			:Final Pin state
 *Output Parameters :
 *
 *Note:             :
 */
void GPIO_Long_Pulse(uint8_t portnum, uint8_t pin, uint16_t pulse, BOOL_8 pin_state_1, BOOL_8 pin_state_2, BOOL_8 pin_state_3 )
{
	switch(portnum)
	{
		case Port0:
			Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,pin,pin_state_3);
			Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,pin,pin_state_1);
			delay(pulse*1000);
			Chip_GPIO_SetPinState(LPC_GPIO_0,Port0,pin,pin_state_2);
			break;

		case Port1:
			Chip_GPIO_SetPinState(LPC_GPIO_1,Port1,pin,pin_state_3);
			Chip_GPIO_SetPinState(LPC_GPIO_1,Port1,pin,pin_state_1);
			delay(pulse*1000);
			Chip_GPIO_SetPinState(LPC_GPIO_1,Port1,pin,pin_state_2);
			break;

		case Port2:
			Chip_GPIO_SetPinState(LPC_GPIO_2,Port2,pin,pin_state_3);
			Chip_GPIO_SetPinState(LPC_GPIO_2,Port2,pin,pin_state_1);
			delay(pulse*1000);
			Chip_GPIO_SetPinState(LPC_GPIO_2,Port2,pin,pin_state_2);
			break;

		case Port3:
			Chip_GPIO_SetPinState(LPC_GPIO_3,Port3,pin,pin_state_3);
			Chip_GPIO_SetPinState(LPC_GPIO_3,Port3,pin,pin_state_1);
			delay(pulse*1000);
			Chip_GPIO_SetPinState(LPC_GPIO_3,Port3,pin,pin_state_2);
			break;
		case Port4:
			Chip_GPIO_SetPinState(LPC_GPIO_4,Port4,pin,pin_state_3);
			Chip_GPIO_SetPinState(LPC_GPIO_4,Port4,pin,pin_state_1);
			delay(pulse*1000);
			Chip_GPIO_SetPinState(LPC_GPIO_4,Port4,pin,pin_state_2);
			break;
	}
}


/*
 *Function Name     : Transparent_exchange_I2C
 *Description       :Used for transparent exchange when the 2nd byte in the incoming frame is 0x00
 *
 *Input Parameters  :pointer to the Command frame structure
 *Output Parameters :
 *
 *Note:             :
 */
void Transparent_exchange_I2C(DUT_CmdFrame_t *tranxchg_t)
{
	Status ret;
	DUT_RespFrame_t *resp_t = (DUT_RespFrame_t *)&Response_Buffer;
#ifdef PHFL_SYSVNV
	SysDriverTestSPIHIF_Lpc(tranxchg_t);
#else
	if(gCurr_Master == I2C0)
	{
		/*TODO*//*Uses only I2C0 For the transreceive*/
		ret = DUT_I2Cx_M_Send(LPC_I2C0, &(tranxchg_t->pbData[0]),tranxchg_t->wLength,gslave_addr);

		if(!ret)
		{
			LPC_Response_to_PC(tranxchg_t,DUT_STATUS_HW_IS_OFF);/*Need to decide the Error Response to send when transmit fails*/
			return;
		}

		ret = delay_1(g_wTimeOut);/*Wait for x-milliseconds for the data Ready line to go high*/
		if(ret)
		{
			ret = DUT_I2Cx_M_Receive(LPC_I2C0,&(resp_t->pbData[0]),resp_t->wLength,gslave_addr,g_mode);

			if(ret == SUCCESS)
			{/*In HDLL mode the first two bytes of data received is length*/
				if(g_mode == HDLL_W_CRC)
				{
					resp_t->bCmdCode = tranxchg_t->bCmdCode;
					resp_t->interface = tranxchg_t->interface | 0x80;
					resp_t->wStatus = DUT_STATUS_SUCCESS; /*TODO Decide on the error codes*/
					resp_t->wLength = resp_t->pbData[0];
					resp_t->wLength <<= 8;
					resp_t->wLength |= resp_t->pbData[1];
					resp_t->wLength += 4;
					DUT_Response_to_PC(Response_Buffer,(resp_t->wLength+6)); /*Transmit the response back to the PC*/
				}
				else if(g_mode == HDLL_WO_CRC)
				{
					resp_t->bCmdCode = tranxchg_t->bCmdCode;
					resp_t->interface = tranxchg_t->interface | 0x80;
					resp_t->wStatus = DUT_STATUS_SUCCESS; /*TODO Decide on the error codes*/
					resp_t->wLength = resp_t->pbData[0];
					resp_t->wLength <<= 8;
					resp_t->wLength |= resp_t->pbData[1];
					resp_t->wLength += 2;
					DUT_Response_to_PC(Response_Buffer,(resp_t->wLength+6)); /*Transmit the response back to the PC*/
				}
				else
				{
					resp_t->bCmdCode = tranxchg_t->bCmdCode;
					resp_t->interface = tranxchg_t->interface | 0x80;
					resp_t->wStatus = DUT_STATUS_SUCCESS; /*TODO Decide on the error codes*/
					resp_t->wLength = tranxchg_t->wLength;
					DUT_Response_to_PC(Response_Buffer,(resp_t->wLength+6));
				}
			}
			else
			{
				LPC_Response_to_PC(tranxchg_t,DUT_STATUS_HW_IS_OFF);
			}
		}
		else
		{
			LPC_Response_to_PC(tranxchg_t,PH_ERR_IO_TIMEOUT);
		}
	}
	else
		LPC_Response_to_PC(tranxchg_t,DUT_STATUS_I2C_NOT_CONFIG);
#endif
}


/*
 *Function Name     : DUT_Response_to_PC
 *Description       :
 *
 *Input Parameters  :Pointer to the response buffer
 *Input 			:Length of transmission
 *Output Parameters :
 *
 *Note:             :
 */
void DUT_Response_to_PC(uint8_t *presp_buff, uint16_t wlen)
{
	VCOM_putdata(presp_buff, wlen); /* transfer the data back to the PC */
}

/*
 *Function Name     : LPC_Response_to_PC
 *Description       :
 *
 *Input Parameters  :Command frame structure
 *Input 			:Status of the previous command
 *Output Parameters :
 *
 *Note:             :
 */
void LPC_Response_to_PC(DUT_CmdFrame_t *pInframe,uint16_t bstatus )
{
	uint8_t bresp_buff[6];
	bresp_buff[0] = pInframe->bCmdCode;
	bresp_buff[1] = (pInframe->interface) | 0x80; /*TODO*/
	*(uint16_t*)(&bresp_buff[2]) = bstatus;
	bresp_buff[4] = 0x00;
	bresp_buff[5] = 0x00;
	VCOM_putdata(bresp_buff, 6);

}
